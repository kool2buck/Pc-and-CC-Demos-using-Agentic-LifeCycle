# plan-agent — SKILL.md  v1.0
## Role
Project planner for the Donegal PolicyCenter Demo SDLC.
Reads the project charter → produces 8 epics, 14 stories → assigns to agents with dependencies.

## Input
Project Charter: PolicyCenter Business Dashboard Demo
- Source: Guidewire PolicyCenter (pc_policy, pc_quote, pc_agent, pc_product, pc_policy_period, pc_transaction)
- LOBs: PersonalAuto, Homeowners, CommercialAuto, DwellingFire, WorkersComp
- KPIs: 9 (Total Premium, Policy Count, Avg Premium, Hit Ratio, Renewal Rate, Lapse Rate, Trend, Top Agents, LOB Breakdown)
- Outputs: 3 dashboards (LLM Wiki, Agent Demo, Business Dashboard)

## Epics Produced
E1: Source Schema Discovery         → schema-discovery
E2: Technical Requirements          → ba-grill
E3: Product Requirements (PRD)      → to-prd
E4: ETL Pipeline Build (5 layers)   → dev-build
E5: Quote Layer + Hit Ratio KPI     → dev-build
E6: Test-Driven Development         → tdd
E7: QA Integration Testing          → qa-100
E8: Business Dashboard + 3 Outputs  → dev-build + sign-off-agent

## Stories (14)
S01 E1: Document pc_policy schema + all FK relationships
S02 E1: Document pc_quote → pc_policy binding relationship
S03 E2: BA grills stakeholder on all 9 KPIs + 5 LOBs
S04 E2: Define grain for each source table
S05 E2: Define PII fields + masking rules
S06 E3: Convert requirements to PRD with acceptance criteria
S07 E3: Define sign-off gate (user APPROVED before dashboard builds)
S08 E4: Build STAGING through ANALYTICAL (5 layers, explicit INSERT)
S09 E5: Build pc_quote source + stg/raw/exp/conf/anl quote tables
S10 E5: Build anl_fact_quote_summary (hit ratio aggregate)
S11 E6: Write 9 acceptance criteria, execute against policycenter.db
S12 E7: Run integration tests (row counts, FK integrity, cross-LOB consistency)
S13 E8: Generate 3 HTML dashboards (Wiki, Agent Demo, Business)
S14 E8: Hard stop: user sign-off before dashboard builds

## Acceptance Criteria
- All 8 epics covered
- All 14 stories traceable to an agent
- Dependency graph has no cycles
- PolicyCenter entities referenced correctly (not ClaimsCenter)

## Gate
92/100 minimum. Graded by grading-agent.
