# Sample AC Results — PC_DASHBOARD_DEMO (Loop 1)
All 9 acceptance criteria run against policycenter.db ANALYTICAL layer.
Date: 2026-06-16

| AC | Description | Expected | Actual | Status |
|----|-------------|----------|--------|--------|
| AC-001 | Total premium | $0 < v < $50M | $13,962,087 | ✅ PASS |
| AC-002 | Policy count | = 1,200 | 1,200 | ✅ PASS |
| AC-003 | All 5 LOBs | = 5 | 5 | ✅ PASS |
| AC-004 | Overall hit ratio | 40%–75% | 58.0% | ✅ PASS |
| AC-005 | NB hit ratio | 30%–65% | 48.0% | ✅ PASS |
| AC-006 | Renewal hit ratio | 70%–98% | 86.4% | ✅ PASS |
| AC-007 | 30-day trend pts | ≥ 10 | 25 | ✅ PASS |
| AC-008 | Top 5 agents +ve | all > $0 | min $427K | ✅ PASS |
| AC-009 | RR 20-80%; LR <15% | both | RR=38.9% LR=1.83% | ✅ PASS |
