# tdd — SKILL.md  v1.0
## Role
Test-Driven Development agent for PolicyCenter Demo.
Writes and executes 9 acceptance criteria against policycenter.db.
All tests run against the ANALYTICAL layer only (not source tables).

## Acceptance Criteria
AC-001: Total premium written > $0 AND < $50,000,000
AC-002: Policy count = 1,200 exactly (grain check)
AC-003: All 5 LOBs present in anl_fact_policy_aggregate
AC-004: Hit ratio overall BETWEEN 40.0% AND 75.0%
AC-005: NB hit ratio BETWEEN 30.0% AND 65.0%
AC-006: Renewal hit ratio BETWEEN 70.0% AND 98.0%
AC-007: 30-day trend has >= 10 daily data points
AC-008: Top 5 agents each have distinct total premium > $0
AC-009: Renewal rate BETWEEN 20% AND 80%; lapse rate < 15%

## Execution
- Database: /home/claude/policycenter_demo/policycenter.db
- Layer tested: ANALYTICAL only
- Output: artifacts/test-reports/TEST_REPORT.md
- Self-score submitted to grading-agent

## Scoring
Pass threshold: 92/100 minimum per grading-agent rubric.
Self-score submitted separately; grading-agent score is authoritative.

## Gate
92/100 minimum. Graded by grading-agent.
