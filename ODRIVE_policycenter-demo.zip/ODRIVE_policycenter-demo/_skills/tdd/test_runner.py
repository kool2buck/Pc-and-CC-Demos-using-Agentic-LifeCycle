#!/usr/bin/env python3
"""TDD Agent Test Runner — PolicyCenter Demo
Runs all 9 acceptance criteria against policycenter.db ANALYTICAL layer.
"""
import sqlite3, sys

DB = 'policycenter.db'
conn = sqlite3.connect(DB)
c = conn.cursor()

results = []
def check(ac_id, desc, val, expected_fn, expected_desc):
    ok = expected_fn(val)
    results.append((ac_id, desc, val, expected_desc, '✅ PASS' if ok else '❌ FAIL'))
    return ok

# AC-001
prem = c.execute("SELECT SUM(total_written_premium) FROM anl_fact_policy_aggregate").fetchone()[0]
check('AC-001','Total premium written',round(prem,0),lambda v:0<v<50_000_000,'$0 < v < $50M')

# AC-002
pol = c.execute("SELECT COUNT(*) FROM anl_dim_policy WHERE is_current=1").fetchone()[0]
check('AC-002','Policy count',pol,lambda v:v==1200,'= 1,200')

# AC-003
lobs = c.execute("SELECT COUNT(DISTINCT lob) FROM anl_fact_policy_aggregate").fetchone()[0]
check('AC-003','All 5 LOBs present',lobs,lambda v:v==5,'= 5')

# AC-004
hr = c.execute("SELECT CAST(SUM(bound_count) AS REAL)/SUM(total_quotes) FROM anl_fact_quote_summary").fetchone()[0]
check('AC-004','Overall hit ratio',round(hr*100,1),lambda v:40<=v<=75,'40% - 75%')

# AC-005
hr_nb = c.execute("SELECT CAST(SUM(bound_count) AS REAL)/SUM(total_quotes) FROM anl_fact_quote_summary WHERE quote_type='NewBusiness'").fetchone()[0]
check('AC-005','NB hit ratio',round(hr_nb*100,1),lambda v:30<=v<=65,'30% - 65%')

# AC-006
hr_rn = c.execute("SELECT CAST(SUM(bound_count) AS REAL)/SUM(total_quotes) FROM anl_fact_quote_summary WHERE quote_type='Renewal'").fetchone()[0]
check('AC-006','Renewal hit ratio',round(hr_rn*100,1),lambda v:70<=v<=98,'70% - 98%')

# AC-007
trend = c.execute("SELECT COUNT(*) FROM (SELECT date_key FROM anl_fact_policy_transaction GROUP BY date_key) WHERE date_key >= strftime('%Y%m%d', date('now','-30 days'))").fetchone()[0]
check('AC-007','30-day trend points',trend,lambda v:v>=10,'≥ 10')

# AC-008
top5 = c.execute("SELECT MIN(s) FROM (SELECT SUM(total_written_premium) as s FROM anl_fact_policy_aggregate GROUP BY agent_key ORDER BY s DESC LIMIT 5)").fetchone()[0]
check('AC-008','Top 5 agents positive',top5,lambda v:v>0,'all > $0')

# AC-009a
rr = c.execute("SELECT CAST(SUM(renewal_count) AS REAL)/SUM(policy_count) FROM anl_fact_policy_aggregate").fetchone()[0]
check('AC-009a','Renewal rate',round(rr*100,1),lambda v:20<=v<=80,'20% - 80%')

# AC-009b
lr = c.execute("SELECT CAST(SUM(lapse_count) AS REAL)/SUM(policy_count) FROM anl_fact_policy_aggregate").fetchone()[0]
check('AC-009b','Lapse rate',round(lr*100,2),lambda v:v<15,'< 15%')

conn.close()

print(f"{'AC':8} {'Description':30} {'Actual':15} {'Expected':20} {'Result'}")
print('─'*90)
for row in results:
    print(f"{row[0]:8} {row[1]:30} {str(row[2]):15} {row[3]:20} {row[4]}")

passed = sum(1 for r in results if 'PASS' in r[4])
print(f"\nResult: {passed}/{len(results)} PASS")
sys.exit(0 if passed==len(results) else 1)
