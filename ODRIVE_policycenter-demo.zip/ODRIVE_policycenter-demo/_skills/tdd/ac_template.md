# Acceptance Criteria Template — tdd
## Format
AC-NNN: [Description]
- SQL: [query against ANALYTICAL layer]
- Expected: [value or range]
- Actual: [result from DB]
- Status: PASS / FAIL

## 9 ACs for PC_DASHBOARD_DEMO
AC-001: Total premium written > $0 AND < $50,000,000
AC-002: Policy count = 1,200 exactly
AC-003: All 5 LOBs present in anl_fact_policy_aggregate
AC-004: Overall hit ratio BETWEEN 40.0% AND 75.0%
AC-005: NB hit ratio BETWEEN 30.0% AND 65.0%
AC-006: Renewal hit ratio BETWEEN 70.0% AND 98.0%
AC-007: 30-day trend >= 10 daily data points
AC-008: Top 5 agents all have distinct total premium > $0
AC-009: Renewal rate 20-80%; lapse rate < 15%
