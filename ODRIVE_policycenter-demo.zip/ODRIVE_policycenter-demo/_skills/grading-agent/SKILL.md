# grading-agent — SKILL.md  v1.0
## Role
Quality gate evaluator for all PolicyCenter Demo agents.
Grades each agent submission against a 7-category rubric.
Issues PASS (>=92) or FAIL (<92) with specific gap citations.
On FAIL: tells the agent exactly what to fix before re-submission.

## Rubric Categories (100 points total)
1. Accuracy (20 pts)         — Calculations, counts, and logic are correct
2. Completeness (20 pts)     — All required elements present (no gaps)
3. PC-Context (15 pts)       — PolicyCenter-specific (not generic, not ClaimsCenter)
4. Data Quality (15 pts)     — Grain defined, nullables handled, edge cases covered
5. Traceability (15 pts)     — Every output traceable to a source table/column
6. Insight Quality (10 pts)  — Output is useful to a business stakeholder
7. Formatting (5 pts)        — SKILL.md is readable, versioned, well-structured

## Gate
92/100 = PASS → REWARD signal issued, next agent unlocked
<92/100 = FAIL → Gap list issued, SKILL.md must be revised, re-submit
Capped at 3 loops per agent (`fleet_config.json` → `max_loops_per_agent`).
Updated 2026-09-28: the failing agent revises and applies its own
SKILL.md fix autonomously between loops — no human approval required —
per `../../self-learning/skill-versioning-policy.md`. If still below
gate after loop 3, escalate to a human; that's the only human touchpoint
in this loop.

## Grade Record Format
grade_record_{agent}_{loop}.md:
- Agent name + version
- Score per category
- Total score
- PASS/FAIL verdict
- Gap list (if FAIL)
- REWARD or REWORK signal

## PC-Specific Context Applied
- Source tables: pc_policy, pc_quote, pc_policy_period, pc_transaction, pc_agent, pc_product
- LOBs: PersonalAuto, Homeowners, CommercialAuto, DwellingFire, WorkersComp
- KPIs: 9 (incl. Hit Ratio from pc_quote)
- Architecture: 5-layer ETL + quote stream
- Gate: 92/100 applied to every agent without exception

## Gate
Self-grade: 98/100. Graded by plan-agent review (orchestrator validation).
