# Grading Rubric — Schema Audit (schema-discovery)
## Output Type: Schema discovery and documentation
## Gate: 92/100

| # | Category        | Weight | What Earns Full Score                                     |
|---|-----------------|--------|-----------------------------------------------------------|
| 1 | Accuracy        | 20     | All formulas, counts, and logic are verifiably correct    |
| 2 | Completeness    | 20     | All required elements present, no gaps                    |
| 3 | PC-Context      | 15     | PolicyCenter-specific (not generic, not ClaimsCenter)     |
| 4 | Data Quality    | 15     | Grain defined, nullables handled, edge cases documented   |
| 5 | Traceability    | 15     | Every output traceable to source table.column             |
| 6 | Insight Quality | 10     | Output is useful to a business stakeholder at Donegal     |
| 7 | Formatting      | 5      | SKILL.md versioned, readable, changes clearly marked      |

## Failure Patterns for Schema Audit
- Quote grain not defined → Category 4 (Data Quality) penalized
- PII fields not addressed → Category 3 (PC-Context) penalized
- Missing data lineage → Category 5 (Traceability) penalized
