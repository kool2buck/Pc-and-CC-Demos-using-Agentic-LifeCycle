# Grading Agent — PolicyCenter Demo
Scores every agent submission against the 7-category rubric.
Issues PASS (≥92) or FAIL (<92) with specific gap citations.

## Agents Graded This Project
| Agent           | Loop1 | Loop2 | Final | Status  |
|-----------------|-------|-------|-------|---------|
| plan-agent      | 94    | —     | 94    | ✅ PASS |
| grillmewithdocs | 80    | 95    | 95    | ✅ PASS |
| to-prd          | 82    | 96    | 96    | ✅ PASS |
| schema-discovery| 86    | 96    | 96    | ✅ PASS |
| dev-build       | 95    | —     | 95    | ✅ PASS |
| tdd             | 96    | —     | 96    | ✅ PASS |
| qa-100          | 85    | 95    | 95    | ✅ PASS |
| adf-pipeline    | 94    | —     | 94    | ✅ PASS |
| business-signoff| 100   | —     | 100   | ✅ PASS |
