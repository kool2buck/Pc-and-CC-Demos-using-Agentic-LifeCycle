# Grading Rubric Template — PolicyCenter Demo
## 7 Categories (100 points total)
| # | Category       | Weight | Description                                          |
|---|----------------|--------|------------------------------------------------------|
| 1 | Accuracy       | 20     | Calculations and logic are verifiably correct        |
| 2 | Completeness   | 20     | All required elements present, no gaps               |
| 3 | PC-Context     | 15     | PolicyCenter-specific, not generic or ClaimsCenter   |
| 4 | Data Quality   | 15     | Grain defined, nullables handled, edge cases covered |
| 5 | Traceability   | 15     | Every output traceable to source table/column        |
| 6 | Insight Quality| 10     | Output is useful to a business stakeholder           |
| 7 | Formatting     | 5      | SKILL.md readable, versioned, well-structured        |

## Gate: 92/100
- ≥92 → PASS, REWARD signal, unlock next agent
- <92 → FAIL, REWORK signal, gap list issued, re-submit required
