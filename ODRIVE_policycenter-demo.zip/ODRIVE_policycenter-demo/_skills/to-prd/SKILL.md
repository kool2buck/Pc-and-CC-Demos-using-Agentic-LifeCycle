# to-prd — SKILL.md  v1.0  ← FIRST SUBMISSION (WILL FAIL)
## Role
Converts ba-grill output into structured PRD with acceptance criteria and delivery spec.

## Inputs
- ba-grill Technical Requirements (v2.0, 95/100 PASS)
- Project Charter: PolicyCenter Business Dashboard Demo

## PRD Sections
1. Executive Summary: Build PolicyCenter analytics pipeline with 9 KPIs across 5 LOBs
2. Source System: Guidewire PolicyCenter SQLite (policycenter.db)
3. Architecture: 5-layer ETL (STAGING → RAW → EXPLORATION → CONFORMED → ANALYTICAL)
4. KPI Definitions: 9 KPIs as specified by ba-grill v2.0
5. Acceptance Criteria: Each KPI must compute without NULL or error
6. Dashboard: Single-file HTML, no server, LOB filter updates all charts

## Gaps (WILL CAUSE FAILURE)
- Dashboard data lineage not specified (which table feeds which KPI)
- Sign-off gate process not documented
- 3-dashboard output spec missing (wiki / agent demo / business)
- No definition of "done" for dashboard interactivity

## Gate
92/100 minimum. Graded by grading-agent.
