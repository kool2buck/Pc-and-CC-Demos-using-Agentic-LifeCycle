# PRD Template — to-prd Output Format
## Product Requirements Document
### 1. Executive Summary
### 2. Source System & Architecture
### 3. KPI Definitions with Data Lineage
   - KPI n: [Name] → [anl_ table.column]
### 4. Acceptance Criteria (per KPI)
### 5. Sign-Off Gate Specification
### 6. 3-Dashboard Output Specification
   - OUTPUT 1: wiki.html
   - OUTPUT 2: POLICYCENTER_SDLC_DEMO.html
   - OUTPUT 3: dashboard.html
### 7. Definition of Done
