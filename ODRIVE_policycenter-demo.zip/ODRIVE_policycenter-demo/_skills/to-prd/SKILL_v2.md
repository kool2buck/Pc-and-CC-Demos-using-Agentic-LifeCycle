# to-prd — SKILL.md  v2.0  ← REVISED AFTER LOOP 1 FAILURE (88/100)
## Role
Converts ba-grill output into structured PRD with acceptance criteria and delivery spec.

## Inputs
- ba-grill Technical Requirements (v2.0, 95/100 PASS)
- Project Charter: PolicyCenter Business Dashboard Demo

## PRD Sections (Complete)
1. Executive Summary: Build PolicyCenter analytics pipeline + 3 HTML dashboards
2. Source System: Guidewire PolicyCenter (policycenter.db — 5 tables + pc_quote)
3. Architecture: 5-layer ETL + quote layer (6 analytical tables)
4. KPI Definitions: 9 KPIs (6 card + 5 chart sections)
5. Acceptance Criteria: Each KPI must compute with data from ANALYTICAL layer only

## Data Lineage per KPI (ADDED v2)
- KPI 1 Total Premium → anl_fact_policy_aggregate.total_written_premium
- KPI 2 Policy Count → anl_dim_policy WHERE is_current=1
- KPI 3 Renewal Rate → anl_fact_policy_aggregate.renewal_count / policy_count
- KPI 4 Avg Premium → SUM(total_written_premium) / SUM(policy_count)
- KPI 5 Lapse Rate → anl_fact_policy_aggregate.lapse_count / policy_count
- KPI 6 30-Day Trend → anl_fact_policy_transaction JOIN anl_dim_date
- KPI 7 Top 5 Agents → anl_fact_policy_aggregate JOIN anl_dim_agent
- KPI 8 LOB Breakdown → anl_fact_policy_aggregate GROUP BY lob
- KPI 9 Hit Ratio → anl_fact_quote_summary (bound_count / total_quotes)

## Sign-Off Gate Process (ADDED v2)
- Gate: Hard stop before dashboard.html is generated
- Trigger: All 9 KPIs verified in verify_kpis() pass
- Action: Present sign-off screen with KPI table to stakeholder
- Unlock: User types APPROVED in chat
- Record: Sign-off timestamp written to grading/grade-records/signoff.md

## 3-Dashboard Output Spec (ADDED v2)
- OUTPUT 1: wiki.html — LLM Wiki (artifacts + Obsidian graph + knowledge base)
- OUTPUT 2: agent_demo.html — Agent Pipeline Demo (10 agents, grading, before/after diffs)
- OUTPUT 3: dashboard.html — Business Dashboard (9 KPIs, 5 LOB filter, 5 charts)

## Definition of Done (ADDED v2)
- LOB filter changes ALL 6 KPI cards + ALL 5 charts simultaneously
- All 9 KPIs show non-zero data for every LOB
- No external server required (file:// protocol works)
- Single self-contained HTML file per dashboard

## Gate
92/100 minimum. Graded by grading-agent.
