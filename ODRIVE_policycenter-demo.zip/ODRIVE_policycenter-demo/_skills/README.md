# Skills Directory — PC_DASHBOARD_DEMO_2025
All 12 agent SKILL.md files plus companion files.

| Skill | Type | Companion Files |
|-------|------|-----------------|
| grading-agent | Platform | rubric_template.md, grading_agent.md, 6×rubric_*.md |
| orchestrator | Platform | model_policy.json, fleet_config.json |
| obsidian-llm-wiki | Platform | wiki_structure.md |
| plan-agent | Delivery | epic_template.md, plan_config.json |
| grillmewithdocs | Delivery | SKILL_v2.md, brd_template.md, interview_protocol.md, guidewire_glossary_pointer.md |
| to-prd | Delivery | SKILL_v2.md, prd_template.md |
| schema-discovery | Delivery | SKILL_v2.md, catalog.json, schema_audit_template.md |
| dev-build | Delivery | etl_patterns.md, insert_patterns.md |
| tdd | Delivery | ac_template.md, test_runner.py, sample_ac_results.md |
| qa-100 | Delivery | SKILL_v2.md, integration_test_template.md |
| adf-pipeline | Delivery | pipeline_config.md, run_log.md, pc_etl_nightly.json |
| business-signoff | Delivery | signoff_template.md, kpi_checklist.md, kpi_presentation.md |
