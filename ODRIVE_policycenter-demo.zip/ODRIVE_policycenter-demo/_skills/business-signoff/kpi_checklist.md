# KPI Pre-Sign-Off Checklist
Before presenting to stakeholder, verify all items:
☑ All 9 KPIs return non-NULL, non-zero values from ANALYTICAL layer
☑ All 5 LOBs have data in anl_fact_policy_aggregate
☑ Hit ratio: Overall 40-75%, NB 30-65%, Renewal 70-95%
☑ 30-day trend has ≥10 data points
☑ tdd agent scored ≥92/100
☑ qa-100 agent scored ≥92/100
☑ Renewal Rate disclaimer disclosed (aggregate vs policy-level)
☑ PII handling documented (insured_name excluded from fact tables)
