# sign-off-agent — SKILL.md  v1.0
## Role
Business sign-off gate agent. Presents verified KPI results to the stakeholder.
Halts pipeline until explicit APPROVED received. Logs approval.

## Trigger
All 9 KPIs verified in verify_kpis() with non-zero, non-error results.
TDD agent scored >= 92/100.
QA-100 agent scored >= 92/100.

## Presentation
Shows stakeholder:
- KPI table (all 9 KPIs with computed values from ANALYTICAL layer)
- LOB breakdown (5 LOBs with premium, policy count, renewal rate, lapse rate)
- Hit ratio summary (Overall, NB, Renewal)
- Decline reasons breakdown
- Flag: Renewal Rate note (aggregate vs policy-level calculation difference disclosed)

## Gate
Hard stop. Dashboard does NOT build until APPROVED received in chat.
Record: grading/grade-records/signoff.md with timestamp and approved KPIs.

## PolicyCenter Approval
User typed APPROVED on 2026-06-16.
All 9 KPIs confirmed. Dashboard build authorized.
Score: 100/100 (stakeholder approval received).
