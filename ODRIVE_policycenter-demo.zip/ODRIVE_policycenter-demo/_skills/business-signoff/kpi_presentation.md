# KPI Presentation Format — business-signoff
## For CDO Sign-Off Meeting

### Slide 1: Pipeline Summary
- 12 agents executed
- All scores ≥ 92/100
- Loop agents: grillmewithdocs(2), to-prd(2), schema-discovery(2), qa-100(2)

### Slide 2: 9 KPI Results
| KPI | Value | On Target? |
|-----|-------|-----------|
| Total Premium Written | $13,962,087 | ✅ |
| Policy Count | 1,200 | ✅ |
| Renewal Rate | 38.9% | ✅ |
| Average Premium | $7,109 | ✅ |
| Lapse Rate | 1.83% | ✅ |
| 30-Day Trend | 25 points | ✅ |
| Top Agent | Thompson $856K | ✅ |
| Top LOB | Workers Comp $8.2M | ✅ |
| Hit Ratio | 58% overall | ✅ |

### Decision Required: APPROVE or REQUEST REVISION
