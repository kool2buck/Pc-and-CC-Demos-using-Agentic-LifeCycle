# obsidian-llm-wiki — SKILL.md  v1.0
## Role  (Second Brain Platform Agent)
Maintains the PolicyCenter Demo knowledge graph.
Everything the SDLC pipeline produces is indexed, linked, and queryable here.
The wiki.html renders this as an Obsidian-like interactive graph.

## What It Contains
### Agents (12 nodes)
grading-agent | orchestrator | obsidian-llm-wiki | plan-agent | grillmewithdocs
to-prd | schema-discovery | dev-build | tdd | qa-100 | adf-pipeline | business-signoff

### Artifacts (linked from agents that produced them)
BRD.md → grillmewithdocs
PRD.md → to-prd
Technical_Requirements.md → grillmewithdocs
Schema_Audit.md → schema-discovery
Data_Dictionary.md → dev-build
ETL_Pipeline_Architecture.md → dev-build
TEST_REPORT.md → tdd
QA_TEST_REPORT.md → qa-100
SIGNOFF_PACKAGE.md → business-signoff
dashboard.html → dev-build + business-signoff

### Glossary (shared across all projects)
glossary/policycenter.md   — 6 entities, typelists, PII flags
glossary/billingcenter.md  — 9 entities
glossary/claimscenter.md   — 7 entities

### Knowledge Base
etl_patterns.md | scd_types.md | grain_definitions.md
pii_masking.md  | dedup_strategies.md | lessons_learned.md

## Graph Rendering
wiki.html renders nodes as colored circles (agents=navy, artifacts=gold, glossary=green)
Edges show producer→artifact relationships
Click any node → shows the file content in right panel

## Gate
Self-managed platform agent. Validated by orchestrator.
