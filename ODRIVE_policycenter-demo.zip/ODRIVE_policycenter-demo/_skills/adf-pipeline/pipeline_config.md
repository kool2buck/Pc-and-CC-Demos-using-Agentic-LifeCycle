# ADF Pipeline Config — PolicyCenter Demo
## Pipeline: PC_ETL_NIGHTLY
Simulates Azure Data Factory pipeline for PolicyCenter → Snowflake analytical layer.

## Activities (in dependency order)
| Activity                  | Type    | Source         | Sink                    |
|---------------------------|---------|----------------|-------------------------|
| PC_Extract_To_Staging     | Copy    | PolicyCenter   | stg_* tables            |
| STG_To_RAW                | Script  | stg_* tables   | raw_* tables            |
| RAW_To_EXPLORATION        | Script  | raw_* tables   | exp_* tables            |
| EXP_To_CONFORMED          | Script  | exp_* tables   | conf_* tables           |
| CONF_To_ANALYTICAL        | Script  | conf_* tables  | anl_* tables            |
| ANL_To_DASHBOARD          | Trigger | anl_* tables   | dashboard.html          |

## Trigger: nightly 02:00 ET
## SLA: < 4 hours total runtime
## Alert: data-ops@donegal.com on failure

## Smoke Test (post-run AC)
All anl_ tables row count > 0 for current load_date.
