# adf-pipeline — SKILL.md  v1.0
## Role
ADF (Azure Data Factory) Pipeline Agent for PolicyCenter Demo.
Simulates the orchestration layer that would run this ETL in production on Azure.
Produces pipeline config, run logs, and smoke-test validation.

## What It Produces
- pipeline_config.json: ADF-style pipeline definition
- run_log.md: Simulated ADF pipeline run (all 5 layers + quote stream)
- smoke_test.md: Post-run validation (row counts, null checks, FK integrity)

## PolicyCenter Pipeline Activities
1. PC_Extract_To_Staging    → stg_policy, stg_quote, stg_transaction
2. STG_To_RAW               → raw_* (append-only, load_date stamped)
3. RAW_To_EXPLORATION       → exp_policy_enriched, exp_quote_enriched
4. EXP_To_CONFORMED         → conf_dim_*, conf_fact_transaction, conf_fact_quote
5. CONF_To_ANALYTICAL       → anl_dim_* (Type2 SCD), anl_fact_policy_transaction,
                               anl_fact_policy_aggregate, anl_fact_quote_summary
6. ANALYTICAL_To_DASHBOARD  → Triggers dashboard.html regeneration

## Smoke Test (post-run)
- SOURCE row count = STAGING row count (transactions: 3,975)
- RAW row count >= STAGING (append-only, always grows)
- ANALYTICAL fact rows > 0 for all 5 LOBs
- anl_fact_quote_summary bound_count <= total_quotes (sanity)
- Dashboard regenerated without errors

## Production Notes
- In Snowflake: replace Python sqlite3 with Snowflake Connector + CALL procedures
- In ADF: each layer = one pipeline with dataset + linked service
- Schedule: nightly at 02:00 ET (after PC batch close)
- Alert: email to data-ops@donegal.com if any activity fails

## Gate
92/100 minimum. Graded by grading-agent.
