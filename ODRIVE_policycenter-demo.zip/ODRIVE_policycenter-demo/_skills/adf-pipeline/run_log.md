# ADF Pipeline Run Log — PC_ETL_NIGHTLY
**Run ID:** PC-ETL-20260616-0200
**Status:** ✅ SUCCEEDED
**Start:** 2026-06-16 02:00:01 ET
**End:** 2026-06-16 02:47:33 ET
**Duration:** 47m 32s

## Activity Results
| Activity              | Status    | Duration | Rows Written |
|-----------------------|-----------|----------|--------------|
| PC_Extract_To_Staging | Succeeded | 3m 12s   | 3,975 txns   |
| STG_To_RAW            | Succeeded | 4m 51s   | 3,975 rows   |
| RAW_To_EXPLORATION    | Succeeded | 6m 22s   | 3,975 rows   |
| EXP_To_CONFORMED      | Succeeded | 11m 04s  | 3,975 + dims |
| CONF_To_ANALYTICAL    | Succeeded | 18m 44s  | 7,724 rows   |
| ANL_To_DASHBOARD      | Succeeded | 3m 19s   | 3 HTML files |

## Smoke Test: ✅ ALL PASS
