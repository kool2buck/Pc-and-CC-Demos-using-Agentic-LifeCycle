# schema-discovery — SKILL.md  v2.0  ← REVISED AFTER LOOP 1 FAILURE (91/100)
## Role
Discovers and documents the PolicyCenter source schema including quote binding relationships.

## Tables Discovered
| Table              | PK             | Row Count | Notes                        |
|--------------------|----------------|-----------|------------------------------|
| pc_agent           | agent_id       | 25        | 5 agencies, 4 regions        |
| pc_product         | product_id     | 5         | One per LOB                  |
| pc_policy          | policy_id      | 1,200     | 5 LOBs, 8 states             |
| pc_policy_period   | period_id      | 1,964     | 1-2 terms per policy         |
| pc_transaction     | transaction_id | 3,975     | NB, Renewal, Endorsement, Cancel |
| pc_quote           | quote_id       | 3,384     | 1,964 bound, 1,420 unbound   |

## FK Relationships (COMPLETE — ADDED v2)
- pc_policy.agent_id       → pc_agent.agent_id
- pc_policy.product_id     → pc_product.product_id
- pc_policy_period.policy_id → pc_policy.policy_id
- pc_transaction.policy_id → pc_policy.policy_id
- pc_transaction.period_id → pc_policy_period.period_id
- pc_transaction.agent_id  → pc_agent.agent_id
- pc_quote.policy_id       → pc_policy.policy_id (NULLABLE — NULL when not bound)
- pc_quote.agent_id        → pc_agent.agent_id
- pc_quote.product_id      → pc_product.product_id

## Nullable Fields (ADDED v2)
- pc_quote.policy_id: NULL when quote is Declined/Expired/InProgress
- pc_quote.decline_reason: NULL when status = 'Bound'
- pc_quote.bound_date: NULL when status != 'Bound'

## Key Business Rule (ADDED v2)
A pc_quote becomes a pc_policy when status = 'Bound'.
The pc_quote.policy_id links the two records.
Hit Ratio = bound quotes / total quotes (by LOB, agent, month, quote_type).

## Data Quality Flags
- pc_transaction.premium_amount can be negative (endorsements, cancellations)
- pc_quote.quoted_premium always positive
- pc_policy_period.written_premium always positive

## Gate
92/100 minimum. Graded by grading-agent.
