# Schema Audit Template — schema-discovery

## Section 1: Source Table Inventory
| Table | PK | Rows | FK Count | PII Fields |

## Section 2: FK Relationship Map
Diagram: table.column → table.column (NULLABLE if applicable)

## Section 3: Data Quality Findings
### Nullables (expected)
### Nullables (unexpected — investigate)

## Section 4: PolicyCenter-Specific Patterns
### Fan-out Risk
### Effective Dating
### Typelist Columns

## Section 5: DW Design Implications
### For STAGING
### For RAW
### For EXPLORATION
### For CONFORMED
### For ANALYTICAL
