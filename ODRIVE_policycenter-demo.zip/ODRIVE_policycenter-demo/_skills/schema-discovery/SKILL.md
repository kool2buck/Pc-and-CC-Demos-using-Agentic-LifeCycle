# schema-discovery — SKILL.md  v1.0  ← FIRST SUBMISSION (WILL FAIL)
## Role
Discovers and documents the PolicyCenter source schema, all tables, PKs, FKs, types.

## Tables Discovered
| Table              | PK             | Row Count |
|--------------------|----------------|-----------|
| pc_agent           | agent_id       | 25        |
| pc_product         | product_id     | 5         |
| pc_policy          | policy_id      | 1,200     |
| pc_policy_period   | period_id      | 1,964     |
| pc_transaction     | transaction_id | 3,975     |
| pc_quote           | quote_id       | 3,384     |

## FK Relationships (INCOMPLETE — WILL CAUSE FAILURE)
- pc_policy.agent_id → pc_agent.agent_id
- pc_policy.product_id → pc_product.product_id
- pc_policy_period.policy_id → pc_policy.policy_id
- pc_transaction.policy_id → pc_policy.policy_id
- pc_transaction.agent_id → pc_agent.agent_id
- [MISSING: pc_quote FK relationships]

## Gate
92/100 minimum. Graded by grading-agent.
