# orchestrator — SKILL.md  v1.0
## Role
Fleet allocation and pipeline state manager for PolicyCenter Demo.
Sequences agent execution, manages token budget, tracks gate passage.

## Agent Sequence (with dependencies)
Step 1: plan-agent         (no dependency)
Step 2: ba-grill           (after plan-agent PASS)
Step 3: to-prd             (after ba-grill PASS)
Step 4: schema-discovery   (parallel with ba-grill)
Step 5: dev-build          (after to-prd + schema-discovery PASS)
Step 6: tdd                (after dev-build PASS)
Step 7: qa-100             (after dev-build PASS, parallel with tdd)
Step 8: grading-agent      (scores each agent as submitted)
Step 9: sign-off-agent     (after tdd + qa-100 PASS)
Step 10: dashboard builds  (after sign-off-agent APPROVED)

## Token Budget Policy
- plan-agent:      claude-haiku-4-5  (simple structure task)
- ba-grill:        claude-sonnet-4-6 (nuanced interview logic)
- to-prd:          claude-sonnet-4-6 (structured output)
- schema-discovery: claude-haiku-4-5 (deterministic SQL queries)
- dev-build:       claude-sonnet-4-6 (complex ETL logic)
- tdd:             claude-haiku-4-5  (deterministic test execution)
- qa-100:          claude-haiku-4-5  (deterministic SQL checks)
- grading-agent:   claude-sonnet-4-6 (judgment + rubric scoring)
- sign-off-agent:  claude-sonnet-4-6 (stakeholder presentation)
- orchestrator:    claude-haiku-4-5  (state tracking)

## Pipeline State
Tracked in: grading/grade-records/pipeline_state.md
- Each agent: NOT_STARTED | IN_PROGRESS | FAIL_LOOP_{n} | PASS
- Gate passed: YES/NO with score

## Gate
96/100. Self-graded. Orchestrator validates own completeness.
