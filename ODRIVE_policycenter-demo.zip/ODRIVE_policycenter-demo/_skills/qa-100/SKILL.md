# qa-100 — SKILL.md  v1.0  ← FIRST SUBMISSION (WILL FAIL)
## Role
Integration testing agent. Verifies full pipeline integrity end-to-end.

## Integration Tests
QA-001: Row count consistency — SOURCE == STAGING == RAW (transactions)
QA-002: No orphaned policy_keys in anl_fact_policy_transaction
QA-003: No orphaned agent_keys in anl_fact_policy_transaction
QA-004: Quote binding integrity — all bound quotes have a valid policy_id
QA-005: anl_dim_agent is_current=1 count matches pc_agent count
QA-006: anl_dim_policy is_current=1 count matches pc_policy count
QA-007: SUM(premium) consistent between conf and anl layers (within 0.01%)
QA-008: anl_fact_quote_summary totals match raw_quote counts

## Gaps (WILL CAUSE FAILURE)
- No cross-LOB distribution test (LOB % in analytical should match source)
- No test for Type 2 SCD correctness (only is_current=1 rows should be used)
- No negative premium guard (endorsements/cancellations could corrupt aggregates)

## Gate
92/100 minimum. Graded by grading-agent.
