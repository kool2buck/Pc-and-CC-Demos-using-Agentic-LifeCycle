# qa-100 — SKILL.md  v2.0  ← REVISED AFTER LOOP 1 FAILURE (89/100)
## Role
Integration testing agent. Verifies full pipeline integrity end-to-end.

## Integration Tests (Complete)
QA-001: Row count consistency — SOURCE == STAGING == RAW (transactions)
QA-002: No orphaned policy_keys in anl_fact_policy_transaction
QA-003: No orphaned agent_keys in anl_fact_policy_transaction
QA-004: Quote binding integrity — all bound quotes have a valid policy_id
QA-005: anl_dim_agent is_current=1 count matches pc_agent count (25)
QA-006: anl_dim_policy is_current=1 count matches pc_policy count (1,200)
QA-007: SUM(premium) consistent between conf and anl layers (within 0.01%)
QA-008: anl_fact_quote_summary totals match raw_quote counts

## Additional Tests (ADDED v2)
QA-009 [NEW]: Cross-LOB distribution — each LOB's policy % in anl_fact_policy_aggregate
              matches pc_policy LOB distribution (within ±2%)
QA-010 [NEW]: Type 2 SCD guard — zero rows with is_current=1 AND eff_end IS NOT NULL
              in anl_dim_agent and anl_dim_policy
QA-011 [NEW]: Negative premium guard — anl_fact_policy_aggregate.total_written_premium
              must be > 0 for all rows (endorsement/cancellation amounts must not dominate)
QA-012 [NEW]: Hit ratio sanity — anl_fact_quote_summary bound_count never > total_quotes

## Gate
92/100 minimum. Graded by grading-agent.
