# Integration Test Template — qa-100
## Format
QA-NNN: [Description]
- SQL: [verification query]
- Expected: [condition]
- Actual: [result]
- Status: PASS / FAIL

## 12 Integration Tests for PC_DASHBOARD_DEMO
QA-001: SOURCE == STAGING row count (transactions)
QA-002: No orphaned policy_keys in anl_fact_policy_transaction
QA-003: No orphaned agent_keys in anl_fact_policy_transaction
QA-004: Bound quotes all have valid policy_id
QA-005: anl_dim_agent is_current=1 count = pc_agent count (25)
QA-006: anl_dim_policy is_current=1 count = pc_policy count (1200)
QA-007: SUM(premium) conformed vs analytical within 0.01%
QA-008: anl_fact_quote_summary totals match raw_quote counts
QA-009: Cross-LOB distribution within ±2% of source
QA-010: Type 2 SCD: zero rows with is_current=1 AND eff_end IS NOT NULL
QA-011: Negative premium guard: all agg rows total_written_premium > 0
QA-012: Hit ratio sanity: bound_count never > total_quotes
