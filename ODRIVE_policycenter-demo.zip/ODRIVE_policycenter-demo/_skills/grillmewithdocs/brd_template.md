# BRD Template — GrillMeWithDocs Output Format
## Document Control
| Field           | Value                              |
|-----------------|------------------------------------|
| Project Name    | [Name]                             |
| BRD Version     | [n.n]                              |
| Date            | [YYYY-MM-DD]                       |
| Produced By     | GrillMeWithDocs Agent              |
| Domain          | [PolicyCenter/BillingCenter/ClaimsCenter] |
| Status          | Draft → Pending Grading Agent Review |

## Section 1: Executive Summary
### 1.1 Business Problem
### 1.2 Proposed Solution
### 1.3 Business Value
### 1.4 Timeline

## Section 2: Business Scope
### 2.1 In Scope (LOBs, entities, KPIs)
### 2.2 Out of Scope
### 2.3 Assumptions
### 2.4 Constraints

## Section 3: Data Requirements
### 3.1 Source System
### 3.2 Source Tables and Grain
### 3.3 KPI Definitions (formula, grain, filter)
### 3.4 LOB-Specific Rules

## Section 4: Non-Functional Requirements
### 4.1 PII Handling
### 4.2 Architecture Constraints
### 4.3 Sign-Off Gate

## Section 5: Acceptance Criteria
### 5.1 KPI Acceptance Tests
### 5.2 Pipeline Acceptance Tests
### 5.3 Dashboard Acceptance Tests

## Section 10: Glossary
[Terms loaded from glossary/policycenter.md]

## Self-Score Block (submitted to grading-agent)
[Score per rubric category]
