# Guidewire Glossary Pointer
## Path
glossary/policycenter.md — PolicyCenter entity metadata
glossary/billingcenter.md — BillingCenter entity metadata
glossary/claimscenter.md  — ClaimsCenter entity metadata

## Fallback
If glossary files not found, agent uses trained Guidewire knowledge
and flags BRD Section 10 as "based on standard definitions — verify against implementation."
