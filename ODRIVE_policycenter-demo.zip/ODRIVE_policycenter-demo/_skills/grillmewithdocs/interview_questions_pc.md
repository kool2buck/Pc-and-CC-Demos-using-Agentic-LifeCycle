# GrillMeWithDocs — PolicyCenter-Specific Interview Questions
## Phase 2 Deep Dive (PolicyCenter Only)

### Quote-to-Bind Questions
Q: Is pc_quote available in your implementation? (Not all Donegal centers use Quote module)
Q: Is quote_type tracked as NewBusiness vs Renewal?
Q: What is the expected overall hit ratio? (For AC validation range setting)
Q: Which decline reasons should be tracked in the dashboard?

### LOB-Specific Questions
Q: Are all 5 LOBs active in PolicyCenter? (WorkersComp sometimes in separate system)
Q: Which LOBs use endorsements? (Affects negative premium handling)
Q: Are commercial lines in the same PC instance as personal lines?

### Agent/Agency Questions
Q: Do agents move agencies? (Affects Type 2 SCD decision on anl_dim_agent)
Q: Is agent commission tracked in pc_transaction?
Q: Are there inactive agents in pc_agent? (Affects policy count accuracy)
