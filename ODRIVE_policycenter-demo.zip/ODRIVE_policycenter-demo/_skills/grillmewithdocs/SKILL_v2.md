# grillmewithdocs — SKILL.md  v2.0  ← REVISED AFTER LOOP 1 FAILURE (86/100)
## Role
Business Analyst interrogator for PolicyCenter Dashboard Demo.
Grills stakeholder to extract complete, unambiguous technical requirements.

## Interview Protocol
Ask about each KPI until grain, calculation logic, edge cases, AND validation ranges are pinned.

## KPIs Extracted (Complete)
1. Total Premium Written — SUM(written_premium) from pc_policy_period, all terms
2. Policy Count — COUNT(DISTINCT policy_id), includes active + expired
3. Renewal Rate — SUM(renewal_flag=1)/COUNT(DISTINCT policy_id), period-level
4. Average Premium — SUM(written_premium)/SUM(policy_count), weighted
5. Lapse Rate — SUM(lapse_flag)/COUNT(DISTINCT policy_id), policy-level
6. 30-Day Trend — SUM(premium_amount) WHERE txn_type IN (NewBusiness, Renewal), daily GROUP BY
7. Top 5 Agents — SUM(total_written_premium) from anl_fact_policy_aggregate, rank DESC
8. Premium by LOB — SUM(total_written_premium) GROUP BY lob, all 5 LOBs required
9. Hit Ratio — SUM(bound_count)/SUM(total_quotes); split by NewBusiness vs Renewal

## Grain Definitions (ADDED v2)
- pc_quote: one row per quote event (quote_id is PK, policy_id NULL if not bound)
- pc_policy_period: one row per policy per term (period_id is PK)
- pc_transaction: one row per financial transaction (transaction_id is PK)
- anl_fact_quote_summary: agent × LOB × quote_type × year × month

## LOB Premium Validation Ranges (ADDED v2)
- PersonalAuto: $800–$2,500
- Homeowners: $1,000–$3,500
- CommercialAuto: $3,000–$15,000
- DwellingFire: $600–$2,000
- WorkersComp: $5,000–$50,000

## PII Rules (ADDED v2)
- insured_name: present in SOURCE and STAGING only
- EXPLORATION layer: insured_name carried through for DS use (flagged PII)
- CONFORMED + ANALYTICAL: insured_name excluded from fact tables, present in dim_policy only
- Masking: Not required for demo; note for production SOX compliance

## Renewal Quote Distinction (ADDED v2)
- pc_quote.quote_type = 'NewBusiness' | 'Renewal'
- Hit Ratio reported separately for each type; overall = combined
- Renewal hit ratio expected 70–95%, NB hit ratio expected 30–60%

## Gate
92/100 minimum. Graded by grading-agent.
