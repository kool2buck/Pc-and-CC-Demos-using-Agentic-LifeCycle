# grillmewithdocs — SKILL.md  v1.0  ← FIRST SUBMISSION (WILL FAIL)
## Role
Business Analyst interrogator for PolicyCenter Dashboard Demo.
Grills stakeholder to extract complete, unambiguous technical requirements.

## Interview Protocol
Ask about each KPI until grain, calculation logic, and edge cases are pinned.

## KPIs Extracted
1. Total Premium Written — SUM(written_premium) from pc_policy_period
2. Policy Count — COUNT(DISTINCT policy_id) from pc_policy
3. Renewal Rate — SUM(renewal_flag)/COUNT(period_id) from pc_policy_period
4. Average Premium — AVG(written_premium) from pc_policy_period
5. Lapse Rate — SUM(lapse_flag)/COUNT(policy_id) from pc_policy
6. 30-Day Premium Trend — daily SUM(premium_amount) last 30 days
7. Premium by Agent Top 5 — SUM(written_premium) GROUP BY agent_id
8. Premium by LOB — SUM(written_premium) GROUP BY lob
9. Hit Ratio — SUM(is_bound)/COUNT(quote_id) from pc_quote

## LOBs
PersonalAuto, Homeowners, CommercialAuto, DwellingFire, WorkersComp

## Gaps (WILL CAUSE FAILURE)
- Quote grain not defined (what is one row in pc_quote?)
- LOB-specific premium validation ranges not specified
- PII field insured_name handling not addressed
- Renewal quote vs new business quote distinction missing

## Gate
92/100 minimum. Graded by grading-agent.
