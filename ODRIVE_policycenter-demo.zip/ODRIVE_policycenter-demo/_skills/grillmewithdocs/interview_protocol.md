# GrillMeWithDocs — Interview Protocol
## Phase 0: Load Context
Load Guidewire glossary for PolicyCenter from glossary/policycenter.md.
Load any uploaded BRD drafts or business documents.

## Phase 1: Project Scope (Q1.1–Q1.5)
Q1.1 What Guidewire system is the source? (PolicyCenter / BillingCenter / ClaimsCenter)
Q1.2 Which Lines of Business are in scope?
Q1.3 What is the primary business question this project answers?
Q1.4 Who is the primary consumer of the output? (Actuarial / Underwriting / Finance / Executive)
Q1.5 What is the go-live timeline?

## Phase 2: KPI Definitions (Q2.1–Q2.9)
For each KPI: formula, grain, filter conditions, edge cases, LOB applicability.
Q2.1 Total Premium Written
Q2.2 Policy Count
Q2.3 Renewal Rate
Q2.4 Average Premium per Policy
Q2.5 Lapse Rate
Q2.6 30-Day Premium Trend
Q2.7 Top 5 Agents by Premium
Q2.8 Premium by LOB
Q2.9 Hit Ratio (Quote to Bind)

## Phase 3: Data Quality & PII
Q3.1 Which fields contain PII? (insured_name, address, SSN, DOB)
Q3.2 PII handling: mask in EXPLORATION? exclude from ANALYTICAL?
Q3.3 What are the LOB-specific premium validation ranges?

## Phase 4: Architecture Constraints
Q4.1 5-layer ETL confirmed (STAGING→RAW→EXPLORATION→CONFORMED→ANALYTICAL)?
Q4.2 Explicit INSERT statements only (no CTAS)?
Q4.3 Sign-off gate: hard stop before dashboard generates?
Q4.4 3 output dashboards: Wiki / Agent Demo / Business Dashboard?
