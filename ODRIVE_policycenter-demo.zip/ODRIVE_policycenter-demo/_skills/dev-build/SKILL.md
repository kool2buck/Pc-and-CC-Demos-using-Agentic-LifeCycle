# dev-build — SKILL.md  v1.0
## Role
ETL build agent for the PolicyCenter Demo pipeline.
Implements all 5 layers + quote stream using explicit INSERT statements only (no CTAS).

## Architecture
SOURCE → STAGING → RAW → EXPLORATION → CONFORMED → ANALYTICAL

## Files Produced
- 01_build_pipeline.py  (SOURCE + all 5 layers, 1,200 policies)
- 01b_add_quotes.py     (pc_quote source + stg/raw/exp/conf/anl quote tables)
- 02_build_dashboard.py (queries analytical layer, generates dashboard.html)

## Tables per Layer
STAGING  (5): stg_agent, stg_product, stg_policy, stg_policy_period, stg_transaction
RAW      (5): raw_agent, raw_product, raw_policy, raw_policy_period, raw_transaction
EXPLORATION (2): exp_policy_enriched, exp_transaction_enriched
CONFORMED (5): conf_dim_agent, conf_dim_product, conf_dim_date, conf_dim_policy, conf_fact_transaction
ANALYTICAL (6): anl_dim_agent (Type2), anl_dim_policy (Type2), anl_dim_product, anl_dim_date, anl_fact_policy_transaction, anl_fact_policy_aggregate

QUOTE STREAM per layer:
STAGING: stg_quote | RAW: raw_quote | EXPLORATION: exp_quote_enriched
CONFORMED: conf_fact_quote | ANALYTICAL: anl_fact_quote_summary

## Constraints
- All layer transitions: explicit INSERT INTO ... SELECT FROM (never CTAS)
- RAW: append-only, dedup on load_date to prevent re-loads
- ANALYTICAL dim_agent + dim_policy: Type 2 SCD (eff_start, eff_end, is_current)
- anl_fact_quote_summary: grain = agent_key × product_key × year × month × lob × quote_type

## Acceptance Criteria
- SOURCE row counts: 1,200 policies, 1,964 periods, 3,975 transactions, 3,384 quotes
- ANALYTICAL row counts: 3,975 txn fact rows, 1,471+ agg rows, 2,278+ quote summary rows
- All 9 KPIs computable from ANALYTICAL layer alone

## Gate
92/100 minimum. Graded by grading-agent.
