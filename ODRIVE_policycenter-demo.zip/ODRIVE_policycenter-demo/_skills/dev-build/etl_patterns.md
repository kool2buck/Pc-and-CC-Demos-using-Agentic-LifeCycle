# ETL Patterns — PolicyCenter Demo
## Rule 1: No CTAS
Always CREATE TABLE first, then INSERT INTO ... SELECT FROM.

## Rule 2: RAW is Append-Only
Never TRUNCATE or DELETE from raw_* tables.
Use NOT EXISTS guard on load_date to prevent re-loads.

## Rule 3: Type 2 SCD
anl_dim_agent and anl_dim_policy are Type 2 SCD.
Fields: eff_start, eff_end (NULL when current), is_current (1/0).

## Rule 4: Grain
- STAGING: same grain as source
- RAW: source grain + load_date
- EXPLORATION: joined, enriched, one row per source event
- CONFORMED: dimensional grain (dim_* are 1:1 with source entity)
- ANALYTICAL: fact_policy_transaction = 1 row per transaction_id
               fact_policy_aggregate  = 1 row per agent×LOB×year×month
               fact_quote_summary     = 1 row per agent×LOB×quote_type×year×month

## Rule 5: Negative Premiums
Endorsements and cancellations have negative premium_amount.
anl_fact_policy_aggregate.total_written_premium must be positive (NB/Renewal dominate).
