# INSERT Patterns — dev-build Reference
## Explicit INSERT only. No CTAS. Ever.

### Pattern: Staging (fresh extract)
```sql
DROP TABLE IF EXISTS stg_policy;
CREATE TABLE stg_policy (col1 TYPE, col2 TYPE, ..., stg_load_date TEXT);
INSERT INTO stg_policy (col1, col2, ..., stg_load_date)
SELECT col1, col2, ..., :load_date FROM pc_policy;
```

### Pattern: RAW (append-only with dedup)
```sql
CREATE TABLE IF NOT EXISTS raw_policy (col1 TYPE, ..., load_date TEXT);
INSERT INTO raw_policy (col1, ..., load_date)
SELECT col1, ..., :load_date FROM stg_policy
WHERE NOT EXISTS (
    SELECT 1 FROM raw_policy r
    WHERE r.policy_id = stg_policy.policy_id AND r.load_date = :load_date
);
```

### Pattern: Aggregate Fact
```sql
DROP TABLE IF EXISTS anl_fact_policy_aggregate;
CREATE TABLE anl_fact_policy_aggregate (agg_key INTEGER PRIMARY KEY AUTOINCREMENT, ...);
INSERT INTO anl_fact_policy_aggregate (agent_key, ..., load_date)
SELECT aa.agent_key, ..., :load_date
FROM raw_policy_period pp
JOIN raw_policy p ON pp.policy_id = p.policy_id
JOIN anl_dim_agent aa ON p.agent_id = aa.agent_id AND aa.is_current = 1
JOIN anl_dim_product adp ON p.product_id = adp.product_id
WHERE pp.load_date = :load_date AND p.load_date = :load_date
GROUP BY aa.agent_key, adp.product_key, strftime('%Y', pp.effective_date), ...;
```
