#!/usr/bin/env python3
"""
Donegal Insurance — PolicyCenter Demo
ETL Pipeline: SOURCE → STAGING → RAW → EXPLORATION → CONFORMED → ANALYTICAL
Scale: Medium (1,200 policies, ~5,000 transactions)
LOBs: PersonalAuto, Homeowners, CommercialAuto, DwellingFire, WorkersComp
"""
import sqlite3, random, os
from datetime import datetime, timedelta

# ─────────────────────────────────────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────────────────────────────────────
OUTPUT_DIR  = '/home/claude/policycenter_demo'
DB_PATH     = f'{OUTPUT_DIR}/policycenter.db'
LOAD_DATE   = datetime.now().strftime('%Y-%m-%d')
TODAY       = datetime.now()
TODAY_STR   = TODAY.strftime('%Y-%m-%d')
NUM_POLICIES = 1200
NUM_AGENTS   = 25
random.seed(42)

LOBS = {
    'PersonalAuto':   {'prem_range': (800,   2500),  'commission': 0.12, 'product_id': 'PRD001', 'code': 'PA'},
    'Homeowners':     {'prem_range': (1000,  3500),  'commission': 0.10, 'product_id': 'PRD002', 'code': 'HO'},
    'CommercialAuto': {'prem_range': (3000,  15000), 'commission': 0.10, 'product_id': 'PRD003', 'code': 'CA'},
    'DwellingFire':   {'prem_range': (600,   2000),  'commission': 0.12, 'product_id': 'PRD004', 'code': 'DF'},
    'WorkersComp':    {'prem_range': (5000,  50000), 'commission': 0.08, 'product_id': 'PRD005', 'code': 'WC'},
}
LOB_NAMES   = list(LOBS.keys())
LOB_WEIGHTS = [0.25, 0.25, 0.20, 0.15, 0.15]
STATES      = ['PA', 'VA', 'MD', 'NY', 'NJ', 'DE', 'OH', 'WV']
REGIONS     = ['Northeast', 'Southeast', 'Midwest', 'Mid-Atlantic']

def r2(v): return round(v, 2)
def step(m): print(f"\n{'─'*62}\n▶  {m}")
def ok(m):   print(f"   ✅  {m}")

# ─────────────────────────────────────────────────────────────────────────────
# PHASE 1 — SOURCE
# ─────────────────────────────────────────────────────────────────────────────
def build_source(conn):
    step("PHASE 1 — SOURCE: PolicyCenter source tables")
    c = conn.cursor()
    c.executescript("""
        DROP TABLE IF EXISTS pc_transaction;
        DROP TABLE IF EXISTS pc_policy_period;
        DROP TABLE IF EXISTS pc_policy;
        DROP TABLE IF EXISTS pc_product;
        DROP TABLE IF EXISTS pc_agent;

        CREATE TABLE pc_agent (
            agent_id     TEXT PRIMARY KEY,
            agent_name   TEXT NOT NULL,
            agency_name  TEXT NOT NULL,
            region       TEXT NOT NULL,
            state        TEXT NOT NULL,
            created_date TEXT NOT NULL
        );
        CREATE TABLE pc_product (
            product_id   TEXT PRIMARY KEY,
            lob          TEXT NOT NULL,
            product_name TEXT NOT NULL,
            product_code TEXT NOT NULL
        );
        CREATE TABLE pc_policy (
            policy_id     TEXT PRIMARY KEY,
            policy_number TEXT NOT NULL,
            product_id    TEXT NOT NULL,
            lob           TEXT NOT NULL,
            agent_id      TEXT NOT NULL,
            insured_name  TEXT NOT NULL,
            state         TEXT NOT NULL,
            status        TEXT NOT NULL,
            created_date  TEXT NOT NULL
        );
        CREATE TABLE pc_policy_period (
            period_id       TEXT PRIMARY KEY,
            policy_id       TEXT NOT NULL,
            term_number     INTEGER NOT NULL,
            effective_date  TEXT NOT NULL,
            expiration_date TEXT NOT NULL,
            written_premium REAL NOT NULL,
            renewal_flag    INTEGER NOT NULL DEFAULT 0,
            lapse_flag      INTEGER NOT NULL DEFAULT 0,
            status          TEXT NOT NULL
        );
        CREATE TABLE pc_transaction (
            transaction_id    TEXT PRIMARY KEY,
            policy_id         TEXT NOT NULL,
            period_id         TEXT NOT NULL,
            agent_id          TEXT NOT NULL,
            lob               TEXT NOT NULL,
            transaction_type  TEXT NOT NULL,
            transaction_date  TEXT NOT NULL,
            premium_amount    REAL NOT NULL,
            commission_rate   REAL NOT NULL,
            commission_amount REAL NOT NULL
        );
    """)

    # Agents
    fn = ['James','Mary','John','Patricia','Robert','Jennifer','Michael','Linda','William','Barbara',
          'David','Susan','Richard','Jessica','Joseph','Sarah','Thomas','Karen','Charles','Lisa',
          'Christopher','Nancy','Daniel','Betty','Matthew']
    ln = ['Smith','Johnson','Williams','Brown','Jones','Garcia','Miller','Davis','Wilson','Anderson',
          'Taylor','Thomas','Hernandez','Moore','Martin','Jackson','Thompson','White','Lopez','Lee',
          'Gonzalez','Harris','Clark','Lewis','Robinson']
    agents = []
    for i in range(1, NUM_AGENTS+1):
        d = (TODAY - timedelta(days=random.randint(500,1000))).strftime('%Y-%m-%d')
        agents.append((f'AGT{i:03d}', f'{fn[i-1]} {ln[i-1]}',
                       f'Donegal Agency {((i-1)//5)+1}',
                       REGIONS[(i-1)%len(REGIONS)], STATES[(i-1)%len(STATES)], d))
    c.executemany("INSERT INTO pc_agent VALUES (?,?,?,?,?,?)", agents)

    # Products
    prods = [(cfg['product_id'], lob, lob, cfg['code']) for lob, cfg in LOBS.items()]
    c.executemany("INSERT INTO pc_product VALUES (?,?,?,?)", prods)

    # Policies / Periods / Transactions
    fi = ['Alice','Bob','Carol','Dave','Eve','Frank','Grace','Hank','Iris','Jack',
          'Kate','Leo','Mia','Ned','Olivia','Pete','Quinn','Rita','Sam','Tara',
          'Uma','Victor','Wendy','Xavier','Yara','Zoe','Aaron','Beth','Carl','Diana']
    li = ['Adams','Baker','Cooper','Davis','Evans','Fisher','Green','Hall','Ingram','Jones',
          'King','Lewis','Moore','Nelson','Owen','Parker','Quinn','Reed','Stone','Taylor',
          'Upton','Vance','Ward','Young','Zhang','Allen','Burns','Chase','Dean','Ellis']

    pol_rows, per_rows, txn_rows = [], [], []
    pctr = 1; txctr = 1

    for n in range(1, NUM_POLICIES+1):
        pol_id  = f'POL{n:06d}'
        pol_num = f'DNG-{random.randint(100000,999999)}'
        lob     = random.choices(LOB_NAMES, weights=LOB_WEIGHTS)[0]
        cfg     = LOBS[lob]
        agt_id  = f'AGT{random.randint(1,NUM_AGENTS):03d}'
        insured = f'{random.choice(fi)} {random.choice(li)}'
        state   = random.choice(STATES)
        n_terms = random.choices([1,2], weights=[0.38,0.62])[0]
        first_eff = TODAY - timedelta(days=random.randint(365,730))
        pol_status = 'Active'

        for term in range(1, n_terms+1):
            per_id = f'PER{pctr:07d}'; pctr += 1
            eff    = first_eff + timedelta(days=365*(term-1))
            exp    = eff + timedelta(days=365)
            prem   = r2(random.uniform(*cfg['prem_range']))
            renewal_flag = 1 if term > 1 else 0
            lapse_flag   = 0

            if term == n_terms:
                if exp > TODAY:
                    per_status = 'Active'
                elif random.random() < 0.08:
                    lapse_flag = 1
                    per_status = 'Cancelled'
                    pol_status = 'NonRenewed' if term > 1 else 'Cancelled'
                else:
                    per_status = 'Expired'
                    if term == 1: pol_status = 'Expired'
            else:
                per_status = 'Expired'

            per_rows.append((per_id, pol_id, term,
                             eff.strftime('%Y-%m-%d'), exp.strftime('%Y-%m-%d'),
                             prem, renewal_flag, lapse_flag, per_status))

            # Main transaction
            main_type = 'Renewal' if renewal_flag else 'NewBusiness'
            txn_dt = (eff + timedelta(days=random.randint(0,5))).strftime('%Y-%m-%d')
            comm   = cfg['commission']
            txn_rows.append((f'TXN{txctr:08d}', pol_id, per_id, agt_id, lob,
                             main_type, txn_dt, prem, comm, r2(prem*comm)))
            txctr += 1

            # Endorsements (0-3 per term)
            n_end = random.choices([0,1,2,3], weights=[0.22,0.40,0.28,0.10])[0]
            for _ in range(n_end):
                end_dt = eff + timedelta(days=random.randint(30,330))
                if end_dt > TODAY: continue
                ep = r2(random.uniform(-300, 700))
                txn_rows.append((f'TXN{txctr:08d}', pol_id, per_id, agt_id, lob,
                                 'Endorsement', end_dt.strftime('%Y-%m-%d'),
                                 ep, comm, r2(ep*comm)))
                txctr += 1

            # Cancellation if lapsed
            if lapse_flag:
                can_dt = (eff + timedelta(days=random.randint(60,300))).strftime('%Y-%m-%d')
                cp = r2(-prem * random.uniform(0.3, 0.7))
                txn_rows.append((f'TXN{txctr:08d}', pol_id, per_id, agt_id, lob,
                                 'Cancellation', can_dt, cp, comm, r2(cp*comm)))
                txctr += 1

        pol_rows.append((pol_id, pol_num, cfg['product_id'], lob, agt_id,
                         insured, state, pol_status, first_eff.strftime('%Y-%m-%d')))

    c.executemany("INSERT INTO pc_policy VALUES (?,?,?,?,?,?,?,?,?)", pol_rows)
    c.executemany("INSERT INTO pc_policy_period VALUES (?,?,?,?,?,?,?,?,?)", per_rows)
    c.executemany("INSERT INTO pc_transaction VALUES (?,?,?,?,?,?,?,?,?,?)", txn_rows)
    conn.commit()
    ok(f"{len(pol_rows):,} policies | {len(per_rows):,} periods | {len(txn_rows):,} transactions")
    return len(txn_rows)

# ─────────────────────────────────────────────────────────────────────────────
# PHASE 2 — STAGING  (1:1 extract, fresh each load)
# ─────────────────────────────────────────────────────────────────────────────
def build_staging(conn):
    step("PHASE 2 — STAGING: 1:1 extract, fresh each load")
    c = conn.cursor()
    c.executescript(f"""
        DROP TABLE IF EXISTS stg_agent;
        CREATE TABLE stg_agent (
            agent_id TEXT, agent_name TEXT, agency_name TEXT, region TEXT,
            state TEXT, created_date TEXT, stg_load_date TEXT
        );
        INSERT INTO stg_agent
        SELECT agent_id, agent_name, agency_name, region, state, created_date, '{LOAD_DATE}'
        FROM pc_agent;

        DROP TABLE IF EXISTS stg_product;
        CREATE TABLE stg_product (
            product_id TEXT, lob TEXT, product_name TEXT, product_code TEXT, stg_load_date TEXT
        );
        INSERT INTO stg_product
        SELECT product_id, lob, product_name, product_code, '{LOAD_DATE}'
        FROM pc_product;

        DROP TABLE IF EXISTS stg_policy;
        CREATE TABLE stg_policy (
            policy_id TEXT, policy_number TEXT, product_id TEXT, lob TEXT, agent_id TEXT,
            insured_name TEXT, state TEXT, status TEXT, created_date TEXT, stg_load_date TEXT
        );
        INSERT INTO stg_policy
        SELECT policy_id, policy_number, product_id, lob, agent_id,
               insured_name, state, status, created_date, '{LOAD_DATE}'
        FROM pc_policy;

        DROP TABLE IF EXISTS stg_policy_period;
        CREATE TABLE stg_policy_period (
            period_id TEXT, policy_id TEXT, term_number INTEGER, effective_date TEXT,
            expiration_date TEXT, written_premium REAL, renewal_flag INTEGER,
            lapse_flag INTEGER, status TEXT, stg_load_date TEXT
        );
        INSERT INTO stg_policy_period
        SELECT period_id, policy_id, term_number, effective_date, expiration_date,
               written_premium, renewal_flag, lapse_flag, status, '{LOAD_DATE}'
        FROM pc_policy_period;

        DROP TABLE IF EXISTS stg_transaction;
        CREATE TABLE stg_transaction (
            transaction_id TEXT, policy_id TEXT, period_id TEXT, agent_id TEXT, lob TEXT,
            transaction_type TEXT, transaction_date TEXT, premium_amount REAL,
            commission_rate REAL, commission_amount REAL, stg_load_date TEXT
        );
        INSERT INTO stg_transaction
        SELECT transaction_id, policy_id, period_id, agent_id, lob,
               transaction_type, transaction_date, premium_amount,
               commission_rate, commission_amount, '{LOAD_DATE}'
        FROM pc_transaction;
    """)
    conn.commit()
    cnt = c.execute("SELECT COUNT(*) FROM stg_transaction").fetchone()[0]
    ok(f"{cnt:,} transactions in STAGING")

# ─────────────────────────────────────────────────────────────────────────────
# PHASE 3 — RAW  (append-only historical archive, never truncated)
# ─────────────────────────────────────────────────────────────────────────────
def build_raw(conn):
    step("PHASE 3 — RAW: Append-only historical archive with load_date")
    c = conn.cursor()
    c.executescript(f"""
        CREATE TABLE IF NOT EXISTS raw_agent (
            agent_id TEXT, agent_name TEXT, agency_name TEXT, region TEXT,
            state TEXT, created_date TEXT, load_date TEXT
        );
        INSERT INTO raw_agent
        SELECT agent_id, agent_name, agency_name, region, state, created_date, '{LOAD_DATE}'
        FROM stg_agent
        WHERE NOT EXISTS (
            SELECT 1 FROM raw_agent r WHERE r.agent_id = stg_agent.agent_id AND r.load_date = '{LOAD_DATE}'
        );

        CREATE TABLE IF NOT EXISTS raw_product (
            product_id TEXT, lob TEXT, product_name TEXT, product_code TEXT, load_date TEXT
        );
        INSERT INTO raw_product
        SELECT product_id, lob, product_name, product_code, '{LOAD_DATE}'
        FROM stg_product
        WHERE NOT EXISTS (
            SELECT 1 FROM raw_product r WHERE r.product_id = stg_product.product_id AND r.load_date = '{LOAD_DATE}'
        );

        CREATE TABLE IF NOT EXISTS raw_policy (
            policy_id TEXT, policy_number TEXT, product_id TEXT, lob TEXT, agent_id TEXT,
            insured_name TEXT, state TEXT, status TEXT, created_date TEXT, load_date TEXT
        );
        INSERT INTO raw_policy
        SELECT policy_id, policy_number, product_id, lob, agent_id,
               insured_name, state, status, created_date, '{LOAD_DATE}'
        FROM stg_policy
        WHERE NOT EXISTS (
            SELECT 1 FROM raw_policy r WHERE r.policy_id = stg_policy.policy_id AND r.load_date = '{LOAD_DATE}'
        );

        CREATE TABLE IF NOT EXISTS raw_policy_period (
            period_id TEXT, policy_id TEXT, term_number INTEGER, effective_date TEXT,
            expiration_date TEXT, written_premium REAL, renewal_flag INTEGER,
            lapse_flag INTEGER, status TEXT, load_date TEXT
        );
        INSERT INTO raw_policy_period
        SELECT period_id, policy_id, term_number, effective_date, expiration_date,
               written_premium, renewal_flag, lapse_flag, status, '{LOAD_DATE}'
        FROM stg_policy_period
        WHERE NOT EXISTS (
            SELECT 1 FROM raw_policy_period r WHERE r.period_id = stg_policy_period.period_id AND r.load_date = '{LOAD_DATE}'
        );

        CREATE TABLE IF NOT EXISTS raw_transaction (
            transaction_id TEXT, policy_id TEXT, period_id TEXT, agent_id TEXT, lob TEXT,
            transaction_type TEXT, transaction_date TEXT, premium_amount REAL,
            commission_rate REAL, commission_amount REAL, load_date TEXT
        );
        INSERT INTO raw_transaction
        SELECT transaction_id, policy_id, period_id, agent_id, lob,
               transaction_type, transaction_date, premium_amount,
               commission_rate, commission_amount, '{LOAD_DATE}'
        FROM stg_transaction
        WHERE NOT EXISTS (
            SELECT 1 FROM raw_transaction r WHERE r.transaction_id = stg_transaction.transaction_id AND r.load_date = '{LOAD_DATE}'
        );
    """)
    conn.commit()
    cnt = c.execute("SELECT COUNT(*) FROM raw_transaction").fetchone()[0]
    ok(f"{cnt:,} transactions in RAW (append-only, never truncated)")

# ─────────────────────────────────────────────────────────────────────────────
# PHASE 4 — EXPLORATION  (enriched joins, exposed to Data Scientists)
# ─────────────────────────────────────────────────────────────────────────────
def build_exploration(conn):
    step("PHASE 4 — EXPLORATION: Enriched joins for Data Scientists / ML")
    c = conn.cursor()
    c.executescript(f"""
        DROP TABLE IF EXISTS exp_policy_enriched;
        CREATE TABLE exp_policy_enriched (
            policy_id TEXT, policy_number TEXT, lob TEXT, product_code TEXT,
            agent_id TEXT, agent_name TEXT, agency_name TEXT, region TEXT, agent_state TEXT,
            insured_name TEXT, policy_state TEXT, policy_status TEXT,
            term_number INTEGER, effective_date TEXT, expiration_date TEXT,
            written_premium REAL, renewal_flag INTEGER, lapse_flag INTEGER, period_status TEXT,
            term_age_days INTEGER, is_active INTEGER, load_date TEXT
        );
        INSERT INTO exp_policy_enriched
        SELECT
            p.policy_id, p.policy_number, p.lob, pr.product_code,
            a.agent_id, a.agent_name, a.agency_name, a.region, a.state,
            p.insured_name, p.state, p.status,
            pp.term_number, pp.effective_date, pp.expiration_date,
            pp.written_premium, pp.renewal_flag, pp.lapse_flag, pp.status,
            CAST((julianday('{TODAY_STR}') - julianday(pp.effective_date)) AS INTEGER),
            CASE WHEN pp.status = 'Active' THEN 1 ELSE 0 END,
            '{LOAD_DATE}'
        FROM raw_policy p
        JOIN raw_policy_period pp ON p.policy_id = pp.policy_id
        JOIN raw_agent a          ON p.agent_id   = a.agent_id
        JOIN raw_product pr       ON p.product_id = pr.product_id
        WHERE p.load_date = '{LOAD_DATE}' AND pp.load_date = '{LOAD_DATE}'
          AND a.load_date = '{LOAD_DATE}' AND pr.load_date = '{LOAD_DATE}';

        DROP TABLE IF EXISTS exp_transaction_enriched;
        CREATE TABLE exp_transaction_enriched (
            transaction_id TEXT, transaction_type TEXT, transaction_date TEXT,
            policy_id TEXT, policy_number TEXT, period_id TEXT,
            lob TEXT, agent_id TEXT, agent_name TEXT, agency_name TEXT, region TEXT,
            premium_amount REAL, commission_rate REAL, commission_amount REAL,
            txn_year INTEGER, txn_month INTEGER, txn_quarter INTEGER,
            load_date TEXT
        );
        INSERT INTO exp_transaction_enriched
        SELECT
            t.transaction_id, t.transaction_type, t.transaction_date,
            t.policy_id, p.policy_number, t.period_id,
            t.lob, a.agent_id, a.agent_name, a.agency_name, a.region,
            t.premium_amount, t.commission_rate, t.commission_amount,
            CAST(strftime('%Y','%m','%d', t.transaction_date) AS INTEGER),
            CAST(strftime('%m', t.transaction_date) AS INTEGER),
            CAST((CAST(strftime('%m', t.transaction_date) AS INTEGER)+2)/3 AS INTEGER),
            '{LOAD_DATE}'
        FROM raw_transaction t
        JOIN raw_policy p ON t.policy_id = p.policy_id
        JOIN raw_agent a  ON t.agent_id  = a.agent_id
        WHERE t.load_date = '{LOAD_DATE}' AND p.load_date = '{LOAD_DATE}' AND a.load_date = '{LOAD_DATE}';
    """)
    conn.commit()
    cnt = c.execute("SELECT COUNT(*) FROM exp_transaction_enriched").fetchone()[0]
    ok(f"{cnt:,} enriched transactions in EXPLORATION")

# ─────────────────────────────────────────────────────────────────────────────
# PHASE 5 — CONFORMED  (3NF Dimensional Model)
# ─────────────────────────────────────────────────────────────────────────────
def build_conformed(conn):
    step("PHASE 5 — CONFORMED: 3NF Dimensional Model")
    c = conn.cursor()
    c.executescript(f"""
        DROP TABLE IF EXISTS conf_dim_agent;
        CREATE TABLE conf_dim_agent (
            agent_key   INTEGER PRIMARY KEY AUTOINCREMENT,
            agent_id    TEXT NOT NULL,
            agent_name  TEXT NOT NULL,
            agency_name TEXT NOT NULL,
            region      TEXT NOT NULL,
            state       TEXT NOT NULL,
            load_date   TEXT NOT NULL
        );
        INSERT INTO conf_dim_agent (agent_id, agent_name, agency_name, region, state, load_date)
        SELECT DISTINCT agent_id, agent_name, agency_name, region, state, '{LOAD_DATE}'
        FROM raw_agent WHERE load_date = '{LOAD_DATE}';

        DROP TABLE IF EXISTS conf_dim_product;
        CREATE TABLE conf_dim_product (
            product_key  INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id   TEXT NOT NULL,
            lob          TEXT NOT NULL,
            product_name TEXT NOT NULL,
            product_code TEXT NOT NULL,
            load_date    TEXT NOT NULL
        );
        INSERT INTO conf_dim_product (product_id, lob, product_name, product_code, load_date)
        SELECT product_id, lob, product_name, product_code, '{LOAD_DATE}'
        FROM raw_product WHERE load_date = '{LOAD_DATE}';

        DROP TABLE IF EXISTS conf_dim_date;
        CREATE TABLE conf_dim_date (
            date_key   TEXT PRIMARY KEY,
            full_date  TEXT NOT NULL,
            year       INTEGER NOT NULL,
            quarter    INTEGER NOT NULL,
            month      INTEGER NOT NULL,
            month_name TEXT NOT NULL,
            day        INTEGER NOT NULL,
            day_name   TEXT NOT NULL
        );
        WITH RECURSIVE dates(d) AS (
            SELECT date('{TODAY_STR}', '-730 days')
            UNION ALL SELECT date(d, '+1 day') FROM dates WHERE d < '{TODAY_STR}'
        )
        INSERT OR IGNORE INTO conf_dim_date
        SELECT
            strftime('%Y%m%d', d),
            d,
            CAST(strftime('%Y', d) AS INTEGER),
            CAST((CAST(strftime('%m',d) AS INTEGER)+2)/3 AS INTEGER),
            CAST(strftime('%m', d) AS INTEGER),
            CASE strftime('%m',d)
                WHEN '01' THEN 'January'   WHEN '02' THEN 'February'
                WHEN '03' THEN 'March'     WHEN '04' THEN 'April'
                WHEN '05' THEN 'May'       WHEN '06' THEN 'June'
                WHEN '07' THEN 'July'      WHEN '08' THEN 'August'
                WHEN '09' THEN 'September' WHEN '10' THEN 'October'
                WHEN '11' THEN 'November'  WHEN '12' THEN 'December'
            END,
            CAST(strftime('%d', d) AS INTEGER),
            CASE strftime('%w',d)
                WHEN '0' THEN 'Sunday'    WHEN '1' THEN 'Monday'
                WHEN '2' THEN 'Tuesday'   WHEN '3' THEN 'Wednesday'
                WHEN '4' THEN 'Thursday'  WHEN '5' THEN 'Friday'
                WHEN '6' THEN 'Saturday'
            END
        FROM dates;

        DROP TABLE IF EXISTS conf_dim_policy;
        CREATE TABLE conf_dim_policy (
            policy_key    INTEGER PRIMARY KEY AUTOINCREMENT,
            policy_id     TEXT NOT NULL,
            policy_number TEXT NOT NULL,
            lob           TEXT NOT NULL,
            product_id    TEXT NOT NULL,
            agent_id      TEXT NOT NULL,
            insured_name  TEXT NOT NULL,
            state         TEXT NOT NULL,
            status        TEXT NOT NULL,
            created_date  TEXT NOT NULL,
            load_date     TEXT NOT NULL
        );
        INSERT INTO conf_dim_policy (policy_id, policy_number, lob, product_id, agent_id,
            insured_name, state, status, created_date, load_date)
        SELECT policy_id, policy_number, lob, product_id, agent_id,
               insured_name, state, status, created_date, '{LOAD_DATE}'
        FROM raw_policy WHERE load_date = '{LOAD_DATE}';

        DROP TABLE IF EXISTS conf_fact_transaction;
        CREATE TABLE conf_fact_transaction (
            txn_key           INTEGER PRIMARY KEY AUTOINCREMENT,
            transaction_id    TEXT NOT NULL,
            policy_id         TEXT NOT NULL,
            period_id         TEXT NOT NULL,
            agent_id          TEXT NOT NULL,
            product_id        TEXT NOT NULL,
            date_key          TEXT NOT NULL,
            lob               TEXT NOT NULL,
            transaction_type  TEXT NOT NULL,
            premium_amount    REAL NOT NULL,
            commission_rate   REAL NOT NULL,
            commission_amount REAL NOT NULL,
            load_date         TEXT NOT NULL
        );
        INSERT INTO conf_fact_transaction (transaction_id, policy_id, period_id, agent_id,
            product_id, date_key, lob, transaction_type, premium_amount,
            commission_rate, commission_amount, load_date)
        SELECT t.transaction_id, t.policy_id, t.period_id, t.agent_id,
               p.product_id,
               strftime('%Y%m%d', t.transaction_date),
               t.lob, t.transaction_type,
               t.premium_amount, t.commission_rate, t.commission_amount,
               '{LOAD_DATE}'
        FROM raw_transaction t
        JOIN raw_policy p ON t.policy_id = p.policy_id
        WHERE t.load_date = '{LOAD_DATE}' AND p.load_date = '{LOAD_DATE}';
    """)
    conn.commit()
    cnt = c.execute("SELECT COUNT(*) FROM conf_fact_transaction").fetchone()[0]
    ok(f"{cnt:,} transactions in CONFORMED fact table")
    ok("dim_agent | dim_product | dim_date | dim_policy all loaded")

# ─────────────────────────────────────────────────────────────────────────────
# PHASE 6 — ANALYTICAL  (Type 2 SCD Dims + Transaction + Aggregate Facts)
# ─────────────────────────────────────────────────────────────────────────────
def build_analytical(conn):
    step("PHASE 6 — ANALYTICAL: Type 2 SCD Dimensions + Aggregate Facts")
    c = conn.cursor()
    c.executescript(f"""
        -- Type 2 SCD: Dim Agent
        DROP TABLE IF EXISTS anl_dim_agent;
        CREATE TABLE anl_dim_agent (
            agent_key   INTEGER PRIMARY KEY AUTOINCREMENT,
            agent_id    TEXT NOT NULL,
            agent_name  TEXT NOT NULL,
            agency_name TEXT NOT NULL,
            region      TEXT NOT NULL,
            state       TEXT NOT NULL,
            eff_start   TEXT NOT NULL,
            eff_end     TEXT,
            is_current  INTEGER NOT NULL DEFAULT 1,
            load_date   TEXT NOT NULL
        );
        INSERT INTO anl_dim_agent (agent_id, agent_name, agency_name, region, state,
            eff_start, eff_end, is_current, load_date)
        SELECT agent_id, agent_name, agency_name, region, state,
               '{LOAD_DATE}', NULL, 1, '{LOAD_DATE}'
        FROM conf_dim_agent;

        -- Dim Product
        DROP TABLE IF EXISTS anl_dim_product;
        CREATE TABLE anl_dim_product (
            product_key  INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id   TEXT NOT NULL,
            lob          TEXT NOT NULL,
            product_name TEXT NOT NULL,
            product_code TEXT NOT NULL,
            load_date    TEXT NOT NULL
        );
        INSERT INTO anl_dim_product (product_id, lob, product_name, product_code, load_date)
        SELECT product_id, lob, product_name, product_code, '{LOAD_DATE}'
        FROM conf_dim_product;

        -- Dim Date (carry from CONFORMED)
        DROP TABLE IF EXISTS anl_dim_date;
        CREATE TABLE anl_dim_date AS SELECT * FROM conf_dim_date WHERE 1=0;
        INSERT INTO anl_dim_date SELECT * FROM conf_dim_date;

        -- Type 2 SCD: Dim Policy
        DROP TABLE IF EXISTS anl_dim_policy;
        CREATE TABLE anl_dim_policy (
            policy_key    INTEGER PRIMARY KEY AUTOINCREMENT,
            policy_id     TEXT NOT NULL,
            policy_number TEXT NOT NULL,
            lob           TEXT NOT NULL,
            product_id    TEXT NOT NULL,
            agent_id      TEXT NOT NULL,
            insured_name  TEXT NOT NULL,
            state         TEXT NOT NULL,
            status        TEXT NOT NULL,
            created_date  TEXT NOT NULL,
            eff_start     TEXT NOT NULL,
            eff_end       TEXT,
            is_current    INTEGER NOT NULL DEFAULT 1,
            load_date     TEXT NOT NULL
        );
        INSERT INTO anl_dim_policy (policy_id, policy_number, lob, product_id, agent_id,
            insured_name, state, status, created_date, eff_start, eff_end, is_current, load_date)
        SELECT policy_id, policy_number, lob, product_id, agent_id,
               insured_name, state, status, created_date,
               '{LOAD_DATE}', NULL, 1, '{LOAD_DATE}'
        FROM conf_dim_policy;

        -- Fact: Policy Transaction (transaction grain)
        DROP TABLE IF EXISTS anl_fact_policy_transaction;
        CREATE TABLE anl_fact_policy_transaction (
            txn_key           INTEGER PRIMARY KEY AUTOINCREMENT,
            transaction_id    TEXT NOT NULL,
            policy_key        INTEGER NOT NULL,
            agent_key         INTEGER NOT NULL,
            product_key       INTEGER NOT NULL,
            date_key          TEXT NOT NULL,
            period_id         TEXT NOT NULL,
            lob               TEXT NOT NULL,
            transaction_type  TEXT NOT NULL,
            premium_amount    REAL NOT NULL,
            commission_rate   REAL NOT NULL,
            commission_amount REAL NOT NULL,
            load_date         TEXT NOT NULL
        );
        INSERT INTO anl_fact_policy_transaction (transaction_id, policy_key, agent_key,
            product_key, date_key, period_id, lob, transaction_type,
            premium_amount, commission_rate, commission_amount, load_date)
        SELECT
            ct.transaction_id,
            ap.policy_key,
            aa.agent_key,
            adp.product_key,
            ct.date_key,
            ct.period_id,
            ct.lob,
            ct.transaction_type,
            ct.premium_amount,
            ct.commission_rate,
            ct.commission_amount,
            '{LOAD_DATE}'
        FROM conf_fact_transaction ct
        JOIN anl_dim_policy  ap  ON ct.policy_id   = ap.policy_id  AND ap.is_current = 1
        JOIN anl_dim_agent   aa  ON ct.agent_id    = aa.agent_id   AND aa.is_current = 1
        JOIN anl_dim_product adp ON ct.product_id  = adp.product_id;

        -- Fact: Policy Aggregate (agent / LOB / year-month grain)
        DROP TABLE IF EXISTS anl_fact_policy_aggregate;
        CREATE TABLE anl_fact_policy_aggregate (
            agg_key               INTEGER PRIMARY KEY AUTOINCREMENT,
            agent_key             INTEGER NOT NULL,
            product_key           INTEGER NOT NULL,
            period_year           INTEGER NOT NULL,
            period_month          INTEGER NOT NULL,
            lob                   TEXT NOT NULL,
            total_written_premium REAL NOT NULL,
            policy_count          INTEGER NOT NULL,
            new_business_count    INTEGER NOT NULL,
            renewal_count         INTEGER NOT NULL,
            lapse_count           INTEGER NOT NULL,
            cancellation_count    INTEGER NOT NULL,
            avg_premium           REAL NOT NULL,
            renewal_rate          REAL NOT NULL,
            lapse_rate            REAL NOT NULL,
            load_date             TEXT NOT NULL
        );
        INSERT INTO anl_fact_policy_aggregate (agent_key, product_key, period_year, period_month,
            lob, total_written_premium, policy_count, new_business_count, renewal_count,
            lapse_count, cancellation_count, avg_premium, renewal_rate, lapse_rate, load_date)
        SELECT
            aa.agent_key,
            adp.product_key,
            CAST(strftime('%Y', pp.effective_date) AS INTEGER),
            CAST(strftime('%m', pp.effective_date) AS INTEGER),
            p.lob,
            ROUND(SUM(pp.written_premium), 2),
            COUNT(DISTINCT p.policy_id),
            SUM(CASE WHEN pp.renewal_flag = 0 THEN 1 ELSE 0 END),
            SUM(CASE WHEN pp.renewal_flag = 1 THEN 1 ELSE 0 END),
            SUM(pp.lapse_flag),
            SUM(CASE WHEN pp.status = 'Cancelled' THEN 1 ELSE 0 END),
            ROUND(AVG(pp.written_premium), 2),
            ROUND(CAST(SUM(CASE WHEN pp.renewal_flag = 1 THEN 1 ELSE 0 END) AS REAL)
                / NULLIF(COUNT(DISTINCT p.policy_id), 0), 4),
            ROUND(CAST(SUM(pp.lapse_flag) AS REAL)
                / NULLIF(COUNT(DISTINCT p.policy_id), 0), 4),
            '{LOAD_DATE}'
        FROM raw_policy_period pp
        JOIN raw_policy      p   ON pp.policy_id  = p.policy_id
        JOIN anl_dim_agent   aa  ON p.agent_id    = aa.agent_id  AND aa.is_current = 1
        JOIN anl_dim_product adp ON p.product_id  = adp.product_id
        WHERE pp.load_date = '{LOAD_DATE}' AND p.load_date = '{LOAD_DATE}'
        GROUP BY aa.agent_key, adp.product_key,
                 strftime('%Y', pp.effective_date),
                 strftime('%m', pp.effective_date),
                 p.lob;
    """)
    conn.commit()
    txn  = c.execute("SELECT COUNT(*) FROM anl_fact_policy_transaction").fetchone()[0]
    agg  = c.execute("SELECT COUNT(*) FROM anl_fact_policy_aggregate").fetchone()[0]
    ok(f"{txn:,} rows in anl_fact_policy_transaction")
    ok(f"{agg:,} rows in anl_fact_policy_aggregate")
    ok("anl_dim_agent (Type2) | anl_dim_policy (Type2) | anl_dim_product | anl_dim_date loaded")

# ─────────────────────────────────────────────────────────────────────────────
# PHASE 7 — KPI VERIFICATION
# ─────────────────────────────────────────────────────────────────────────────
def verify_kpis(conn):
    step("PHASE 7 — KPI VERIFICATION: All 8 KPIs against Analytical Layer")
    c = conn.cursor()
    results = {}

    # KPI 1: Total Premium Written
    v = c.execute("SELECT ROUND(SUM(total_written_premium),2) FROM anl_fact_policy_aggregate").fetchone()[0]
    results['total_premium'] = v
    ok(f"KPI 1 — Total Premium Written       : ${v:>18,.2f}")

    # KPI 2: Policy Count
    v = c.execute("SELECT COUNT(*) FROM anl_dim_policy WHERE is_current = 1").fetchone()[0]
    results['policy_count'] = v
    ok(f"KPI 2 — Policy Count                : {v:>18,}")

    # KPI 3: Renewal Rate
    v = c.execute("""
        SELECT ROUND(CAST(SUM(renewal_count) AS REAL) / NULLIF(SUM(policy_count),0) * 100, 2)
        FROM anl_fact_policy_aggregate
    """).fetchone()[0]
    results['renewal_rate'] = v
    ok(f"KPI 3 — Renewal Rate                : {v:>17.2f}%")

    # KPI 4: Average Premium
    v = c.execute("""
        SELECT ROUND(SUM(total_written_premium)/NULLIF(SUM(policy_count),0), 2)
        FROM anl_fact_policy_aggregate
    """).fetchone()[0]
    results['avg_premium'] = v
    ok(f"KPI 4 — Average Premium per Policy  : ${v:>18,.2f}")

    # KPI 5: Lapse Rate
    v = c.execute("""
        SELECT ROUND(CAST(SUM(lapse_count) AS REAL) / NULLIF(SUM(policy_count),0) * 100, 2)
        FROM anl_fact_policy_aggregate
    """).fetchone()[0]
    results['lapse_rate'] = v
    ok(f"KPI 5 — Lapse Rate                  : {v:>17.2f}%")

    # KPI 6: 30-Day Premium Trend
    trend = c.execute("""
        SELECT d.full_date, ROUND(SUM(t.premium_amount), 2)
        FROM anl_fact_policy_transaction t
        JOIN anl_dim_date d ON t.date_key = d.date_key
        WHERE d.full_date >= date('now', '-30 days')
          AND t.transaction_type IN ('NewBusiness','Renewal')
        GROUP BY d.full_date
        ORDER BY d.full_date
    """).fetchall()
    results['trend'] = trend
    ok(f"KPI 6 — 30-Day Premium Trend        : {len(trend):>14} data points")

    # KPI 7: Premium by Agent (Top 5)
    top5 = c.execute("""
        SELECT a.agent_name, ROUND(SUM(f.total_written_premium),2)
        FROM anl_fact_policy_aggregate f
        JOIN anl_dim_agent a ON f.agent_key = a.agent_key
        GROUP BY a.agent_key, a.agent_name
        ORDER BY 2 DESC LIMIT 5
    """).fetchall()
    results['top5_agents'] = top5
    ok(f"KPI 7 — Premium by Agent (Top 5):")
    for name, total in top5:
        print(f"             {name:<28} ${total:>12,.2f}")

    # KPI 8: Premium by LOB
    by_lob = c.execute("""
        SELECT lob,
               ROUND(SUM(total_written_premium),2) as total,
               SUM(policy_count) as cnt,
               ROUND(AVG(renewal_rate)*100,2) as rr,
               ROUND(AVG(lapse_rate)*100,2) as lr
        FROM anl_fact_policy_aggregate
        GROUP BY lob ORDER BY total DESC
    """).fetchall()
    results['by_lob'] = by_lob
    ok(f"KPI 8 — Premium by LOB:")
    for lob, total, cnt, rr, lr in by_lob:
        print(f"             {lob:<16} ${total:>14,.2f}  |  {cnt:>5,} policies  |  RR {rr:.1f}%  |  LR {lr:.1f}%")

    print(f"\n{'═'*62}")
    print("   ✅  ALL 8 KPIs VERIFIED — Analytical Layer is ready")
    print(f"{'═'*62}\n")
    return results

# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    if os.path.exists(DB_PATH): os.remove(DB_PATH)
    conn = sqlite3.connect(DB_PATH)
    print(f"\n{'═'*62}")
    print("  Donegal Insurance — PolicyCenter Demo ETL Pipeline")
    print(f"  Load Date: {LOAD_DATE}  |  Scale: Medium")
    print(f"{'═'*62}")

    txn_count = build_source(conn)
    build_staging(conn)
    build_raw(conn)
    build_exploration(conn)
    build_conformed(conn)
    build_analytical(conn)
    results    = verify_kpis(conn)
    conn.close()

    print(f"   📦  DB  : {DB_PATH}")
    print(f"   📊  Transactions generated : {txn_count:,}")
    db_mb = os.path.getsize(DB_PATH) / 1024 / 1024
    print(f"   💾  DB size                 : {db_mb:.2f} MB\n")
