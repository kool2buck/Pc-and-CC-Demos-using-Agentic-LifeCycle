# Operations Runbook — PolicyCenter Demo
**Date:** 2026-06-16  |  **Environment:** Demo/SQLite

## 1. Running the ETL Pipeline (from scratch)
```bash
cd policycenter-demo/
python3 python/01_build_pipeline.py  # SOURCE + 5-layer ETL
python3 python/01b_add_quotes.py     # Quote stream + anl_fact_quote_summary
```
Expected: policycenter.db ~7MB, no errors

## 2. Verifying KPIs after rebuild
```bash
sqlite3 policycenter.db "SELECT SUM(total_written_premium) FROM anl_fact_policy_aggregate;"
# Expected: ~13962087
sqlite3 policycenter.db "SELECT SUM(bound_count)*1.0/SUM(total_quotes) FROM anl_fact_quote_summary;"
# Expected: ~0.5804
```

## 3. Launching Dashboards
Mac: ./scripts/launch-demo.sh
Windows: scripts\launch-demo.bat
Both open 3 dashboards in default browser.

## 4. Common Issues
| Symptom | Cause | Fix |
|---------|-------|-----|
| dashboard.html blank charts | Missing policycenter.db | Re-run ETL scripts |
| SQL terminal no results | Old DB schema | Rebuild with 01_build_pipeline.py |
| PII names not decrypting | Wrong role button | Click regional_mgr_pa or data_gov_officer |

## 5. File Size Reference
| File | Expected Size |
|------|---------------|
| policycenter.db | ~7 MB |
| POLICYCENTER_SDLC_DEMO.html | ~57 KB |
| wiki.html | ~45 KB |
| dashboard.html | ~60 KB |
