# Artifacts Directory — PC_DASHBOARD_DEMO_2025

| File | Produced By | Status |
|------|-------------|--------|
| BRD.md | grillmewithdocs (Loop 2) | ✅ APPROVED |
| PRD.md | to-prd (Loop 2) | ✅ PASS |
| Technical_Requirements.md | grillmewithdocs | ✅ PASS |
| Schema_Audit.md | schema-discovery (Loop 2) | ✅ PASS |
| Data_Dictionary.md | dev-build | ✅ PASS |
| ETL_Pipeline_Architecture.md | dev-build | ✅ PASS |
| Dimensional_Model.md | dev-build | ✅ PASS |
| Operations_Runbook.md | dev-build | ✅ PASS |
| SIGNOFF_PACKAGE.md | business-signoff | ✅ APPROVED |
| sql/00_orchestration.sql | dev-build | ETL master |
| sql/01_staging.sql | dev-build | Layer 1 |
| sql/02_raw.sql | dev-build | Layer 2 |
| sql/03_exploration.sql | dev-build | Layer 3 |
| sql/04_conformed.sql | dev-build | Layer 4 |
| sql/05_analytical.sql | dev-build | Layer 5 |
| sql/06_aggregate_facts.sql | dev-build | NEW: Aggregate |
| sql/sample_kpi_queries.sql | dev-build | Reference |
| sql/etl_validation_queries.sql | qa-100 | Validation |
| test-reports/TEST_REPORT.md | tdd | 9/9 PASS |
| test-reports/QA_TEST_REPORT.md | qa-100 | 12/12 PASS |
