# Data Dictionary — PolicyCenter Demo
## Analytical Layer Tables | Date: 2026-06-16

---

## anl_dim_agent  (Type 2 SCD)
| Column     | Type    | Description                              | PII |
|------------|---------|------------------------------------------|-----|
| agent_key  | INTEGER | Surrogate key (PK)                        | No  |
| agent_id   | TEXT    | Natural key from pc_agent                | No  |
| agent_name | TEXT    | Full name of agent                       | No  |
| agency_name| TEXT    | Parent agency name                       | No  |
| region     | TEXT    | Geographic region (Northeast/etc)        | No  |
| state      | TEXT    | State code                               | No  |
| eff_start  | TEXT    | Effective start date (Type 2 SCD)        | No  |
| eff_end    | TEXT    | Effective end date (NULL = current)      | No  |
| is_current | INTEGER | 1 = current record, 0 = historical       | No  |
| load_date  | TEXT    | Date loaded into analytical layer        | No  |

## anl_dim_policy  (Type 2 SCD)
| Column       | Type    | Description                            | PII |
|--------------|---------|----------------------------------------|-----|
| policy_key   | INTEGER | Surrogate key (PK)                      | No  |
| policy_id    | TEXT    | Natural key from pc_policy             | No  |
| policy_number| TEXT    | Human-readable policy number (DNG-xxx) | No  |
| lob          | TEXT    | Line of Business                       | No  |
| product_id   | TEXT    | FK to anl_dim_product                  | No  |
| agent_id     | TEXT    | FK to anl_dim_agent (natural key)      | No  |
| insured_name | TEXT    | Policyholder name                      | ⚠️ PII |
| state        | TEXT    | State where policy is written          | No  |
| status       | TEXT    | Active/Expired/Cancelled/NonRenewed    | No  |
| created_date | TEXT    | Original policy creation date          | No  |
| eff_start    | TEXT    | SCD effective start                    | No  |
| eff_end      | TEXT    | SCD effective end (NULL = current)     | No  |
| is_current   | INTEGER | 1 = current record                     | No  |
| load_date    | TEXT    | Load date                              | No  |

## anl_dim_product
| Column       | Type    | Description               | PII |
|--------------|---------|---------------------------|-----|
| product_key  | INTEGER | Surrogate key (PK)         | No  |
| product_id   | TEXT    | Natural key from pc_product| No  |
| lob          | TEXT    | Line of Business           | No  |
| product_name | TEXT    | Full LOB name              | No  |
| product_code | TEXT    | 2-letter code (PA/HO/etc)  | No  |
| load_date    | TEXT    | Load date                  | No  |

## anl_dim_date
| Column     | Type    | Description              |
|------------|---------|--------------------------|
| date_key   | TEXT    | YYYYMMDD format (PK)     |
| full_date  | TEXT    | YYYY-MM-DD               |
| year       | INTEGER | Calendar year            |
| quarter    | INTEGER | 1–4                      |
| month      | INTEGER | 1–12                     |
| month_name | TEXT    | January–December         |
| day        | INTEGER | Day of month             |
| day_name   | TEXT    | Monday–Sunday            |

## anl_fact_policy_transaction  (Grain: 1 row per transaction)
| Column           | Type    | Description                              |
|------------------|---------|------------------------------------------|
| txn_key          | INTEGER | Surrogate key (PK)                        |
| transaction_id   | TEXT    | Natural key from pc_transaction           |
| policy_key       | INTEGER | FK to anl_dim_policy                     |
| agent_key        | INTEGER | FK to anl_dim_agent                      |
| product_key      | INTEGER | FK to anl_dim_product                    |
| date_key         | TEXT    | FK to anl_dim_date                       |
| period_id        | TEXT    | FK to pc_policy_period (natural key)      |
| lob              | TEXT    | Line of Business                         |
| transaction_type | TEXT    | NewBusiness/Renewal/Endorsement/Cancellation |
| premium_amount   | REAL    | Transaction premium (can be negative)    |
| commission_rate  | REAL    | Commission rate (decimal)                |
| commission_amount| REAL    | Calculated commission                    |
| load_date        | TEXT    | Load date                                |

## anl_fact_policy_aggregate  (Grain: agent × LOB × year × month)
| Column               | Type    | Description                          |
|----------------------|---------|--------------------------------------|
| agg_key              | INTEGER | Surrogate key (PK)                    |
| agent_key            | INTEGER | FK to anl_dim_agent                  |
| product_key          | INTEGER | FK to anl_dim_product                |
| period_year          | INTEGER | Year of policy effective date        |
| period_month         | INTEGER | Month of policy effective date       |
| lob                  | TEXT    | Line of Business                     |
| total_written_premium| REAL    | SUM of written_premium               |
| policy_count         | INTEGER | COUNT(DISTINCT policy_id)            |
| new_business_count   | INTEGER | Policies with renewal_flag=0         |
| renewal_count        | INTEGER | Policies with renewal_flag=1         |
| lapse_count          | INTEGER | Policies with lapse_flag=1           |
| cancellation_count   | INTEGER | Periods with status=Cancelled        |
| avg_premium          | REAL    | AVG(written_premium)                 |
| renewal_rate         | REAL    | renewal_count / policy_count         |
| lapse_rate           | REAL    | lapse_count / policy_count           |
| load_date            | TEXT    | Load date                            |

## anl_fact_quote_summary  (Grain: agent × LOB × quote_type × year × month)
| Column              | Type    | Description                              |
|---------------------|---------|------------------------------------------|
| summary_key         | INTEGER | Surrogate key (PK)                        |
| agent_key           | INTEGER | FK to anl_dim_agent                      |
| product_key         | INTEGER | FK to anl_dim_product                    |
| quote_year          | INTEGER | Year of quote date                       |
| quote_month         | INTEGER | Month of quote date                      |
| lob                 | TEXT    | Line of Business                         |
| quote_type          | TEXT    | NewBusiness or Renewal                   |
| total_quotes        | INTEGER | COUNT(*) of all quotes in group          |
| bound_count         | INTEGER | COUNT(*) where status='Bound'            |
| declined_count      | INTEGER | COUNT(*) where status='Declined'         |
| expired_count       | INTEGER | COUNT(*) where status='Expired'          |
| inprogress_count    | INTEGER | COUNT(*) where status='InProgress'       |
| hit_ratio           | REAL    | bound_count / total_quotes               |
| avg_quoted_premium  | REAL    | AVG(quoted_premium)                      |
| total_quoted_premium| REAL    | SUM(quoted_premium)                      |
| load_date           | TEXT    | Load date                                |
