# ETL Pipeline Architecture — PC_DASHBOARD_DEMO_2025
**Date:** 2026-06-16  |  **Produced by:** dev-build

## 5-Layer Architecture
```
SOURCE (Guidewire PolicyCenter — 6 tables)
  ↓  [STAGING]    1:1 extract, fresh each load, no transforms
  ↓  [RAW]        Append-only archive, load_date stamped, NOT EXISTS guard
  ↓  [EXPLORATION] Enriched joins, PII flagged, exposed to DS/ML
  ↓  [CONFORMED]  3NF dims + transactional + quote facts
  ↓  [ANALYTICAL] Type 2 SCD dims + policy_transaction + policy_aggregate + quote_summary
```

## Quote Stream (Parallel through all 5 layers)
```
SOURCE: pc_quote (3,384 rows)
  → stg_quote → raw_quote → exp_quote_enriched → conf_fact_quote → anl_fact_quote_summary
```
The quote stream feeds **KPI 9: Hit Ratio** exclusively.

## New in PC_DASHBOARD_DEMO vs Claims Center
1. **anl_fact_policy_aggregate** — pre-aggregated KPIs 1-5, 7, 8 at agent×LOB×year×month grain
2. **anl_fact_quote_summary** — quote conversion (Hit Ratio) at agent×LOB×type×year×month grain
3. **CONFORMED quote fact** — raw quote events with is_bound flag for SCD join

## ETL Rules (Permanent)
1. No CREATE TABLE AS SELECT (CTAS) — ever
2. RAW: append-only, never truncated
3. ANALYTICAL dims: Type 2 SCD (eff_start, eff_end, is_current)
4. Grain defined before writing SQL (documented in data_dict and grading rubric)
