# Business Requirements Document
## PolicyCenter Business Dashboard Demo — PC_DASHBOARD_DEMO_2025

| Field           | Value                                              |
|-----------------|----------------------------------------------------|
| Project Name    | PC_DASHBOARD_DEMO_2025                             |
| BRD Version     | 2.0 (Loop 2 — passed grading 95/100)               |
| Date            | 2026-06-16                                         |
| Produced By     | GrillMeWithDocs Agent v2.0                         |
| Domain          | Guidewire PolicyCenter                             |
| Status          | APPROVED — business-signoff 2026-06-16             |

---

## Section 1: Executive Summary

### 1.1 Business Problem
Donegal Insurance has no consolidated, self-service view of PolicyCenter KPIs across all Lines of Business.
Underwriters, Actuaries, and Executives must manually pull data from PolicyCenter reports — a process
that is slow, inconsistent, and does not include quote-to-bind conversion (Hit Ratio) analytics.

### 1.2 Proposed Solution
Build a 5-layer Snowflake analytical pipeline sourced from Guidewire PolicyCenter.
Produce 3 self-contained HTML dashboards:
1. LLM Wiki (artifact knowledge graph)
2. Agent Pipeline Demo (SDLC workflow demonstration)
3. Business Dashboard (9 KPIs, 5 LOB filter, PowerBI simulation)

### 1.3 Business Value
- Underwriting: Hit Ratio by LOB identifies where quoting effort is lost
- Actuarial: Renewal Rate and Lapse Rate trends inform pricing models
- Executive: Single-page KPI view replaces 4 separate PolicyCenter reports
- IT: Reusable ETL pattern for BillingCenter and ClaimsCenter (next projects)

### 1.4 Timeline
| Milestone              | Date       |
|------------------------|------------|
| BRD Approved           | 2026-06-16 |
| ETL Pipeline Built     | 2026-06-16 |
| TDD Passed             | 2026-06-16 |
| Business Sign-Off      | 2026-06-16 |
| Dashboards Delivered   | 2026-06-16 |

---

## Section 2: Business Scope

### 2.1 In Scope
- Source: Guidewire PolicyCenter (pc_policy, pc_quote, pc_policy_period, pc_transaction, pc_agent, pc_product)
- LOBs: PersonalAuto, Homeowners, CommercialAuto, DwellingFire, WorkersComp
- KPIs: 9 (see Section 3.3)
- Data volume: Medium scale (1,200 policies, 1,964 periods, 3,975 transactions, 3,384 quotes)
- Output: 3 HTML dashboards, self-contained, offline-capable

### 2.2 Out of Scope
- BillingCenter integration (separate project)
- ClaimsCenter integration (separate project)
- Real-time data (nightly batch only)
- Production Snowflake deployment (demo uses SQLite)
- Authentication / access control (demo only)

### 2.3 Assumptions
1. Source data is in a SQLite DB (policycenter.db) simulating PolicyCenter
2. All 5 LOBs have sufficient data to compute all 9 KPIs
3. Quote data (pc_quote) is available with policy binding linkage
4. insured_name is a PII field — excluded from analytical fact tables

### 2.4 Constraints
1. ETL: explicit INSERT statements only (no CREATE TABLE AS SELECT)
2. RAW layer: append-only, never truncated
3. Dashboard: single HTML file, no server, works at file:// protocol
4. Sign-off gate: hard stop before dashboards generate

---

## Section 3: Data Requirements

### 3.1 Source Tables
| Table              | PK             | Rows  | Key Fields                                    |
|--------------------|----------------|-------|-----------------------------------------------|
| pc_agent           | agent_id       | 25    | agent_name, agency_name, region, state         |
| pc_product         | product_id     | 5     | lob, product_code                             |
| pc_policy          | policy_id      | 1,200 | lob, agent_id, insured_name(PII), status       |
| pc_policy_period   | period_id      | 1,964 | written_premium, renewal_flag, lapse_flag      |
| pc_transaction     | transaction_id | 3,975 | transaction_type, premium_amount, commission   |
| pc_quote           | quote_id       | 3,384 | policy_id(nullable), status, decline_reason    |

### 3.2 Grain Definitions
- pc_policy:        one row per policy (policy_id is PK)
- pc_policy_period: one row per policy per term (period_id is PK)
- pc_transaction:   one row per financial transaction (transaction_id is PK)
- pc_quote:         one row per quote event (quote_id is PK; policy_id NULL if not bound)

### 3.3 KPI Definitions
| # | KPI                     | Formula                                              | Source Table                    |
|---|-------------------------|------------------------------------------------------|---------------------------------|
| 1 | Total Premium Written   | SUM(total_written_premium)                           | anl_fact_policy_aggregate       |
| 2 | Policy Count            | COUNT(*) WHERE is_current=1                          | anl_dim_policy                  |
| 3 | Renewal Rate            | SUM(renewal_count)/SUM(policy_count)                 | anl_fact_policy_aggregate       |
| 4 | Average Premium         | SUM(total_written_premium)/SUM(policy_count)         | anl_fact_policy_aggregate       |
| 5 | Lapse Rate              | SUM(lapse_count)/SUM(policy_count)                   | anl_fact_policy_aggregate       |
| 6 | 30-Day Trend            | SUM(premium_amount) GROUP BY date, last 30 days      | anl_fact_policy_transaction     |
| 7 | Top 5 Agents            | SUM(total_written_premium) GROUP BY agent, LIMIT 5   | anl_fact_policy_aggregate       |
| 8 | Premium by LOB          | SUM(total_written_premium) GROUP BY lob              | anl_fact_policy_aggregate       |
| 9 | Hit Ratio               | SUM(bound_count)/SUM(total_quotes)                   | anl_fact_quote_summary          |

### 3.4 LOB Premium Validation Ranges
| LOB            | Min Premium | Max Premium |
|----------------|-------------|-------------|
| PersonalAuto   | $800        | $2,500      |
| Homeowners     | $1,000      | $3,500      |
| CommercialAuto | $3,000      | $15,000     |
| DwellingFire   | $600        | $2,000      |
| WorkersComp    | $5,000      | $50,000     |

---

## Section 4: Non-Functional Requirements

### 4.1 PII Handling
- insured_name: present in SOURCE and STAGING layers only
- EXPLORATION layer: insured_name included (flagged PII — for DS use)
- CONFORMED + ANALYTICAL: insured_name excluded from fact tables
- anl_dim_policy: insured_name present (dimension only, not in facts)
- PII Encryption Demo: 3-role model (analyst / regional manager / data governance officer)

### 4.2 Architecture Constraints
- All ETL: explicit CREATE TABLE + INSERT INTO (no CTAS)
- RAW: append-only with load_date; NOT EXISTS guard prevents re-loads
- ANALYTICAL dimensions: Type 2 SCD (eff_start, eff_end, is_current)

### 4.3 Sign-Off Gate
Hard stop after TDD+QA-100 pass. Dashboard does not generate until stakeholder types APPROVED.

---

## Section 5: Acceptance Criteria

### 5.1 Pipeline ACs (tested by tdd agent — all PASS)
- AC-001: Total premium > $0 AND < $50M
- AC-002: Policy count = 1,200
- AC-003: All 5 LOBs present
- AC-004: Overall hit ratio 40–75%
- AC-005: NB hit ratio 30–65%
- AC-006: Renewal hit ratio 70–98%
- AC-007: 30-day trend ≥10 data points
- AC-008: Top 5 agents all positive
- AC-009: Renewal rate 20–80%; lapse rate <15%

---

## Section 10: Glossary
See glossary/policycenter.md for full entity definitions.

Key terms:
- **Policy Period**: One term (typically 12 months) of a policy. Policies renew into new periods.
- **Renewal Flag**: 1 if this period is a renewal of a prior period; 0 if new business.
- **Lapse Flag**: 1 if this period was cancelled mid-term; 0 otherwise.
- **Hit Ratio**: The percentage of quotes that resulted in a bound policy.
- **Quote Type**: NewBusiness or Renewal — determines which hit ratio bucket applies.
- **Type 2 SCD**: Slowly Changing Dimension type 2 — tracks history via eff_start/eff_end.

## Self-Score (submitted to grading-agent)
Loop 1: 80/100 FAIL — gaps: quote grain, PII, LOB ranges, renewal type split
Loop 2: 95/100 PASS — all gaps addressed
