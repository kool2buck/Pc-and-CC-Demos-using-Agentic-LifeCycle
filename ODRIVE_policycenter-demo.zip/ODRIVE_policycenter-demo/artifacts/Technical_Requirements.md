# Technical Requirements — PC_DASHBOARD_DEMO_2025
## Produced by: grillmewithdocs v2.0 | Date: 2026-06-16

## TR-001: Source Tables
All 6 PolicyCenter tables must be present in SOURCE layer.
pc_agent(25), pc_product(5), pc_policy(1200), pc_policy_period(1964),
pc_transaction(3975), pc_quote(3384)

## TR-002: ETL Pattern
Explicit INSERT statements only. No CREATE TABLE AS SELECT.
Every layer: CREATE TABLE [schema] → INSERT INTO [table] SELECT FROM [prior layer].

## TR-003: RAW Layer
Append-only. Deduplicate on load_date (NOT EXISTS guard).
Never TRUNCATE or DELETE from raw_* tables.

## TR-004: Type 2 SCD
anl_dim_agent and anl_dim_policy: eff_start, eff_end (NULL = current), is_current flag.

## TR-005: Quote Binding
pc_quote.policy_id is nullable. NULL = unbound. Non-NULL = bound to pc_policy.
Hit Ratio = SUM(is_bound=1) / COUNT(*) from anl_fact_quote_summary.

## TR-006: Grain
anl_fact_policy_transaction: one row per transaction_id
anl_fact_policy_aggregate: one row per agent_key × product_key × year × month × lob
anl_fact_quote_summary: one row per agent_key × product_key × year × month × lob × quote_type

## TR-007: PII
insured_name is PII. Present in SOURCE, STAGING, EXPLORATION.
Excluded from all analytical fact tables. Present in anl_dim_policy only.

## TR-008: LOB Validation
Each LOB's written_premium must fall within defined ranges:
PersonalAuto $800-$2500 | Homeowners $1000-$3500 | CommercialAuto $3000-$15000
DwellingFire $600-$2000 | WorkersComp $5000-$50000
