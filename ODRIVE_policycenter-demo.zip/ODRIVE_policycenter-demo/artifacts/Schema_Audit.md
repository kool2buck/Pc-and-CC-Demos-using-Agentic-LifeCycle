# Schema Audit — PolicyCenter Source
## Produced by: schema-discovery v2.0 | Date: 2026-06-16 | Score: 96/100

## Tables Audited
| Table              | PK             | Rows  | FK Count | PII Fields      | Nullables                        |
|--------------------|----------------|-------|----------|-----------------|----------------------------------|
| pc_agent           | agent_id       | 25    | 0        | none            | none                             |
| pc_product         | product_id     | 5     | 0        | none            | none                             |
| pc_policy          | policy_id      | 1,200 | 2        | insured_name    | none                             |
| pc_policy_period   | period_id      | 1,964 | 1        | none            | none                             |
| pc_transaction     | transaction_id | 3,975 | 3        | none            | none                             |
| pc_quote           | quote_id       | 3,384 | 3        | none            | policy_id, decline_reason, bound_date |

## FK Integrity Results
All 9 FK relationships verified — 0 orphaned records found.

## Data Quality Flags
- pc_transaction.premium_amount: CAN be negative (endorsements/cancellations) — NOT a defect
- pc_quote.policy_id: NULL for 1,420 unbound quotes — expected business behavior
- pc_quote.quoted_premium: always positive — constraint holds

## Key Business Rule
pc_quote → pc_policy binding:
When pc_quote.status = 'Bound', pc_quote.policy_id links to the resulting policy.
This is the source of the Hit Ratio KPI.
