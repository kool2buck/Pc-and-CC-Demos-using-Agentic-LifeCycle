# Dimensional Model — PolicyCenter Analytics
**Date:** 2026-06-16  |  **Produced by:** dev-build

## Star Schema (Primary: policy_transaction fact)
```
anl_dim_date      ←── anl_fact_policy_transaction ──→ anl_dim_agent
                                  ↑                          ↑
anl_dim_product ──────────────────┘               anl_dim_policy
```

## Aggregate Schema (Primary: policy_aggregate fact)
```
anl_dim_agent ←── anl_fact_policy_aggregate ──→ anl_dim_product
(+ period_year, period_month, lob in grain)
```

## Quote Schema (KPI 9: Hit Ratio)
```
anl_dim_agent ←── anl_fact_quote_summary ──→ anl_dim_product
(+ quote_year, quote_month, lob, quote_type in grain)
```

## Key Design Decisions
| Decision | Choice | Reason |
|----------|--------|--------|
| Type 2 SCD on agent | Yes | Agents change agencies; history needed |
| Type 2 SCD on policy | Yes | Policy status changes over life |
| Aggregate fact pre-built | Yes | KPIs 1-8 need fast aggregation by LOB/agent/month |
| Quote fact separate | Yes | Completely different grain from policy transactions |
| Date dimension | Yes | Enables 30-day trend, monthly slicing |
