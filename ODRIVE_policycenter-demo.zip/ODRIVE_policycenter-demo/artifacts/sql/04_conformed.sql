-- LAYER 4: CONFORMED
-- 3NF Dimensional Model with business logic applied. Explicit INSERT only.
-- ─────────────────────────────────────────────────────────────────────────────

DROP TABLE IF EXISTS conf_dim_agent;
CREATE TABLE conf_dim_agent (
    agent_key INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT NOT NULL, agent_name TEXT NOT NULL,
    agency_name TEXT NOT NULL, region TEXT NOT NULL,
    state TEXT NOT NULL, load_date TEXT NOT NULL
);
INSERT INTO conf_dim_agent (agent_id, agent_name, agency_name, region, state, load_date)
SELECT DISTINCT agent_id, agent_name, agency_name, region, state, :load_date
FROM raw_agent WHERE load_date = :load_date;

DROP TABLE IF EXISTS conf_fact_transaction;
CREATE TABLE conf_fact_transaction (
    txn_key INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_id TEXT NOT NULL, policy_id TEXT NOT NULL,
    period_id TEXT NOT NULL, agent_id TEXT NOT NULL, product_id TEXT NOT NULL,
    date_key TEXT NOT NULL, lob TEXT NOT NULL, transaction_type TEXT NOT NULL,
    premium_amount REAL NOT NULL, commission_rate REAL NOT NULL,
    commission_amount REAL NOT NULL, load_date TEXT NOT NULL
);
INSERT INTO conf_fact_transaction (transaction_id, policy_id, period_id, agent_id,
    product_id, date_key, lob, transaction_type, premium_amount,
    commission_rate, commission_amount, load_date)
SELECT t.transaction_id, t.policy_id, t.period_id, t.agent_id, p.product_id,
       strftime('%Y%m%d', t.transaction_date),
       t.lob, t.transaction_type, t.premium_amount, t.commission_rate,
       t.commission_amount, :load_date
FROM raw_transaction t
JOIN raw_policy p ON t.policy_id = p.policy_id
WHERE t.load_date = :load_date AND p.load_date = :load_date;

DROP TABLE IF EXISTS conf_fact_quote;
CREATE TABLE conf_fact_quote (
    quote_key INTEGER PRIMARY KEY AUTOINCREMENT,
    quote_id TEXT NOT NULL, policy_id TEXT, agent_id TEXT NOT NULL,
    product_id TEXT NOT NULL, date_key TEXT NOT NULL, lob TEXT NOT NULL,
    quote_type TEXT NOT NULL, quoted_premium REAL NOT NULL,
    status TEXT NOT NULL, decline_reason TEXT,
    is_bound INTEGER NOT NULL, load_date TEXT NOT NULL
);
INSERT INTO conf_fact_quote (quote_id, policy_id, agent_id, product_id,
    date_key, lob, quote_type, quoted_premium, status, decline_reason, is_bound, load_date)
SELECT q.quote_id, q.policy_id, q.agent_id, q.product_id,
       strftime('%Y%m%d', q.quote_date),
       q.lob, q.quote_type, q.quoted_premium, q.status, q.decline_reason,
       CASE WHEN q.status = 'Bound' THEN 1 ELSE 0 END,
       :load_date
FROM raw_quote q WHERE q.load_date = :load_date;
