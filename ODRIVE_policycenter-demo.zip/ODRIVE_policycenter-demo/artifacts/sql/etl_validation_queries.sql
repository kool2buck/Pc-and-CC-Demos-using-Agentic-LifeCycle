-- ETL Validation Queries — Verify layer row counts and integrity

-- STAGING vs RAW count match
SELECT 'stg_transaction' AS layer, COUNT(*) AS rows FROM stg_transaction
UNION ALL
SELECT 'raw_transaction', COUNT(*) FROM raw_transaction WHERE load_date = date('now');

-- Analytical row counts
SELECT 'anl_dim_agent (current)' AS table_name, COUNT(*) AS rows FROM anl_dim_agent WHERE is_current=1
UNION ALL SELECT 'anl_dim_policy (current)', COUNT(*) FROM anl_dim_policy WHERE is_current=1
UNION ALL SELECT 'anl_fact_policy_transaction', COUNT(*) FROM anl_fact_policy_transaction
UNION ALL SELECT 'anl_fact_policy_aggregate', COUNT(*) FROM anl_fact_policy_aggregate
UNION ALL SELECT 'anl_fact_quote_summary', COUNT(*) FROM anl_fact_quote_summary;

-- PK uniqueness check
SELECT 'anl_fact_policy_transaction' AS table_name,
       COUNT(*) AS total, COUNT(DISTINCT transaction_id) AS unique_pks
FROM anl_fact_policy_transaction;

-- FK integrity: no orphaned policy_keys
SELECT COUNT(*) AS orphaned_policy_keys
FROM anl_fact_policy_transaction t
LEFT JOIN anl_dim_policy p ON t.policy_key=p.policy_key
WHERE p.policy_key IS NULL;
