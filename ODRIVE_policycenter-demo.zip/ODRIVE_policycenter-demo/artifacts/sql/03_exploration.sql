-- LAYER 3: EXPLORATION
-- Enriched joins. 1:1 enriched from RAW. Exposed to Data Scientists for ML activities.
-- ─────────────────────────────────────────────────────────────────────────────

DROP TABLE IF EXISTS exp_policy_enriched;
CREATE TABLE exp_policy_enriched (
    policy_id TEXT, policy_number TEXT, lob TEXT, product_code TEXT,
    agent_id TEXT, agent_name TEXT, agency_name TEXT, region TEXT, agent_state TEXT,
    insured_name TEXT,  -- PII: retained here for DS use only
    policy_state TEXT, policy_status TEXT,
    term_number INTEGER, effective_date TEXT, expiration_date TEXT,
    written_premium REAL, renewal_flag INTEGER, lapse_flag INTEGER, period_status TEXT,
    term_age_days INTEGER, is_active INTEGER, load_date TEXT
);
INSERT INTO exp_policy_enriched
SELECT p.policy_id, p.policy_number, p.lob, pr.product_code,
       a.agent_id, a.agent_name, a.agency_name, a.region, a.state,
       p.insured_name,
       p.state, p.status,
       pp.term_number, pp.effective_date, pp.expiration_date,
       pp.written_premium, pp.renewal_flag, pp.lapse_flag, pp.status,
       CAST((julianday('now') - julianday(pp.effective_date)) AS INTEGER),
       CASE WHEN pp.status = 'Active' THEN 1 ELSE 0 END,
       :load_date
FROM raw_policy p
JOIN raw_policy_period pp ON p.policy_id = pp.policy_id
JOIN raw_agent a          ON p.agent_id   = a.agent_id
JOIN raw_product pr       ON p.product_id = pr.product_id
WHERE p.load_date = :load_date AND pp.load_date = :load_date
  AND a.load_date = :load_date AND pr.load_date = :load_date;

DROP TABLE IF EXISTS exp_quote_enriched;
CREATE TABLE exp_quote_enriched (
    quote_id TEXT, quote_type TEXT, quote_date TEXT, effective_date TEXT,
    policy_id TEXT, policy_number TEXT, period_id TEXT,
    lob TEXT, product_code TEXT,
    agent_id TEXT, agent_name TEXT, agency_name TEXT, region TEXT,
    quoted_premium REAL, status TEXT, decline_reason TEXT, bound_date TEXT,
    is_bound INTEGER, days_to_bind INTEGER,
    quote_year INTEGER, quote_month INTEGER, quote_quarter INTEGER,
    load_date TEXT
);
INSERT INTO exp_quote_enriched
SELECT q.quote_id, q.quote_type, q.quote_date, q.effective_date,
       q.policy_id, p.policy_number, NULL,
       q.lob, pr.product_code,
       a.agent_id, a.agent_name, a.agency_name, a.region,
       q.quoted_premium, q.status, q.decline_reason, q.bound_date,
       CASE WHEN q.status = 'Bound' THEN 1 ELSE 0 END,
       CASE WHEN q.bound_date IS NOT NULL
            THEN CAST((julianday(q.bound_date) - julianday(q.quote_date)) AS INTEGER)
            ELSE NULL END,
       CAST(strftime('%Y', q.quote_date) AS INTEGER),
       CAST(strftime('%m', q.quote_date) AS INTEGER),
       CAST((CAST(strftime('%m', q.quote_date) AS INTEGER)+2)/3 AS INTEGER),
       :load_date
FROM raw_quote q
LEFT JOIN raw_policy  p  ON q.policy_id  = p.policy_id  AND p.load_date  = :load_date
LEFT JOIN raw_agent   a  ON q.agent_id   = a.agent_id   AND a.load_date  = :load_date
LEFT JOIN raw_product pr ON q.product_id = pr.product_id AND pr.load_date = :load_date
WHERE q.load_date = :load_date;
