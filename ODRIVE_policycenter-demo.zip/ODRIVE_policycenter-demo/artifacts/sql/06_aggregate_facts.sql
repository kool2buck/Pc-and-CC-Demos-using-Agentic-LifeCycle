-- LAYER 5 (continued): AGGREGATE FACT TABLES
-- anl_fact_policy_aggregate and anl_fact_quote_summary
-- These are the PRIMARY sources for all dashboard KPIs
-- ─────────────────────────────────────────────────────────────────────────────

-- Aggregate Fact: Policy (agent × LOB × year × month grain)
DROP TABLE IF EXISTS anl_fact_policy_aggregate;
CREATE TABLE anl_fact_policy_aggregate (
    agg_key INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_key INTEGER NOT NULL, product_key INTEGER NOT NULL,
    period_year INTEGER NOT NULL, period_month INTEGER NOT NULL, lob TEXT NOT NULL,
    -- KPI 1: Total Premium Written
    total_written_premium REAL NOT NULL,
    -- KPI 2: Policy Count
    policy_count INTEGER NOT NULL,
    -- KPI 3: Components for Renewal Rate
    new_business_count INTEGER NOT NULL,
    renewal_count INTEGER NOT NULL,
    -- KPI 5: Components for Lapse Rate
    lapse_count INTEGER NOT NULL,
    cancellation_count INTEGER NOT NULL,
    -- KPI 4: Average Premium
    avg_premium REAL NOT NULL,
    -- Pre-computed rates (also computable on the fly from counts above)
    renewal_rate REAL NOT NULL,   -- renewal_count / policy_count
    lapse_rate REAL NOT NULL,     -- lapse_count / policy_count
    load_date TEXT NOT NULL
);
INSERT INTO anl_fact_policy_aggregate (agent_key, product_key, period_year, period_month,
    lob, total_written_premium, policy_count, new_business_count, renewal_count,
    lapse_count, cancellation_count, avg_premium, renewal_rate, lapse_rate, load_date)
SELECT
    aa.agent_key,
    adp.product_key,
    CAST(strftime('%Y', pp.effective_date) AS INTEGER),
    CAST(strftime('%m', pp.effective_date) AS INTEGER),
    p.lob,
    ROUND(SUM(pp.written_premium), 2),
    COUNT(DISTINCT p.policy_id),
    SUM(CASE WHEN pp.renewal_flag = 0 THEN 1 ELSE 0 END),
    SUM(CASE WHEN pp.renewal_flag = 1 THEN 1 ELSE 0 END),
    SUM(pp.lapse_flag),
    SUM(CASE WHEN pp.status = 'Cancelled' THEN 1 ELSE 0 END),
    ROUND(AVG(pp.written_premium), 2),
    ROUND(CAST(SUM(CASE WHEN pp.renewal_flag = 1 THEN 1 ELSE 0 END) AS REAL)
        / NULLIF(COUNT(DISTINCT p.policy_id), 0), 4),
    ROUND(CAST(SUM(pp.lapse_flag) AS REAL)
        / NULLIF(COUNT(DISTINCT p.policy_id), 0), 4),
    :load_date
FROM raw_policy_period pp
JOIN raw_policy      p   ON pp.policy_id  = p.policy_id
JOIN anl_dim_agent   aa  ON p.agent_id    = aa.agent_id  AND aa.is_current = 1
JOIN anl_dim_product adp ON p.product_id  = adp.product_id
WHERE pp.load_date = :load_date AND p.load_date = :load_date
GROUP BY aa.agent_key, adp.product_key,
         strftime('%Y', pp.effective_date),
         strftime('%m', pp.effective_date), p.lob;

-- Aggregate Fact: Quote Summary (agent × LOB × quote_type × year × month grain)
-- KPI 9: Hit Ratio source
DROP TABLE IF EXISTS anl_fact_quote_summary;
CREATE TABLE anl_fact_quote_summary (
    summary_key INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_key INTEGER NOT NULL, product_key INTEGER NOT NULL,
    quote_year INTEGER NOT NULL, quote_month INTEGER NOT NULL,
    lob TEXT NOT NULL, quote_type TEXT NOT NULL,
    -- Hit Ratio numerator and denominator
    total_quotes INTEGER NOT NULL,
    bound_count INTEGER NOT NULL,
    -- Decline breakdown (for drill-down)
    declined_count INTEGER NOT NULL,
    expired_count INTEGER NOT NULL,
    inprogress_count INTEGER NOT NULL,
    -- Pre-computed Hit Ratio
    hit_ratio REAL NOT NULL,  -- bound_count / total_quotes
    -- Premium context
    avg_quoted_premium REAL NOT NULL,
    total_quoted_premium REAL NOT NULL,
    load_date TEXT NOT NULL
);
INSERT INTO anl_fact_quote_summary (agent_key, product_key, quote_year, quote_month,
    lob, quote_type, total_quotes, bound_count, declined_count, expired_count,
    inprogress_count, hit_ratio, avg_quoted_premium, total_quoted_premium, load_date)
SELECT
    aa.agent_key,
    adp.product_key,
    CAST(substr(q.date_key, 1, 4) AS INTEGER),
    CAST(substr(q.date_key, 5, 2) AS INTEGER),
    q.lob, q.quote_type,
    COUNT(*),
    SUM(q.is_bound),
    SUM(CASE WHEN q.status = 'Declined'   THEN 1 ELSE 0 END),
    SUM(CASE WHEN q.status = 'Expired'    THEN 1 ELSE 0 END),
    SUM(CASE WHEN q.status = 'InProgress' THEN 1 ELSE 0 END),
    ROUND(CAST(SUM(q.is_bound) AS REAL) / NULLIF(COUNT(*), 0), 4),
    ROUND(AVG(q.quoted_premium), 2),
    ROUND(SUM(q.quoted_premium), 2),
    :load_date
FROM conf_fact_quote q
JOIN anl_dim_agent   aa  ON q.agent_id   = aa.agent_id  AND aa.is_current = 1
JOIN anl_dim_product adp ON q.product_id = adp.product_id
WHERE q.load_date = :load_date
GROUP BY aa.agent_key, adp.product_key,
         substr(q.date_key,1,4), substr(q.date_key,5,2),
         q.lob, q.quote_type;
