-- Sample KPI Queries — Run against policycenter.db
-- Open with: sqlite3 policycenter.db

-- KPI 1: Total Premium Written
SELECT ROUND(SUM(total_written_premium),2) AS total_premium_written
FROM anl_fact_policy_aggregate;

-- KPI 2: Policy Count
SELECT COUNT(*) AS policy_count FROM anl_dim_policy WHERE is_current=1;

-- KPI 3: Renewal Rate
SELECT ROUND(CAST(SUM(renewal_count) AS REAL)/SUM(policy_count)*100,1) AS renewal_rate_pct
FROM anl_fact_policy_aggregate;

-- KPI 9: Hit Ratio (Overall / NB / Renewal)
SELECT
    ROUND(CAST(SUM(bound_count) AS REAL)/SUM(total_quotes)*100,1) AS overall_hit_ratio,
    ROUND(CAST(SUM(CASE WHEN quote_type='NewBusiness' THEN bound_count END) AS REAL)/
          SUM(CASE WHEN quote_type='NewBusiness' THEN total_quotes END)*100,1) AS nb_hit_ratio,
    ROUND(CAST(SUM(CASE WHEN quote_type='Renewal' THEN bound_count END) AS REAL)/
          SUM(CASE WHEN quote_type='Renewal' THEN total_quotes END)*100,1) AS renewal_hit_ratio
FROM anl_fact_quote_summary;

-- Premium by LOB
SELECT lob, ROUND(SUM(total_written_premium),0) AS total_premium
FROM anl_fact_policy_aggregate
GROUP BY lob ORDER BY total_premium DESC;

-- Top 5 Agents
SELECT a.agent_name, ROUND(SUM(f.total_written_premium),0) AS premium
FROM anl_fact_policy_aggregate f
JOIN anl_dim_agent a ON f.agent_key=a.agent_key AND a.is_current=1
GROUP BY f.agent_key, a.agent_name
ORDER BY premium DESC LIMIT 5;
