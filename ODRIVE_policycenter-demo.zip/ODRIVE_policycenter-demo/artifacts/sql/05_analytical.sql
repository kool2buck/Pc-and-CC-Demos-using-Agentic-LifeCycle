-- LAYER 5: ANALYTICAL
-- Type 2 SCD Dimensions + Transaction Fact + Aggregate Fact + Quote Summary
-- ─────────────────────────────────────────────────────────────────────────────

-- Type 2 SCD: Dim Agent
DROP TABLE IF EXISTS anl_dim_agent;
CREATE TABLE anl_dim_agent (
    agent_key INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT NOT NULL, agent_name TEXT NOT NULL,
    agency_name TEXT NOT NULL, region TEXT NOT NULL, state TEXT NOT NULL,
    eff_start TEXT NOT NULL, eff_end TEXT, is_current INTEGER NOT NULL DEFAULT 1,
    load_date TEXT NOT NULL
);
INSERT INTO anl_dim_agent (agent_id, agent_name, agency_name, region, state,
    eff_start, eff_end, is_current, load_date)
SELECT agent_id, agent_name, agency_name, region, state,
       :load_date, NULL, 1, :load_date
FROM conf_dim_agent;

-- Fact: Policy Transaction (transaction grain)
DROP TABLE IF EXISTS anl_fact_policy_transaction;
CREATE TABLE anl_fact_policy_transaction (
    txn_key INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_id TEXT NOT NULL, policy_key INTEGER NOT NULL,
    agent_key INTEGER NOT NULL, product_key INTEGER NOT NULL,
    date_key TEXT NOT NULL, period_id TEXT NOT NULL, lob TEXT NOT NULL,
    transaction_type TEXT NOT NULL, premium_amount REAL NOT NULL,
    commission_rate REAL NOT NULL, commission_amount REAL NOT NULL,
    load_date TEXT NOT NULL
);
INSERT INTO anl_fact_policy_transaction (transaction_id, policy_key, agent_key,
    product_key, date_key, period_id, lob, transaction_type,
    premium_amount, commission_rate, commission_amount, load_date)
SELECT ct.transaction_id,
       ap.policy_key, aa.agent_key, adp.product_key,
       ct.date_key, ct.period_id, ct.lob, ct.transaction_type,
       ct.premium_amount, ct.commission_rate, ct.commission_amount, :load_date
FROM conf_fact_transaction ct
JOIN anl_dim_policy  ap  ON ct.policy_id   = ap.policy_id  AND ap.is_current = 1
JOIN anl_dim_agent   aa  ON ct.agent_id    = aa.agent_id   AND aa.is_current = 1
JOIN anl_dim_product adp ON ct.product_id  = adp.product_id;
