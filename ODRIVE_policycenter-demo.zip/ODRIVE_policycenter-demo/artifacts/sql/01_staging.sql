-- LAYER 1: STAGING
-- 1:1 extract from PolicyCenter source. Fresh each load. No transformations.
-- ─────────────────────────────────────────────────────────────────────────────

DROP TABLE IF EXISTS stg_agent;
CREATE TABLE stg_agent (
    agent_id TEXT, agent_name TEXT, agency_name TEXT,
    region TEXT, state TEXT, created_date TEXT, stg_load_date TEXT
);
INSERT INTO stg_agent
SELECT agent_id, agent_name, agency_name, region, state, created_date, :load_date
FROM pc_agent;

DROP TABLE IF EXISTS stg_product;
CREATE TABLE stg_product (
    product_id TEXT, lob TEXT, product_name TEXT, product_code TEXT, stg_load_date TEXT
);
INSERT INTO stg_product
SELECT product_id, lob, product_name, product_code, :load_date
FROM pc_product;

DROP TABLE IF EXISTS stg_policy;
CREATE TABLE stg_policy (
    policy_id TEXT, policy_number TEXT, product_id TEXT, lob TEXT, agent_id TEXT,
    insured_name TEXT, state TEXT, status TEXT, created_date TEXT, stg_load_date TEXT
);
INSERT INTO stg_policy
SELECT policy_id, policy_number, product_id, lob, agent_id,
       insured_name, state, status, created_date, :load_date
FROM pc_policy;

DROP TABLE IF EXISTS stg_policy_period;
CREATE TABLE stg_policy_period (
    period_id TEXT, policy_id TEXT, term_number INTEGER, effective_date TEXT,
    expiration_date TEXT, written_premium REAL, renewal_flag INTEGER,
    lapse_flag INTEGER, status TEXT, stg_load_date TEXT
);
INSERT INTO stg_policy_period
SELECT period_id, policy_id, term_number, effective_date, expiration_date,
       written_premium, renewal_flag, lapse_flag, status, :load_date
FROM pc_policy_period;

DROP TABLE IF EXISTS stg_transaction;
CREATE TABLE stg_transaction (
    transaction_id TEXT, policy_id TEXT, period_id TEXT, agent_id TEXT, lob TEXT,
    transaction_type TEXT, transaction_date TEXT, premium_amount REAL,
    commission_rate REAL, commission_amount REAL, stg_load_date TEXT
);
INSERT INTO stg_transaction
SELECT transaction_id, policy_id, period_id, agent_id, lob,
       transaction_type, transaction_date, premium_amount,
       commission_rate, commission_amount, :load_date
FROM pc_transaction;

DROP TABLE IF EXISTS stg_quote;
CREATE TABLE stg_quote (
    quote_id TEXT, policy_id TEXT, agent_id TEXT, lob TEXT, product_id TEXT,
    quote_type TEXT, quote_date TEXT, effective_date TEXT, quoted_premium REAL,
    status TEXT, decline_reason TEXT, bound_date TEXT, stg_load_date TEXT
);
INSERT INTO stg_quote
SELECT quote_id, policy_id, agent_id, lob, product_id,
       quote_type, quote_date, effective_date, quoted_premium,
       status, decline_reason, bound_date, :load_date
FROM pc_quote;
