-- PolicyCenter ETL Orchestration Master Script
-- Run this to execute all 5 layers in sequence
-- Usage: python3 run_etl.py (calls each script in order)

-- Step 1: STAGING (fresh extract)
-- Source: pc_agent, pc_product, pc_policy, pc_policy_period, pc_transaction, pc_quote
-- Target: stg_agent, stg_product, stg_policy, stg_policy_period, stg_transaction, stg_quote

-- Step 2: RAW (append-only archive)
-- Source: stg_* tables
-- Target: raw_* tables (never truncated)

-- Step 3: EXPLORATION (enriched joins for DS/ML)
-- Source: raw_* tables
-- Target: exp_policy_enriched, exp_transaction_enriched, exp_quote_enriched

-- Step 4: CONFORMED (3NF dimensional model)
-- Source: exp_* tables
-- Target: conf_dim_*, conf_fact_transaction, conf_fact_quote

-- Step 5: ANALYTICAL (Type 2 SCD + aggregate facts)
-- Source: conf_* tables
-- Target: anl_dim_* (SCD), anl_fact_policy_transaction,
--          anl_fact_policy_aggregate, anl_fact_quote_summary

-- Verify: Run all 9 acceptance criteria from tdd/SKILL.md
