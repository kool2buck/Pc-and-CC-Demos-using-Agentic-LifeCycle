-- LAYER 2: RAW
-- Append-only historical archive. Never truncated. Dedup on load_date.
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS raw_agent (
    agent_id TEXT, agent_name TEXT, agency_name TEXT,
    region TEXT, state TEXT, created_date TEXT, load_date TEXT
);
INSERT INTO raw_agent
SELECT agent_id, agent_name, agency_name, region, state, created_date, :load_date
FROM stg_agent
WHERE NOT EXISTS (SELECT 1 FROM raw_agent r
                  WHERE r.agent_id = stg_agent.agent_id AND r.load_date = :load_date);

CREATE TABLE IF NOT EXISTS raw_policy (
    policy_id TEXT, policy_number TEXT, product_id TEXT, lob TEXT, agent_id TEXT,
    insured_name TEXT, state TEXT, status TEXT, created_date TEXT, load_date TEXT
);
INSERT INTO raw_policy
SELECT policy_id, policy_number, product_id, lob, agent_id,
       insured_name, state, status, created_date, :load_date
FROM stg_policy
WHERE NOT EXISTS (SELECT 1 FROM raw_policy r
                  WHERE r.policy_id = stg_policy.policy_id AND r.load_date = :load_date);

CREATE TABLE IF NOT EXISTS raw_transaction (
    transaction_id TEXT, policy_id TEXT, period_id TEXT, agent_id TEXT, lob TEXT,
    transaction_type TEXT, transaction_date TEXT, premium_amount REAL,
    commission_rate REAL, commission_amount REAL, load_date TEXT
);
INSERT INTO raw_transaction
SELECT transaction_id, policy_id, period_id, agent_id, lob,
       transaction_type, transaction_date, premium_amount,
       commission_rate, commission_amount, :load_date
FROM stg_transaction
WHERE NOT EXISTS (SELECT 1 FROM raw_transaction r
                  WHERE r.transaction_id = stg_transaction.transaction_id AND r.load_date = :load_date);

CREATE TABLE IF NOT EXISTS raw_quote (
    quote_id TEXT, policy_id TEXT, agent_id TEXT, lob TEXT, product_id TEXT,
    quote_type TEXT, quote_date TEXT, effective_date TEXT, quoted_premium REAL,
    status TEXT, decline_reason TEXT, bound_date TEXT, load_date TEXT
);
INSERT INTO raw_quote
SELECT quote_id, policy_id, agent_id, lob, product_id,
       quote_type, quote_date, effective_date, quoted_premium,
       status, decline_reason, bound_date, :load_date
FROM stg_quote
WHERE NOT EXISTS (SELECT 1 FROM raw_quote r
                  WHERE r.quote_id = stg_quote.quote_id AND r.load_date = :load_date);
