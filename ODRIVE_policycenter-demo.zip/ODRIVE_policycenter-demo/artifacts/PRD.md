# Product Requirements Document
## PolicyCenter Business Dashboard Demo

| Field        | Value                          |
|--------------|--------------------------------|
| Version      | 2.0 (Loop 2 — 96/100 PASS)     |
| Date         | 2026-06-16                     |
| Agent        | to-prd v2.0                    |
| Input        | BRD v2.0 (grillmewithdocs)     |

## 1. Architecture
SOURCE (Guidewire PC) → STAGING → RAW → EXPLORATION → CONFORMED → ANALYTICAL
Plus: Quote stream parallel through all 5 layers.

## 2. Data Lineage per KPI
| KPI                  | Analytical Table                    | Column(s)                          |
|----------------------|-------------------------------------|------------------------------------|
| Total Premium Written| anl_fact_policy_aggregate           | SUM(total_written_premium)         |
| Policy Count         | anl_dim_policy                      | COUNT(*) WHERE is_current=1        |
| Renewal Rate         | anl_fact_policy_aggregate           | renewal_count / policy_count       |
| Average Premium      | anl_fact_policy_aggregate           | total_written_premium / policy_count|
| Lapse Rate           | anl_fact_policy_aggregate           | lapse_count / policy_count         |
| 30-Day Trend         | anl_fact_policy_transaction+dim_date| SUM(premium_amount) by full_date   |
| Top 5 Agents         | anl_fact_policy_aggregate+dim_agent | SUM(total_written_premium)         |
| Premium by LOB       | anl_fact_policy_aggregate           | SUM(total_written_premium) by lob  |
| Hit Ratio            | anl_fact_quote_summary              | bound_count / total_quotes         |

## 3. Sign-Off Gate
- Trigger: TDD ≥92%, QA-100 ≥92%
- Presents: KPI table to stakeholder
- Unlock: Stakeholder types APPROVED
- Record: grading/grade-records/grade_business-signoff_loop1.md

## 4. 3 Output Dashboards
1. **wiki.html** — LLM Wiki (artifacts, Obsidian graph, knowledge base, glossary)
2. **POLICYCENTER_SDLC_DEMO.html** — Agent Pipeline (12 agents, PII tab, SQL terminal, BRD viewer)
3. **dashboard.html** — Business Dashboard (9 KPIs, 5 LOB filter, 5 charts)

## 5. Definition of Done
- LOB filter changes ALL 6 KPI cards + ALL 5 charts simultaneously
- All 9 KPIs show non-zero data for every LOB
- Works at file:// protocol (no server needed)
- Single self-contained HTML per dashboard (CSS+JS+data all embedded)
- Offline capable (no external CDN calls at runtime)
