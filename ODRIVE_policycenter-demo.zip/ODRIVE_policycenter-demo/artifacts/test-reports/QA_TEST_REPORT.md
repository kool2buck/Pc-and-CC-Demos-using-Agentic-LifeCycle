# QA Integration Test Report — PolicyCenter Demo
## Agent: qa-100 v2.0 | Date: 2026-06-16 | Score: 95/100

| Test | Description                                              | Result         | Status  |
|------|----------------------------------------------------------|----------------|---------|
| QA-001 | SOURCE == STAGING row count (transactions)           | 3,975 = 3,975  | ✅ PASS |
| QA-002 | No orphaned policy_keys in anl_fact_policy_transaction| 0 orphans       | ✅ PASS |
| QA-003 | No orphaned agent_keys in anl_fact_policy_transaction | 0 orphans       | ✅ PASS |
| QA-004 | Bound quotes all have valid policy_id                | 1,964/1,964     | ✅ PASS |
| QA-005 | anl_dim_agent is_current=1 count = pc_agent count    | 25 = 25         | ✅ PASS |
| QA-006 | anl_dim_policy is_current=1 count = pc_policy count  | 1,200 = 1,200   | ✅ PASS |
| QA-007 | SUM(premium) conf vs anl within 0.01%               | 0.00% delta     | ✅ PASS |
| QA-008 | anl_fact_quote_summary totals match raw_quote counts | 3,384 = 3,384   | ✅ PASS |
| QA-009 | Cross-LOB distribution within ±2% of source         | Max delta 0.8%  | ✅ PASS |
| QA-010 | Type 2 SCD: zero rows with is_current=1 AND eff_end IS NOT NULL | 0 rows | ✅ PASS |
| QA-011 | Negative premium guard: all agg rows total_written_premium > 0 | 1,471/1,471 | ✅ PASS |
| QA-012 | Hit ratio sanity: bound_count never > total_quotes   | Verified        | ✅ PASS |

## Summary: 12/12 tests passed
## Verdict: ✅ ALL QA INTEGRATION TESTS PASS
## Agent Score: 95/100 (graded by grading-agent)
