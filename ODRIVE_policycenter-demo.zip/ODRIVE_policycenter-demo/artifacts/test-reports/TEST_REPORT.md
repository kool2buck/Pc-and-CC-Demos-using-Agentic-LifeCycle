# TEST_REPORT.md — PolicyCenter Demo TDD Agent
**Date:** 2026-06-16 | **Agent:** tdd v1.0 | **DB:** policycenter.db
**Layer Tested:** ANALYTICAL only | **ACs:** 9 | **Passed:** 9

## Acceptance Criteria Results

| AC    | Description                 | Result              | Status  |
|-------|-----------------------------|---------------------|---------|
| AC-001 | Total premium $0–$50M | 13962087.3 | ✅ PASS |
| AC-002 | Policy count = 1200 | 1200 | ✅ PASS |
| AC-003 | All 5 LOBs present | 5 | ✅ PASS |
| AC-004 | Overall hit ratio 40–75% | 58.04 | ✅ PASS |
| AC-005 | NB hit ratio 30–65% | 48.0 | ✅ PASS |
| AC-006 | Renewal hit ratio 70–98% | 86.43 | ✅ PASS |
| AC-007 | 30-day trend ≥ 10 points | 25 | ✅ PASS |
| AC-008 | Top 5 agents all > $0 | 5/5 | ✅ PASS |
| AC-009 | RR 20-80%; LR <15% | RR=38.9% LR=1.83% | ✅ PASS |

## Summary
- **9/9 ACs passed**
- **Self-score submitted to grading-agent:** 97/100
- **Gate:** 92/100 minimum

## Verdict
✅ ALL 9 ACCEPTANCE CRITERIA PASSED — tdd PASS
