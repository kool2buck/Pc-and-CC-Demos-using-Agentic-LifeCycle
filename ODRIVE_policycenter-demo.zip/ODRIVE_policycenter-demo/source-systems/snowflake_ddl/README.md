# Snowflake DDL Files
Run in this order:
1. 00_create_databases.sql — Create all 6 databases + schemas
2. 01_analytical_tables.sql — Create all analytical layer tables
3. (copy artifacts/sql/05_analytical.sql for dim tables)
4. (copy artifacts/sql/06_aggregate_facts.sql for fact tables)

Connection: Snowflake on Azure (Donegal standard)
Warehouse: COMPUTE_WH (M or L depending on data volume)
