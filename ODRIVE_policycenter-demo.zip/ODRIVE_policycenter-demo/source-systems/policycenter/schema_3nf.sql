-- PolicyCenter 3NF Source Schema (SQLite / Snowflake compatible)
CREATE TABLE IF NOT EXISTS pc_agent (
    agent_id    TEXT PRIMARY KEY,
    agent_name  TEXT NOT NULL,
    agency_name TEXT NOT NULL,
    region      TEXT NOT NULL,
    state       TEXT NOT NULL,
    created_date TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS pc_product (
    product_id   TEXT PRIMARY KEY,
    lob          TEXT NOT NULL,
    product_name TEXT NOT NULL,
    product_code TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS pc_policy (
    policy_id     TEXT PRIMARY KEY,
    policy_number TEXT NOT NULL UNIQUE,
    product_id    TEXT NOT NULL REFERENCES pc_product(product_id),
    lob           TEXT NOT NULL,
    agent_id      TEXT NOT NULL REFERENCES pc_agent(agent_id),
    insured_name  TEXT NOT NULL,  -- PII
    state         TEXT NOT NULL,
    status        TEXT NOT NULL,
    created_date  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS pc_policy_period (
    period_id       TEXT PRIMARY KEY,
    policy_id       TEXT NOT NULL REFERENCES pc_policy(policy_id),
    term_number     INTEGER NOT NULL,
    effective_date  TEXT NOT NULL,
    expiration_date TEXT NOT NULL,
    written_premium REAL NOT NULL,
    renewal_flag    INTEGER NOT NULL DEFAULT 0,
    lapse_flag      INTEGER NOT NULL DEFAULT 0,
    status          TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS pc_transaction (
    transaction_id   TEXT PRIMARY KEY,
    policy_id        TEXT NOT NULL REFERENCES pc_policy(policy_id),
    period_id        TEXT NOT NULL REFERENCES pc_policy_period(period_id),
    agent_id         TEXT NOT NULL REFERENCES pc_agent(agent_id),
    lob              TEXT NOT NULL,
    transaction_type TEXT NOT NULL,
    transaction_date TEXT NOT NULL,
    premium_amount   REAL NOT NULL,
    commission_rate  REAL NOT NULL,
    commission_amount REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS pc_quote (
    quote_id       TEXT PRIMARY KEY,
    policy_id      TEXT REFERENCES pc_policy(policy_id),  -- NULLABLE: NULL if unbound
    agent_id       TEXT NOT NULL REFERENCES pc_agent(agent_id),
    lob            TEXT NOT NULL,
    product_id     TEXT NOT NULL REFERENCES pc_product(product_id),
    quote_type     TEXT NOT NULL,  -- NewBusiness | Renewal
    quote_date     TEXT NOT NULL,
    effective_date TEXT NOT NULL,
    quoted_premium REAL NOT NULL,
    status         TEXT NOT NULL,  -- Bound | Declined | Expired | InProgress
    decline_reason TEXT,           -- NULLABLE: only set if status=Declined
    bound_date     TEXT            -- NULLABLE: only set if status=Bound
);
