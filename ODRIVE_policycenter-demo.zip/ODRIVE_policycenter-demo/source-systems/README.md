# Source Systems — PolicyCenter Demo
## SQLite database simulating Guidewire PolicyCenter

### Database: policycenter.db (7.11 MB)
All source + ETL + analytical tables in one SQLite file.
Use `sqlite3 policycenter.db` or `DB Browser for SQLite` to explore.

### Source Tables (6)
pc_agent (25 rows) | pc_product (5 rows) | pc_policy (1,200 rows)
pc_policy_period (1,964 rows) | pc_transaction (3,975 rows) | pc_quote (3,384 rows)

### Analytical Tables (7)
anl_dim_agent | anl_dim_policy | anl_dim_product | anl_dim_date
anl_fact_policy_transaction | anl_fact_policy_aggregate | anl_fact_quote_summary

### Rebuild from Scratch
```bash
python3 python/01_build_pipeline.py
python3 python/01b_add_quotes.py
```
