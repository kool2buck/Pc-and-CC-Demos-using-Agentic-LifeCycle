# CocoWisdom-style institutional memory — schema

Ported unchanged from `policycenter-demo/Snowflake_AILC/self-learning/wisdom-schema.md`
— the record schema itself doesn't depend on which skill layout (`_skills/`
here vs. `Snowflake_AILC/agents/`) sits alongside it. This is the mechanism
that makes the fleet measurably smarter across projects instead of only
within one run. Two append-only, git-committed JSONL files, plus the
promotion rule that turns a pattern into an actual skill change.

## `wisdom/rejections.jsonl`

One line per REWORK signal, ever. Never edited, never deleted.

```json
{
  "run_id": "PC-DEMO-20260616-001",
  "project": "PC_DASHBOARD_DEMO",
  "agent": "grillmewithdocs",
  "loop": 1,
  "category": "Completeness",
  "score": 15,
  "max": 20,
  "gap": "Quote grain not defined (what is one row in pc_quote?)",
  "timestamp": "2026-06-16T14:02:11Z",
  "resolved_in_loop": 2
}
```

Fields are intentionally flat and machine-filterable: any future
grading-agent run can query "every Completeness rejection across every
Donegal project in the last 90 days" without parsing prose.

## `wisdom/approvals.jsonl`

One line per PASS, SHA-bound to the exact artifact that earned it.

```json
{
  "run_id": "PC-DEMO-20260616-001",
  "agent": "grillmewithdocs",
  "loop": 2,
  "artifact_sha256": "9f2b...c41a",
  "score": 95,
  "approved_by": "grading-agent",
  "timestamp": "2026-06-16T14:19:47Z"
}
```

If the artifact is later modified, its hash no longer matches this
record — the approval does not silently carry forward onto a changed file.

## Promotion rule: rejection pattern -> applied skill edit

**Updated 2026-09-28: this now auto-applies. See
`skill-versioning-policy.md` for the full rationale.** A rejection
becomes eligible for promotion to an applied SKILL.md edit when:

1. The same category + a materially similar gap description appears **3 or
   more times** across **2 or more distinct projects** in `rejections.jsonl`.
   This detection threshold is unchanged — a single project still can't
   trigger promotion on its own, no matter how many times a gap recurs
   inside it.
2. The skill-improver process drafts a concrete instruction addition — not
   a vague reminder, a specific guardrail, decision tree, or default: "what
   did we just learn that we should add to the skill file?"
3. The skill-improver process **applies it directly** — commits a new
   `_skills/<agent>/SKILL_v{n}.md` (the same mechanism the existing
   informal `SKILL_v2.md` files used, now governed rather than ad hoc),
   writes the change to `../governance/proposals/<agent>-<date>.diff` as a
   record of what was applied and why. No human accepts or discards it
   first.
4. A separate, unrelated in-run path also exists: an agent that fails its
   own rubric can draft and apply a Minor edit to its own SKILL.md
   immediately, without waiting for the cross-project threshold, capped
   at 3 loops per run. See `skill-versioning-policy.md` for how the two
   paths relate.

Major changes (role, tools, `boundary_tier`) are the one category still
excluded from this — those remain `HUMAN REQUIRED` per
`../governance/cocoplus.toml`, without exception.

## Why this design, and what changed from the original one

The original design's rationale, kept here since it still explains the
*detection* threshold (even though the *application* step it was arguing
for no longer applies): auto-applying on a first or second occurrence
risks a skill over-correcting for a pattern that was actually a one-off.
That's still true, and it's still why 3-occurrences-across-2-projects is
the bar rather than 1. What changed is the belief that a human approval
step was the only way to guard against that risk — the 3-retry cap on
the in-run path, and the 2-project requirement on this cross-project
path, are now treated as sufficient controls on their own. A human only
re-enters if an agent still can't pass after exhausting its 3 autonomous
attempts (`escalation:max_loops_exhausted_without_pass` in
`../governance/cocoplus.toml`).
