# Wisdom logs — provenance note (ODRIVE copy)

This folder did not exist in `ODRIVE_policycenter-demo` before 2026-09-28.
`rejections.jsonl` and `approvals.jsonl` were ported in from the sibling
project `policycenter-demo/Snowflake_AILC/self-learning/wisdom/`, where
they were originally backfilled from real grade records.

That backfill is valid here unchanged: `grading/grade-records/` in this
folder is byte-identical to `policycenter-demo/grading/grade-records/`
(verified via `diff -rq`, no differences), so the same 15 rejection
entries and 12 SHA-bound approval entries — and their recorded
`artifact_sha256` hashes — apply directly. Hashes were re-verified
against this folder's own copies of the grade-record files; all 12
match.

## Layout difference from the Snowflake port

`policycenter-demo` ported these agents into `Snowflake_AILC/agents/<id>/SKILL.md`.
This folder still uses the original, unported layout:
`_skills/<id>/SKILL.md`, with four agents (`grillmewithdocs`, `to-prd`,
`schema-discovery`, `qa-100`) additionally carrying an informal
`SKILL_v2.md` next to the original — the exact "no stated rule for who
was allowed to write the v2 or when" pattern that
`skill-versioning-policy.md` (copied into `../skill-versioning-policy.md`)
was written to replace. Nothing in this folder's `_skills/` was changed —
this port only adds the wisdom/governance layer alongside it, it doesn't
migrate the skill files themselves.

## Same known gaps as the source copy

- `grillmewithdocs` loop 1 and loop 2 grade records are 0 bytes here too
  (identical to the source copy) — no rejection entry exists for it, and
  none was invented. The real gap data lives instead under the
  `ba-grill` grade records, which this folder also carries unchanged.
- `business-signoff` loop 1 grade record is also 0 bytes — no approval
  entry exists for it for the same reason.
