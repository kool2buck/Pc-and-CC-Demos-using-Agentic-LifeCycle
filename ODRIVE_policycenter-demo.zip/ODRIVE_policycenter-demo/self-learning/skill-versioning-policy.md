# Skill versioning policy (ODRIVE copy)

**Updated 2026-09-28 — autonomous self-heal model.** The prior version of
this policy required a human design-system owner to approve every skill
edit before it could be applied. That was changed after an explicit
decision: the fleet does not need a human in the loop for an agent to fix
itself, as long as it converges within 3 retries. A human is now only
pulled in if an agent is still failing the rubric after its third
attempt.

## What's autonomous now, and what still isn't

| Change type | Who drafts it | Who applies it | Gate |
|---|---|---|---|
| Patch (`v1.1`) | Any agent, or the skill-improver process | Same | None — logged, not reviewed |
| Minor (`v2.0` — what the existing `SKILL_v2.md` files already are) | The failing agent itself (in-run) or the skill-improver process (cross-project) | Same — auto-applied | None, provided it converges within `max_loops_per_agent: 3` |
| Major (`v3.0`) | Human only | Human only | `skill_edit:major` — still HUMAN REQUIRED, no exception |

The four existing `SKILL_v2.md` files (`grillmewithdocs`, `to-prd`,
`schema-discovery`, `qa-100`) were written before any gate existed at
all — autonomous or human. Under this policy they'd now be legitimate,
retroactively: a Minor edit, drafted and applied by the agent itself,
logged rather than reviewed. That's a real change in what "informal"
means here — it's no longer a gap to close, it's the intended path.

## Two triggers for a Minor edit, one rule for both

**In-run self-heal (new default path).** An agent fails the rubric on
loop *N* of a 3-loop cap (see `../_skills/orchestrator/fleet_config.json`
→ `max_loops_per_agent: 3`). It reads its own numbered gap list from
`grading-agent`, drafts a Minor SKILL.md addition addressing the specific
gap, applies it to its own `SKILL.md` (or `SKILL_v{n}.md`) immediately,
and resubmits on loop *N+1*. No human reviews this. If the agent still
hasn't passed by loop 3, `escalation:max_loops_exhausted_without_pass`
fires and a human is brought in — this is the only point a human enters
the in-run path.

**Cross-project pattern promotion (unchanged trigger, changed gate).** A
rejection is still only eligible for promotion once the same category +
a materially similar gap appears 3+ times across 2+ distinct projects in
`wisdom/rejections.jsonl` (see `wisdom-schema.md`) — that detection logic
doesn't change; this single project still can't trigger it alone. What
changed is what happens once it trips: the skill-improver process now
drafts **and applies** the addition directly, versions it, and logs it —
it no longer waits in `governance/proposals/` for a named human to
accept it.

## Why loosen this, and where the line still is

The prior design's own rationale (kept here for the record, not because
it still applies to Patch/Minor): auto-applying on a first or second
occurrence risks a skill over-correcting for what was actually a one-off.
The 3-retry cap and the 3x/2-project threshold are the controls that
answer that concern now, in place of a human reviewer. Major changes
keep the human gate because that risk isn't about correctness of
content, it's about scope of authority — a wrong guardrail is a bad
sentence in a SKILL.md; a wrong tool grant or boundary-tier change is a
different agent.

## Distribution

This original (unported) fleet's distribution mechanism is still
informal — manual re-paste of a skill's prose into each user's own
custom instructions, agent by agent. That gap is unrelated to the
human-approval gate removed above and remains unresolved in this folder
specifically (it's what the Snowflake port in `policycenter-demo` was
built to fix via `cortex skill sync`).
