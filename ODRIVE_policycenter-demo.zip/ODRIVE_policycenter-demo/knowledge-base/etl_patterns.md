# ETL Patterns — Donegal Insurance DW
## Applicable to all Guidewire source system projects

### Pattern 1: No CTAS (Non-Negotiable)
Always CREATE TABLE with explicit schema, then INSERT INTO ... SELECT FROM.
Never: CREATE TABLE foo AS SELECT ...

### Pattern 2: RAW Append-Only
```sql
CREATE TABLE IF NOT EXISTS raw_table (..., load_date TEXT);
INSERT INTO raw_table SELECT ..., :load_date FROM stg_table
WHERE NOT EXISTS (SELECT 1 FROM raw_table r WHERE r.pk = stg_table.pk AND r.load_date = :load_date);
```

### Pattern 3: Type 2 SCD
```sql
-- New record insert (first load)
INSERT INTO anl_dim_entity (nat_key, ..., eff_start, eff_end, is_current)
SELECT ..., :load_date, NULL, 1 FROM conf_dim_entity;

-- On change (subsequent load):
UPDATE anl_dim_entity SET eff_end = :load_date, is_current = 0
WHERE nat_key = :changed_key AND is_current = 1;
INSERT INTO anl_dim_entity (nat_key, ..., eff_start, eff_end, is_current)
VALUES (:changed_key, ..., :load_date, NULL, 1);
```

### Pattern 4: Aggregate Fact Build
Aggregate in ANALYTICAL, not CONFORMED.
Source: raw_* tables joined through anl_dim_* (for surrogate keys).
Grain: explicitly define in SKILL.md before writing SQL.
