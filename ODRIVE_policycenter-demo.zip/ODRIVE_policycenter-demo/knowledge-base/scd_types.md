# Slowly Changing Dimensions — Types & Implementation
## For PolicyCenter Demo Analytical Layer

### Type 1 (Overwrite) — used for: anl_dim_product
Dimension rarely changes. When it does, overwrite the record.
No history preserved. Simple. Suitable for product definitions.

### Type 2 (Historical) — used for: anl_dim_agent, anl_dim_policy
Dimension can change (agent moves agency; policy status changes).
New row added with new eff_start. Old row gets eff_end = :load_date, is_current = 0.
Always filter: WHERE is_current = 1 for current state.
Always join to fact tables on surrogate key (agent_key, policy_key), NOT natural key.

### Type 6 (Hybrid 1+2+3) — not used in this demo
Tracks current and prior value plus full history. Overkill for demo. Note for production.
