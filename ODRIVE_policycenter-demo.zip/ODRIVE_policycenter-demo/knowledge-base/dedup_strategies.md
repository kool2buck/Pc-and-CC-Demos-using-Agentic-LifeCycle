# Deduplication Strategies — PolicyCenter ETL

## RAW Layer Dedup
Use NOT EXISTS guard on (natural_key, load_date):
```sql
WHERE NOT EXISTS (SELECT 1 FROM raw_t r WHERE r.pk = stg.pk AND r.load_date = :load_date)
```
Prevents re-processing the same extract date twice.

## Analytical Layer Dedup (Type 2 SCD)
Query pattern to avoid duplicates in queries:
```sql
WHERE is_current = 1  -- Always filter to current version
```
When building facts: JOIN on natural_key AND is_current = 1.

## Quote Dedup
pc_quote.quote_id is globally unique. No dedup needed at source.
Unbound quotes (policy_id IS NULL) are valid — not duplicates of policies.
