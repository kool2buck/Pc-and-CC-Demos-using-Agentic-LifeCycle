# Quote-to-Bind (Hit Ratio) Patterns — PolicyCenter
## Added in PC_DASHBOARD_DEMO (not in Claims Center demo)

### What is Hit Ratio?
Hit Ratio = bound_count / total_quotes
The percentage of quotes that resulted in a bound policy.

### Why Two Hit Ratios?
New Business Hit Ratio: First-time quote for a new customer. Typically lower (~48%).
Reason: Price shopping, competition.

Renewal Hit Ratio: Quote sent to existing policyholder. Typically high (~86%).
Reason: Inertia, established relationship.

### What drives low NB Hit Ratio?
1. PriceDeclined: policyholder chose a competitor
2. CoverageDeclined: coverage terms rejected
3. NoResponse: policyholder never replied
4. CompetitorSelected: active competitor win

### In the ETL
Source: pc_quote.status in ('Bound','Declined','Expired','InProgress')
Binding link: pc_quote.policy_id (non-null) → pc_policy.policy_id
Grain in analytical: anl_fact_quote_summary (agent × LOB × type × year × month)
