# PII Masking Rules — PolicyCenter Demo

## PII Fields in Scope
| Field         | Table       | Classification | Action                              |
|---------------|-------------|----------------|-------------------------------------|
| insured_name  | pc_policy   | HIGH-PII       | Exclude from anl_fact_* tables      |
| insured_name  | stg_policy  | HIGH-PII       | Carry through (staging = 1:1 copy)  |
| insured_name  | raw_policy  | HIGH-PII       | Carry through (historical archive)  |
| insured_name  | exp_policy_enriched | HIGH-PII | Carry through (DS use, flagged) |
| insured_name  | anl_dim_policy | HIGH-PII   | Present (dim only, not fact)        |

## PII Demo (3-Role Model in POLICYCENTER_SDLC_DEMO.html)
- **analyst_read**: sees base64-encoded ciphertext for insured_name
- **regional_mgr_pa**: sees decrypted names for PA/DE/NJ policies; other states encrypted
- **data_gov_officer**: sees all decrypted — full access for governance review

## Production Notes
- Real encryption: AES-256-GCM via Snowflake ENCRYPT() function
- Key management: Azure Key Vault (Donegal standard)
- Row-level access: Snowflake Row Access Policy on anl_dim_policy
- Audit log: Every decryption event logged to cc_decryption_log
