# Aggregate Fact Design — New in PC Demo
## anl_fact_policy_aggregate and anl_fact_quote_summary

### Why Aggregate Facts?
With 1,200 policies × 1,964 periods × 25 agents × 5 LOBs:
- Dashboard must show "Total Premium by LOB" in <100ms
- Aggregating from anl_fact_policy_transaction each time = too slow for browser
- Pre-aggregate at agent×LOB×year×month grain = sub-10ms queries

### Trade-off
| Design | Query Speed | Storage | Flexibility |
|--------|-------------|---------|-------------|
| Transaction fact only | Slow (aggregate on-demand) | Low | High |
| Aggregate fact only | Fast | Medium | Low |
| Both (this demo) | Fast | Medium+ | High |

We built BOTH:
- anl_fact_policy_transaction: for 30-day trend (requires daily grain)
- anl_fact_policy_aggregate: for all other KPIs (requires month grain)

### Grain Rule
Never mix grains in one fact table.
The aggregate fact cannot answer "daily premium" — that requires the transaction fact.
