# Lessons Learned — PolicyCenter Demo
## Session: 2026-06-16

### LL-001: Quote Grain Must Be Defined First
grillmewithdocs Loop 1 failed (80/100) because pc_quote grain was undefined.
**Lesson**: Define grain for EVERY source table in the BRD before schema discovery begins.

### LL-002: Nullable FK is a Valid Business Rule
pc_quote.policy_id is NULL for unbound quotes. This is NOT a data quality issue.
**Lesson**: Document nullable FKs in Schema Audit. Distinguish "data error" from "valid state."

### LL-003: Renewal Rate Has Two Interpretations
Period-level rate (38.9%) vs policy-level rate (62%) are both valid.
**Lesson**: Always specify which level in the BRD. Disclose both in the dashboard.

### LL-004: Negative Premiums Are Not Defects
Endorsements and cancellations post negative premium_amount to pc_transaction.
**Lesson**: Use pc_policy_period.written_premium for KPI 1. Use pc_transaction only for trend.

### LL-005: ba-grill → grillmewithdocs
The correct agent name is grillmewithdocs, not ba-grill.
**Lesson**: Always check the exact agent name from the previous demo before renaming.
