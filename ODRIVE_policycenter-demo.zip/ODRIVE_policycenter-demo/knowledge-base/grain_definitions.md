# Grain Definitions — PolicyCenter Demo

## Source Layer
| Table              | Grain                          | PK             |
|--------------------|--------------------------------|----------------|
| pc_agent           | One row per agent              | agent_id       |
| pc_product         | One row per product/LOB        | product_id     |
| pc_policy          | One row per policy             | policy_id      |
| pc_policy_period   | One row per policy per term    | period_id      |
| pc_transaction     | One row per financial event    | transaction_id |
| pc_quote           | One row per quote issued       | quote_id       |

## Analytical Layer
| Table                        | Grain                                              |
|------------------------------|----------------------------------------------------|
| anl_dim_agent                | One row per agent per version (SCD2)               |
| anl_dim_policy               | One row per policy per version (SCD2)              |
| anl_dim_product              | One row per product (static)                       |
| anl_dim_date                 | One row per calendar date                          |
| anl_fact_policy_transaction  | One row per transaction_id                         |
| anl_fact_policy_aggregate    | One row per agent × LOB × year × month             |
| anl_fact_quote_summary       | One row per agent × LOB × quote_type × year × month|
