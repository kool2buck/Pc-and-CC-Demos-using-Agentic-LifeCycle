#!/usr/bin/env python3
"""
PolicyCenter Demo — Add Hit Ratio KPI
Adds pc_quote source → stg → raw → exp → conformed → analytical
Surgical addition: opens existing DB, adds quote tables, re-verifies all 9 KPIs
"""
import sqlite3, random, os
from datetime import datetime, timedelta

DB_PATH    = '/home/claude/policycenter_demo/policycenter.db'
LOAD_DATE  = datetime.now().strftime('%Y-%m-%d')
TODAY      = datetime.now()
TODAY_STR  = TODAY.strftime('%Y-%m-%d')
random.seed(99)

def r2(v): return round(v, 2)
def step(m): print(f"\n{'─'*62}\n▶  {m}")
def ok(m):   print(f"   ✅  {m}")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 1 — Add pc_quote to SOURCE
# ─────────────────────────────────────────────────────────────────────────────
def add_source_quotes(conn):
    step("STEP 1 — SOURCE: Adding pc_quote (quotes tied to policies)")
    c = conn.cursor()

    c.executescript("""
        DROP TABLE IF EXISTS pc_quote;
        CREATE TABLE pc_quote (
            quote_id        TEXT PRIMARY KEY,
            policy_id       TEXT,              -- NULL if not bound
            agent_id        TEXT NOT NULL,
            lob             TEXT NOT NULL,
            product_id      TEXT NOT NULL,
            quote_type      TEXT NOT NULL,     -- NewBusiness | Renewal
            quote_date      TEXT NOT NULL,
            effective_date  TEXT NOT NULL,
            quoted_premium  REAL NOT NULL,
            status          TEXT NOT NULL,     -- Bound | Declined | Expired | InProgress
            decline_reason  TEXT,              -- populated when status != Bound
            bound_date      TEXT               -- populated when status = Bound
        );
    """)

    # Pull all policies + their first effective dates + LOB + agent + product
    policies = c.execute("""
        SELECT p.policy_id, p.agent_id, p.lob, p.product_id,
               pp.effective_date, pp.term_number, pp.renewal_flag,
               pp.written_premium, pp.status
        FROM pc_policy p
        JOIN pc_policy_period pp ON p.policy_id = pp.policy_id
        ORDER BY p.policy_id, pp.term_number
    """).fetchall()

    # Group by policy_id, track min effective date (first term) and renewal term
    from collections import defaultdict
    pol_map = defaultdict(list)
    for row in policies:
        pol_map[row[0]].append(row)

    # Premium ranges for unbound quotes by LOB
    lob_ranges = {
        'PersonalAuto':   (800,   2500),
        'Homeowners':     (1000,  3500),
        'CommercialAuto': (3000,  15000),
        'DwellingFire':   (600,   2000),
        'WorkersComp':    (5000,  50000),
    }
    lob_products = {
        'PersonalAuto': 'PRD001', 'Homeowners': 'PRD002',
        'CommercialAuto': 'PRD003', 'DwellingFire': 'PRD004', 'WorkersComp': 'PRD005'
    }
    lob_list   = list(lob_ranges.keys())
    lob_weights = [0.25, 0.25, 0.20, 0.15, 0.15]

    decline_reasons = ['PriceDeclined','CoverageDeclined','CompetitorSelected','NoResponse']
    decline_weights = [0.40, 0.25, 0.22, 0.13]

    quote_rows = []
    qctr = 1

    # ── BOUND QUOTES: one per policy period (NB + Renewal) ──────────────────
    bound_nb_count = 0
    bound_ren_count = 0
    for pol_id, terms in pol_map.items():
        for row in terms:
            _, agt_id, lob, prod_id, eff_date, term_num, renewal_flag, written_prem, _ = row
            eff_dt = datetime.strptime(eff_date, '%Y-%m-%d')
            # Quote issued 5-20 days before effective
            q_dt = (eff_dt - timedelta(days=random.randint(5, 20))).strftime('%Y-%m-%d')
            q_type = 'Renewal' if renewal_flag else 'NewBusiness'
            # Quoted premium ± small variation from written premium
            q_prem = r2(written_prem * random.uniform(0.97, 1.03))
            quote_rows.append((
                f'QUO{qctr:08d}', pol_id, agt_id, lob, prod_id,
                q_type, q_dt, eff_date, q_prem,
                'Bound', None, eff_date
            ))
            qctr += 1
            if renewal_flag: bound_ren_count += 1
            else:            bound_nb_count  += 1

    ok(f"Bound NB quotes:      {bound_nb_count:,}")
    ok(f"Bound Renewal quotes: {bound_ren_count:,}")

    # Pull agent list for unbound quotes
    agents = c.execute("SELECT agent_id FROM pc_agent").fetchall()
    agent_ids = [a[0] for a in agents]

    # ── UNBOUND NB QUOTES: ~1,300 (prospects that didn't convert) ──────────
    nb_unbound = 1300
    for _ in range(nb_unbound):
        lob     = random.choices(lob_list, weights=lob_weights)[0]
        agt_id  = random.choice(agent_ids)
        prod_id = lob_products[lob]
        # Quote dates spread over past 2 years
        q_dt_obj = TODAY - timedelta(days=random.randint(10, 720))
        eff_dt_obj = q_dt_obj + timedelta(days=random.randint(5, 30))
        q_prem  = r2(random.uniform(*lob_ranges[lob]))
        status  = random.choices(['Declined','Expired','InProgress'], weights=[0.48, 0.35, 0.17])[0]
        dr      = random.choices(decline_reasons, weights=decline_weights)[0] if status == 'Declined' else None
        quote_rows.append((
            f'QUO{qctr:08d}', None, agt_id, lob, prod_id,
            'NewBusiness', q_dt_obj.strftime('%Y-%m-%d'), eff_dt_obj.strftime('%Y-%m-%d'),
            q_prem, status, dr, None
        ))
        qctr += 1

    # ── UNBOUND RENEWAL QUOTES: ~120 (non-renewals / lapsed) ────────────────
    ren_unbound = 120
    for _ in range(ren_unbound):
        lob     = random.choices(lob_list, weights=lob_weights)[0]
        agt_id  = random.choice(agent_ids)
        prod_id = lob_products[lob]
        q_dt_obj = TODAY - timedelta(days=random.randint(30, 500))
        eff_dt_obj = q_dt_obj + timedelta(days=random.randint(15, 45))
        q_prem  = r2(random.uniform(*lob_ranges[lob]))
        status  = random.choices(['Declined','Expired'], weights=[0.55, 0.45])[0]
        dr      = random.choices(decline_reasons, weights=decline_weights)[0] if status == 'Declined' else None
        quote_rows.append((
            f'QUO{qctr:08d}', None, agt_id, lob, prod_id,
            'Renewal', q_dt_obj.strftime('%Y-%m-%d'), eff_dt_obj.strftime('%Y-%m-%d'),
            q_prem, status, dr, None
        ))
        qctr += 1

    c.executemany("INSERT INTO pc_quote VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", quote_rows)
    conn.commit()

    total  = len(quote_rows)
    bound  = sum(1 for r in quote_rows if r[9] == 'Bound')
    ok(f"Total quotes inserted:   {total:,}")
    ok(f"Total bound:             {bound:,}")
    ok(f"Total unbound:           {total-bound:,}")
    return total, bound

# ─────────────────────────────────────────────────────────────────────────────
# STEP 2 — STAGING
# ─────────────────────────────────────────────────────────────────────────────
def add_staging_quotes(conn):
    step("STEP 2 — STAGING: stg_quote (1:1 extract, fresh)")
    c = conn.cursor()
    c.executescript(f"""
        DROP TABLE IF EXISTS stg_quote;
        CREATE TABLE stg_quote (
            quote_id TEXT, policy_id TEXT, agent_id TEXT, lob TEXT, product_id TEXT,
            quote_type TEXT, quote_date TEXT, effective_date TEXT, quoted_premium REAL,
            status TEXT, decline_reason TEXT, bound_date TEXT, stg_load_date TEXT
        );
        INSERT INTO stg_quote
        SELECT quote_id, policy_id, agent_id, lob, product_id,
               quote_type, quote_date, effective_date, quoted_premium,
               status, decline_reason, bound_date, '{LOAD_DATE}'
        FROM pc_quote;
    """)
    conn.commit()
    cnt = c.execute("SELECT COUNT(*) FROM stg_quote").fetchone()[0]
    ok(f"{cnt:,} quotes in STAGING")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 3 — RAW
# ─────────────────────────────────────────────────────────────────────────────
def add_raw_quotes(conn):
    step("STEP 3 — RAW: raw_quote (append-only, never truncated)")
    c = conn.cursor()
    c.executescript(f"""
        CREATE TABLE IF NOT EXISTS raw_quote (
            quote_id TEXT, policy_id TEXT, agent_id TEXT, lob TEXT, product_id TEXT,
            quote_type TEXT, quote_date TEXT, effective_date TEXT, quoted_premium REAL,
            status TEXT, decline_reason TEXT, bound_date TEXT, load_date TEXT
        );
        INSERT INTO raw_quote
        SELECT quote_id, policy_id, agent_id, lob, product_id,
               quote_type, quote_date, effective_date, quoted_premium,
               status, decline_reason, bound_date, '{LOAD_DATE}'
        FROM stg_quote
        WHERE NOT EXISTS (
            SELECT 1 FROM raw_quote r WHERE r.quote_id = stg_quote.quote_id AND r.load_date = '{LOAD_DATE}'
        );
    """)
    conn.commit()
    cnt = c.execute("SELECT COUNT(*) FROM raw_quote").fetchone()[0]
    ok(f"{cnt:,} quotes in RAW")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 4 — EXPLORATION
# ─────────────────────────────────────────────────────────────────────────────
def add_exploration_quotes(conn):
    step("STEP 4 — EXPLORATION: exp_quote_enriched (joined, for DS/ML)")
    c = conn.cursor()
    c.executescript(f"""
        DROP TABLE IF EXISTS exp_quote_enriched;
        CREATE TABLE exp_quote_enriched (
            quote_id TEXT, quote_type TEXT, quote_date TEXT, effective_date TEXT,
            policy_id TEXT, policy_number TEXT,
            lob TEXT, product_code TEXT,
            agent_id TEXT, agent_name TEXT, agency_name TEXT, region TEXT,
            quoted_premium REAL, status TEXT, decline_reason TEXT, bound_date TEXT,
            is_bound INTEGER, days_to_bind INTEGER,
            quote_year INTEGER, quote_month INTEGER, quote_quarter INTEGER,
            load_date TEXT
        );
        INSERT INTO exp_quote_enriched
        SELECT
            q.quote_id, q.quote_type, q.quote_date, q.effective_date,
            q.policy_id, p.policy_number,
            q.lob, pr.product_code,
            a.agent_id, a.agent_name, a.agency_name, a.region,
            q.quoted_premium, q.status, q.decline_reason, q.bound_date,
            CASE WHEN q.status = 'Bound' THEN 1 ELSE 0 END,
            CASE WHEN q.bound_date IS NOT NULL
                 THEN CAST((julianday(q.bound_date) - julianday(q.quote_date)) AS INTEGER)
                 ELSE NULL END,
            CAST(strftime('%Y', q.quote_date) AS INTEGER),
            CAST(strftime('%m', q.quote_date) AS INTEGER),
            CAST((CAST(strftime('%m', q.quote_date) AS INTEGER)+2)/3 AS INTEGER),
            '{LOAD_DATE}'
        FROM raw_quote q
        LEFT JOIN raw_policy  p  ON q.policy_id  = p.policy_id  AND p.load_date  = '{LOAD_DATE}'
        LEFT JOIN raw_agent   a  ON q.agent_id   = a.agent_id   AND a.load_date  = '{LOAD_DATE}'
        LEFT JOIN raw_product pr ON q.product_id = pr.product_id AND pr.load_date = '{LOAD_DATE}'
        WHERE q.load_date = '{LOAD_DATE}';
    """)
    conn.commit()
    cnt = c.execute("SELECT COUNT(*) FROM exp_quote_enriched").fetchone()[0]
    ok(f"{cnt:,} enriched quotes in EXPLORATION")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 5 — CONFORMED
# ─────────────────────────────────────────────────────────────────────────────
def add_conformed_quotes(conn):
    step("STEP 5 — CONFORMED: conf_fact_quote")
    c = conn.cursor()
    c.executescript(f"""
        DROP TABLE IF EXISTS conf_fact_quote;
        CREATE TABLE conf_fact_quote (
            quote_key       INTEGER PRIMARY KEY AUTOINCREMENT,
            quote_id        TEXT NOT NULL,
            policy_id       TEXT,
            agent_id        TEXT NOT NULL,
            product_id      TEXT NOT NULL,
            date_key        TEXT NOT NULL,
            lob             TEXT NOT NULL,
            quote_type      TEXT NOT NULL,
            quoted_premium  REAL NOT NULL,
            status          TEXT NOT NULL,
            decline_reason  TEXT,
            is_bound        INTEGER NOT NULL,
            load_date       TEXT NOT NULL
        );
        INSERT INTO conf_fact_quote (quote_id, policy_id, agent_id, product_id,
            date_key, lob, quote_type, quoted_premium, status, decline_reason, is_bound, load_date)
        SELECT
            q.quote_id, q.policy_id, q.agent_id, q.product_id,
            strftime('%Y%m%d', q.quote_date),
            q.lob, q.quote_type, q.quoted_premium, q.status, q.decline_reason,
            CASE WHEN q.status = 'Bound' THEN 1 ELSE 0 END,
            '{LOAD_DATE}'
        FROM raw_quote q
        WHERE q.load_date = '{LOAD_DATE}';
    """)
    conn.commit()
    cnt = c.execute("SELECT COUNT(*) FROM conf_fact_quote").fetchone()[0]
    ok(f"{cnt:,} quotes in CONFORMED fact table")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 6 — ANALYTICAL
# ─────────────────────────────────────────────────────────────────────────────
def add_analytical_quotes(conn):
    step("STEP 6 — ANALYTICAL: anl_fact_quote_summary (Hit Ratio aggregate)")
    c = conn.cursor()
    c.executescript(f"""
        DROP TABLE IF EXISTS anl_fact_quote_summary;
        CREATE TABLE anl_fact_quote_summary (
            summary_key          INTEGER PRIMARY KEY AUTOINCREMENT,
            agent_key            INTEGER NOT NULL,
            product_key          INTEGER NOT NULL,
            quote_year           INTEGER NOT NULL,
            quote_month          INTEGER NOT NULL,
            lob                  TEXT NOT NULL,
            quote_type           TEXT NOT NULL,
            total_quotes         INTEGER NOT NULL,
            bound_count          INTEGER NOT NULL,
            declined_count       INTEGER NOT NULL,
            expired_count        INTEGER NOT NULL,
            inprogress_count     INTEGER NOT NULL,
            hit_ratio            REAL NOT NULL,
            avg_quoted_premium   REAL NOT NULL,
            total_quoted_premium REAL NOT NULL,
            load_date            TEXT NOT NULL
        );
        INSERT INTO anl_fact_quote_summary (agent_key, product_key, quote_year, quote_month,
            lob, quote_type, total_quotes, bound_count, declined_count, expired_count,
            inprogress_count, hit_ratio, avg_quoted_premium, total_quoted_premium, load_date)
        SELECT
            aa.agent_key,
            adp.product_key,
            CAST(substr(q.date_key, 1, 4) AS INTEGER),
            CAST(substr(q.date_key, 5, 2) AS INTEGER),
            q.lob,
            q.quote_type,
            COUNT(*),
            SUM(q.is_bound),
            SUM(CASE WHEN q.status = 'Declined'    THEN 1 ELSE 0 END),
            SUM(CASE WHEN q.status = 'Expired'     THEN 1 ELSE 0 END),
            SUM(CASE WHEN q.status = 'InProgress'  THEN 1 ELSE 0 END),
            ROUND(CAST(SUM(q.is_bound) AS REAL) / NULLIF(COUNT(*), 0), 4),
            ROUND(AVG(q.quoted_premium), 2),
            ROUND(SUM(q.quoted_premium), 2),
            '{LOAD_DATE}'
        FROM conf_fact_quote q
        JOIN anl_dim_agent   aa  ON q.agent_id   = aa.agent_id  AND aa.is_current = 1
        JOIN anl_dim_product adp ON q.product_id = adp.product_id
        WHERE q.load_date = '{LOAD_DATE}'
        GROUP BY aa.agent_key, adp.product_key,
                 CAST(substr(q.date_key, 1, 4) AS INTEGER),
                 CAST(substr(q.date_key, 5, 2) AS INTEGER),
                 q.lob, q.quote_type;
    """)
    conn.commit()
    cnt = c.execute("SELECT COUNT(*) FROM anl_fact_quote_summary").fetchone()[0]
    ok(f"{cnt:,} rows in anl_fact_quote_summary")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 7 — VERIFY ALL 9 KPIs
# ─────────────────────────────────────────────────────────────────────────────
def verify_all_kpis(conn):
    step("STEP 7 — KPI VERIFICATION: All 9 KPIs (8 original + Hit Ratio)")
    c = conn.cursor()

    # KPI 1
    v = c.execute("SELECT ROUND(SUM(total_written_premium),2) FROM anl_fact_policy_aggregate").fetchone()[0]
    ok(f"KPI 1 — Total Premium Written       : ${v:>18,.2f}")

    # KPI 2
    v = c.execute("SELECT COUNT(*) FROM anl_dim_policy WHERE is_current=1").fetchone()[0]
    ok(f"KPI 2 — Policy Count                : {v:>18,}")

    # KPI 3
    v = c.execute("""
        SELECT ROUND(CAST(SUM(renewal_count) AS REAL)/NULLIF(SUM(policy_count),0)*100,2)
        FROM anl_fact_policy_aggregate
    """).fetchone()[0]
    ok(f"KPI 3 — Renewal Rate                : {v:>17.2f}%")

    # KPI 4
    v = c.execute("""
        SELECT ROUND(SUM(total_written_premium)/NULLIF(SUM(policy_count),0),2)
        FROM anl_fact_policy_aggregate
    """).fetchone()[0]
    ok(f"KPI 4 — Average Premium per Policy  : ${v:>18,.2f}")

    # KPI 5
    v = c.execute("""
        SELECT ROUND(CAST(SUM(lapse_count) AS REAL)/NULLIF(SUM(policy_count),0)*100,2)
        FROM anl_fact_policy_aggregate
    """).fetchone()[0]
    ok(f"KPI 5 — Lapse Rate                  : {v:>17.2f}%")

    # KPI 6
    trend = c.execute("""
        SELECT d.full_date, ROUND(SUM(t.premium_amount),2)
        FROM anl_fact_policy_transaction t
        JOIN anl_dim_date d ON t.date_key = d.date_key
        WHERE d.full_date >= date('now','-30 days')
          AND t.transaction_type IN ('NewBusiness','Renewal')
        GROUP BY d.full_date ORDER BY d.full_date
    """).fetchall()
    ok(f"KPI 6 — 30-Day Premium Trend        : {len(trend):>14} data points")

    # KPI 7: Top 5 Agents
    top5 = c.execute("""
        SELECT a.agent_name, ROUND(SUM(f.total_written_premium),2)
        FROM anl_fact_policy_aggregate f
        JOIN anl_dim_agent a ON f.agent_key=a.agent_key
        GROUP BY a.agent_key, a.agent_name ORDER BY 2 DESC LIMIT 5
    """).fetchall()
    ok(f"KPI 7 — Premium by Agent (Top 5):")
    for name, total in top5:
        print(f"             {name:<28} ${total:>12,.2f}")

    # KPI 8: Premium by LOB
    by_lob = c.execute("""
        SELECT lob, ROUND(SUM(total_written_premium),2), SUM(policy_count)
        FROM anl_fact_policy_aggregate GROUP BY lob ORDER BY 2 DESC
    """).fetchall()
    ok(f"KPI 8 — Premium by LOB:")
    for lob, total, cnt in by_lob:
        print(f"             {lob:<18} ${total:>14,.2f}   {cnt:>5,} policies")

    # KPI 9: Hit Ratio (NEW)
    hit = c.execute("""
        SELECT
            SUM(total_quotes)   AS total_q,
            SUM(bound_count)    AS bound_q,
            ROUND(CAST(SUM(bound_count) AS REAL)/NULLIF(SUM(total_quotes),0)*100, 2) AS overall_hit,
            SUM(CASE WHEN quote_type='NewBusiness' THEN total_quotes ELSE 0 END) AS nb_total,
            SUM(CASE WHEN quote_type='NewBusiness' THEN bound_count  ELSE 0 END) AS nb_bound,
            SUM(CASE WHEN quote_type='Renewal'     THEN total_quotes ELSE 0 END) AS ren_total,
            SUM(CASE WHEN quote_type='Renewal'     THEN bound_count  ELSE 0 END) AS ren_bound
        FROM anl_fact_quote_summary
    """).fetchone()
    total_q, bound_q, overall_hit, nb_total, nb_bound, ren_total, ren_bound = hit
    nb_hr  = round(nb_bound/nb_total*100,   2) if nb_total  else 0
    ren_hr = round(ren_bound/ren_total*100,  2) if ren_total else 0

    ok(f"KPI 9 — Hit Ratio:")
    print(f"             Overall:     {overall_hit:>6.2f}%  ({bound_q:,} bound / {total_q:,} total quotes)")
    print(f"             New Business:{nb_hr:>6.2f}%  ({nb_bound:,} bound / {nb_total:,} NB quotes)")
    print(f"             Renewal:     {ren_hr:>6.2f}%  ({ren_bound:,} bound / {ren_total:,} renewal quotes)")

    # Hit Ratio by LOB
    hit_lob = c.execute("""
        SELECT lob,
               SUM(total_quotes) AS tq,
               SUM(bound_count)  AS bc,
               ROUND(CAST(SUM(bound_count) AS REAL)/NULLIF(SUM(total_quotes),0)*100,2) AS hr
        FROM anl_fact_quote_summary
        GROUP BY lob ORDER BY hr DESC
    """).fetchall()
    print(f"             By LOB:")
    for lob, tq, bc, hr in hit_lob:
        print(f"               {lob:<18}  {hr:>5.1f}%  ({bc:,}/{tq:,})")

    # Decline reasons breakdown
    dr = c.execute("""
        SELECT q.decline_reason, COUNT(*) as cnt
        FROM raw_quote q
        WHERE q.status = 'Declined' AND q.decline_reason IS NOT NULL
          AND q.load_date = ?
        GROUP BY q.decline_reason ORDER BY cnt DESC
    """, (LOAD_DATE,)).fetchall()
    ok(f"          Decline Reasons (for dashboard drill-down):")
    for reason, cnt in dr:
        print(f"               {reason:<28}  {cnt:,}")

    print(f"\n{'═'*62}")
    print("   ✅  ALL 9 KPIs VERIFIED — Ready for Sign-Off")
    print(f"{'═'*62}\n")

# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    if not os.path.exists(DB_PATH):
        print("❌  policycenter.db not found. Run 01_build_pipeline.py first.")
        exit(1)

    conn = sqlite3.connect(DB_PATH)
    print(f"\n{'═'*62}")
    print("  PolicyCenter Demo — Adding Hit Ratio KPI (Quote Layer)")
    print(f"{'═'*62}")

    total_q, bound_q = add_source_quotes(conn)
    add_staging_quotes(conn)
    add_raw_quotes(conn)
    add_exploration_quotes(conn)
    add_conformed_quotes(conn)
    add_analytical_quotes(conn)
    verify_all_kpis(conn)
    conn.close()

    db_mb = os.path.getsize(DB_PATH)/1024/1024
    print(f"   📦  DB: {DB_PATH}  ({db_mb:.2f} MB)\n")
