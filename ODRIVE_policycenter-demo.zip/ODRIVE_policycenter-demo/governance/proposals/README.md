# Proposals — current status (ODRIVE copy)

**Updated 2026-09-28:** this folder used to hold proposals awaiting a
named human's accept/discard decision. It no longer does — patch/minor
skill edits (in-run self-heal, capped at 3 loops, and cross-project
promotion once the 3x/2-project threshold trips) now auto-apply per
`../../self-learning/skill-versioning-policy.md`. Files here are now a
**record of what was applied and why**, not a queue of pending
decisions. In this layout that means a new `_skills/<agent>/SKILL_v{n}.md`
gets committed directly — the same mechanism the existing informal
`SKILL_v2.md` files already used, now logged here instead of dropped in
unreviewed. Major changes (role, tools, boundary_tier) are the one
category still routed to a human first, and still wouldn't land in this
folder.

**Real applied edits on file: 0.**

Today `rejections.jsonl` holds only one project's worth of history
(`PC_DASHBOARD_DEMO`, run `PC-DEMO-20260616-001`) — identical to the
`policycenter-demo` copy, since the underlying grade records are
byte-identical. Within that single project, "Completeness" is the most
repeated category (6 of 15 logged gaps, across 4 agents: ba-grill,
to-prd, schema-discovery, qa-100), but the cross-project promotion path
still requires 2+ distinct projects — that detection threshold didn't
change, only what happens once it's met. So nothing has actually
promoted yet.

`grillmewithdocs-2026-09-28.HYPOTHETICAL.diff` in this folder is a
worked example of what an auto-applied entry would look like once a
second project logs a matching "grain not defined" rejection twice
more — not a real one, since that second project doesn't exist yet.
