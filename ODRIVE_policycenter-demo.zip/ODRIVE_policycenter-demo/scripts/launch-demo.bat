@echo off
REM Donegal Insurance — PolicyCenter Demo Launcher (Windows)
REM Opens all 3 dashboards in your default browser

set SCRIPT_DIR=%~dp0
set DEMO_DIR=%SCRIPT_DIR%..

echo Donegal Insurance — PolicyCenter Demo
echo ──────────────────────────────────────
echo Opening dashboards...

start "" "%DEMO_DIR%\POLICYCENTER_SDLC_DEMO.html"
timeout /t 1 /nobreak >nul

start "" "%DEMO_DIR%\wiki.html"
timeout /t 1 /nobreak >nul

start "" "%DEMO_DIR%\dashboard.html"

echo.
echo All 3 dashboards opened:
echo   1. POLICYCENTER_SDLC_DEMO.html  (Agent Pipeline + PII + SQL Terminal)
echo   2. wiki.html                    (LLM Wiki + Obsidian Graph)
echo   3. dashboard.html               (Business Dashboard - 9 KPIs)
pause
