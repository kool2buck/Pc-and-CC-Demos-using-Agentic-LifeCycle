@echo off
REM Verifies the demo is complete and all required files exist
set SCRIPT_DIR=%~dp0
set DEMO_DIR=%SCRIPT_DIR%..

echo Donegal Insurance — PolicyCenter Demo Verification
echo ───────────────────────────────────────────────────
echo.

if exist "%DEMO_DIR%\POLICYCENTER_SDLC_DEMO.html" (
    echo [OK] POLICYCENTER_SDLC_DEMO.html found
) else ( echo [MISSING] POLICYCENTER_SDLC_DEMO.html )

if exist "%DEMO_DIR%\wiki.html" (
    echo [OK] wiki.html found
) else ( echo [MISSING] wiki.html )

if exist "%DEMO_DIR%\dashboard.html" (
    echo [OK] dashboard.html found
) else ( echo [MISSING] dashboard.html )

if exist "%DEMO_DIR%\policycenter.db" (
    echo [OK] policycenter.db found
) else ( echo [MISSING] policycenter.db )

if exist "%DEMO_DIR%\artifacts\BRD.md" (
    echo [OK] artifacts/BRD.md found
) else ( echo [MISSING] artifacts/BRD.md )

if exist "%DEMO_DIR%\_skills\grillmewithdocs\SKILL.md" (
    echo [OK] grillmewithdocs/SKILL.md found
) else ( echo [MISSING] grillmewithdocs/SKILL.md )

echo.
echo Verification complete. If all [OK] — run launch-demo.bat
pause
