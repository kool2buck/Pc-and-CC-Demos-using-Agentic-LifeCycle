#!/bin/bash
# Opens the Obsidian vault in Obsidian app (macOS)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
VAULT="$(dirname "$SCRIPT_DIR")/vault"

if command -v obsidian &>/dev/null; then
    obsidian "$VAULT"
elif [ -d "/Applications/Obsidian.app" ]; then
    open -a Obsidian "$VAULT"
else
    echo "Obsidian not found. Download at https://obsidian.md"
    echo "Then open vault at: $VAULT"
fi
