#!/bin/bash
# Donegal Insurance — PolicyCenter Demo Launcher (macOS / Linux)
# Opens all 3 dashboards in your default browser

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DEMO_DIR="$(dirname "$SCRIPT_DIR")"

echo "🏛 Donegal Insurance — PolicyCenter Demo"
echo "─────────────────────────────────────────"
echo "Opening dashboards..."

# Open main SDLC demo
open "$DEMO_DIR/POLICYCENTER_SDLC_DEMO.html" 2>/dev/null || \
xdg-open "$DEMO_DIR/POLICYCENTER_SDLC_DEMO.html" 2>/dev/null
sleep 1

# Open LLM Wiki
open "$DEMO_DIR/wiki.html" 2>/dev/null || \
xdg-open "$DEMO_DIR/wiki.html" 2>/dev/null
sleep 1

# Open Business Dashboard
open "$DEMO_DIR/dashboard.html" 2>/dev/null || \
xdg-open "$DEMO_DIR/dashboard.html" 2>/dev/null

echo "✅ All 3 dashboards opened"
echo ""
echo "Dashboard 1: POLICYCENTER_SDLC_DEMO.html (Agent Pipeline + PII + SQL Terminal)"
echo "Dashboard 2: wiki.html (LLM Wiki + Obsidian Graph + Knowledge Base)"
echo "Dashboard 3: dashboard.html (Business Dashboard — 9 KPIs, 5 LOB Filter)"
