#!/bin/bash
# Rebuilds policycenter.db from scratch and regenerates all dashboards
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DEMO_DIR="$(dirname "$SCRIPT_DIR")"

echo "Rebuilding PolicyCenter Demo..."
cd "$DEMO_DIR"
python3 python/01_build_pipeline.py && \
python3 python/01b_add_quotes.py && \
python3 python/02_build_dashboard.py && \
echo "✅ Rebuild complete"
