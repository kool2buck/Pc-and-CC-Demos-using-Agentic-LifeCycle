# Windows Setup & Portability Guide — PolicyCenter Demo

## First-Time Setup (No Install Required)
1. Unzip `policycenter-demo.zip` to `C:\Users\YourName\Documents\`
2. Double-click `scripts\launch-demo.bat`
3. All 3 dashboards open in your default browser

## Requirements
- Windows 10 or 11
- Any modern browser (Chrome, Edge, Firefox)
- Python 3.8+ (only needed if you want to rebuild the database)

## File Structure
```
policycenter-demo\
├── POLICYCENTER_SDLC_DEMO.html   ← Open directly in browser
├── wiki.html
├── dashboard.html
├── policycenter.db               ← SQLite database (no install needed to VIEW)
├── scripts\launch-demo.bat       ← Double-click to open all 3 dashboards
└── ...
```

## Explore the Database (Optional)
Download DB Browser for SQLite (free, portable):
https://sqlitebrowser.org/dl/
Open `policycenter.db` to run SQL queries directly.

## Copy to USB Drive
```
xcopy /E /I C:\path\to\policycenter-demo D:\USB-DRIVE\policycenter-demo
```
All files are self-contained. Works from USB, network share, or local folder.
