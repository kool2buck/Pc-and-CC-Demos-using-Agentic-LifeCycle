# Guidewire BillingCenter — Glossary & Entity Metadata
## Shared context for GrillMeWithDocs and all BillingCenter projects

---
## Entity: BCAccount
**Definition:** A billing account tied to one or more policies. Manages payment collection.
**Table:** bc_account
**Key Fields:** account_id, accountNumber, paymentMethod, status
**DW Gotcha:** One bc_account can cover multiple policies. Join on policy_id, not account_id alone.

---
## Entity: Charge
**Definition:** An amount billed to a billing account (premium, fee, tax, installment).
**Table:** bc_charge
**Key Fields:** charge_id, account_id, policy_id, charge_type, charge_amount, due_date, status
**PII:** None
**DW Gotcha:** Charges can be VOIDED — always filter status != 'Voided' for financials.

---
## Entity: Payment
**Definition:** A payment received from the insured against a charge.
**Table:** bc_payment
**Key Fields:** payment_id, account_id, payment_date, payment_amount, payment_method, status
**PII:** payment_method may contain masked card number

---
## Entity: Invoice
**Definition:** A statement grouping one or more charges for a billing period.
**Table:** bc_invoice
**Key Fields:** invoice_id, account_id, invoice_date, due_date, invoice_amount, status
**DW Gotcha:** Delinquency is tracked at invoice level. Days-delinquent = today - due_date WHERE status='Unpaid'.

---
## Entity: Disbursement
**Definition:** A payment OUT from Donegal (return premium, refund, commission payment).
**Table:** bc_disbursement
**Key Fields:** disbursement_id, account_id, amount, disbursement_date, reason, status
**DW Gotcha:** Negative in P&L context. Must be separated from Payments (which are inbound).

---
## Key BillingCenter KPIs
- Collected Premium: SUM(payment_amount) WHERE status='Cleared'
- Written vs Collected: bc_charge billed vs bc_payment received
- Delinquency Rate: COUNT(invoice WHERE status='Past Due') / COUNT(invoice)
- Average Days to Pay: AVG(payment_date - due_date) WHERE paid
