# Guidewire ClaimsCenter — Glossary & Entity Metadata
## Shared context for GrillMeWithDocs and all ClaimsCenter projects

---
## Entity: Claim
**Definition:** A reported loss event tied to a policy. The parent record in ClaimsCenter.
**Table:** cc_claim
**Key Fields:** claim_id, claimNumber, policy_id, lob, loss_date, report_date, status, total_incurred
**PII:** claimant name, address, injury description
**DW Gotcha:** total_incurred changes over the life of a claim. Always snapshot with load_date in RAW.

---
## Entity: Exposure
**Definition:** A coverage-specific unit of loss within a Claim (e.g., BI, PD, Collision).
**Table:** cc_exposure
**Key Fields:** exposure_id, claim_id, coverage_type, status, reserved_amount, paid_amount
**DW Gotcha:** One Claim can have many Exposures. Never SUM paid at Claim level — join through Exposure.

---
## Entity: Reserve
**Definition:** An estimate of future claim costs. Set and revised by adjusters.
**Table:** cc_reserve
**Key Fields:** reserve_id, exposure_id, reserve_type, reserve_amount, set_date
**DW Gotcha:** Reserves are point-in-time. Use RAW layer with load_date to track reserve development.

---
## Entity: ClaimTransaction
**Definition:** A financial transaction on an exposure (payment, reserve change, recovery).
**Table:** cc_transaction
**Key Fields:** txn_id, exposure_id, transaction_type, transaction_date, amount, status
**DW Gotcha:** Recoveries are negative. Separate Indemnity from Expense transactions.

---
## Key ClaimsCenter KPIs
- Incurred Loss: SUM(reserve + paid) by LOB
- Loss Ratio: Incurred Loss / Written Premium (joins PC and CC)
- Claim Count: COUNT(DISTINCT claim_id) WHERE status != 'Withdrawn'
- Average Claim Value: Incurred Loss / Claim Count
- Severity: Paid / Closed Claim Count
