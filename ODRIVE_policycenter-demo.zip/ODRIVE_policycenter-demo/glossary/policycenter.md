# Guidewire PolicyCenter — Glossary & Entity Metadata
## Shared context for GrillMeWithDocs and all PolicyCenter projects

---
## Entity: Account
**Definition:** A customer record that can hold one or more policies. The top of the PC hierarchy.
**Table:** pc_account
**Key Fields:** accountNumber, accountHolder (Contact), createTime
**Related Entities:** Policy (one Account → many Policies)
**PII:** accountHolder name, address, SSN, DOB
**DW Gotcha:** Account-to-Policy is one-to-many. Never grain your fact table at Account level.

---
## Entity: Policy
**Definition:** A contract of insurance between Donegal and the insured. Contains one or more PolicyPeriods.
**Table:** pc_policy
**Key Fields:** policy_id, policyNumber, lob, status, agent_id, product_id
**Related Entities:** Account (parent), PolicyPeriod (child), Agent (writer), Product (type)
**PII:** insured_name — mask in CONFORMED and ANALYTICAL layers
**DW Gotcha:** Policy status can change (Active→Cancelled). Use Type 2 SCD in anl_dim_policy.

---
## Entity: PolicyPeriod
**Definition:** One term (typically 12 months) of a Policy. Renewals create new PolicyPeriods.
**Table:** pc_policy_period
**Key Fields:** period_id, policy_id, term_number, effective_date, expiration_date, written_premium, renewal_flag, lapse_flag
**Related Entities:** Policy (parent), Transaction (child)
**PII:** None
**DW Gotcha:** Fan-out risk — always JOIN Policy then PolicyPeriod; never the reverse.
  A Policy with 3 terms has 3 rows in PolicyPeriod. Aggregate at period grain first.

---
## Entity: PolicyLine
**Definition:** The coverage line within a Policy (e.g., Liability, Physical Damage within PersonalAuto).
**Table:** pc_policyline
**Key Fields:** policyLineId, period_id, linePatternCode, coveredPremium
**Related Entities:** PolicyPeriod (parent), Coverage (child)
**DW Gotcha:** Multiple lines per period. If you need premium by coverage, join through PolicyLine.

---
## Entity: Transaction
**Definition:** A financial event on a policy (NewBusiness, Renewal, Endorsement, Cancellation, Reinstatement).
**Table:** pc_transaction
**Key Fields:** transaction_id, policy_id, period_id, agent_id, transaction_type, transaction_date, premium_amount, commission_amount
**PII:** None
**DW Gotcha:** Endorsements and Cancellations have NEGATIVE premium_amount. Do not SUM blindly.
  For written premium, use pc_policy_period.written_premium (always positive).

---
## Entity: Quote
**Definition:** A premium estimate issued before binding. May or may not become a Policy.
**Table:** pc_quote
**Key Fields:** quote_id, policy_id (nullable), agent_id, lob, quote_type, quoted_premium, status, decline_reason, bound_date
**Related Entities:** Policy (when bound), Agent (writer), Product (LOB)
**PII:** None
**Business Rule:** quote.status = 'Bound' → quote.policy_id links to the resulting pc_policy.
  Hit Ratio = COUNT(status='Bound') / COUNT(*) by LOB, agent, quote_type.

---
## Entity: Producer (Agent)
**Definition:** The insurance agent or agency that writes business.
**Table:** pc_agent
**Key Fields:** agent_id, agent_name, agency_name, region, state
**PII:** agent_name (not masked — business entity, not consumer PII)
**DW Gotcha:** Agents can change agencies. Use Type 2 SCD in anl_dim_agent.

---
## Entity: Product
**Definition:** The insurance product definition tied to a Line of Business.
**Table:** pc_product
**Key Fields:** product_id, lob, product_name, product_code
**LOBs:** PersonalAuto (PA) | Homeowners (HO) | CommercialAuto (CA) | DwellingFire (DF) | WorkersComp (WC)
**DW Gotcha:** Product is relatively static — Type 1 SCD is sufficient.

---
## Typelists
### policy.status
Active | Expired | Cancelled | NonRenewed | Draft | Bound

### transaction.transaction_type
NewBusiness | Renewal | Endorsement | Cancellation | Reinstatement

### quote.status
Bound | Declined | Expired | InProgress

### quote.decline_reason
PriceDeclined | CoverageDeclined | CompetitorSelected | NoResponse

### quote.quote_type
NewBusiness | Renewal

---
## PII Field Register
| Table        | Field        | Sensitivity | Handling                          |
|--------------|--------------|-------------|-----------------------------------|
| pc_policy    | insured_name | HIGH-PII    | Exclude from anl_fact_* tables    |
| pc_account   | accountHolder| HIGH-PII    | Not in PC_DASHBOARD_DEMO scope    |

---
## Known DW Patterns for PolicyCenter
1. **Fan-out**: Always aggregate PolicyPeriod → Policy, not Policy → PolicyPeriod
2. **Written Premium**: Use pc_policy_period.written_premium (not pc_transaction.premium_amount)
3. **Renewal Logic**: renewal_flag=1 on the SECOND (and later) terms of a policy
4. **Lapse**: lapse_flag=1 on any period that was cancelled mid-term
5. **Hit Ratio Source**: pc_quote table — one row per quote, policy_id is the binding link
