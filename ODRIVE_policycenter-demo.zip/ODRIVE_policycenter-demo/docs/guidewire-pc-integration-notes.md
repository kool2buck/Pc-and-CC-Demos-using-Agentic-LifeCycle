# Guidewire PolicyCenter Integration Notes
## For Production Snowflake ETL Team

## 1. Connection
- PolicyCenter exposes data via GORM (Guidewire Object-Relational Mapping)
- Tables use pc_* prefix for core, pctl_* for typelists, pcx_* for extensions
- Donegal extensions: pcx_donegal_* (verify with PC admin)

## 2. Effective Dating
PolicyCenter uses effective dating on many tables.
- pc_policy_period: effective_date / expiration_date define the term
- Always filter by effective_date for point-in-time analysis
- For current state: WHERE effective_date <= CURRENT_DATE AND (expiration_date IS NULL OR expiration_date > CURRENT_DATE)

## 3. TypeLists (lookup tables)
- pctl_policy_status: status codes for pc_policy
- pctl_line_of_business: LOB codes
- Always join through typelists for human-readable values in EXPLORATION layer

## 4. Quote Module
- pc_quote is in the PolicyCenter Quote module (separate from Policy module)
- Binding creates: pc_quote.status='Bound' AND pc_quote.policy_id = resulting policy
- Quote activity logs in pc_quote_history (not in demo scope)

## 5. Batch Close Window
PolicyCenter runs nightly batch close.
ETL must run AFTER batch close to capture all daily transactions.
Recommended: ETL trigger at 02:00 ET (batch closes by 01:30 ET at Donegal).
