# KPI Definitions — PolicyCenter Dashboard

## KPI 1: Total Premium Written
**Formula:** SUM(total_written_premium) FROM anl_fact_policy_aggregate
**Value:** $13,962,087
**Grain:** All agents × All LOBs × All periods
**Note:** Uses pc_policy_period.written_premium (not pc_transaction.premium_amount)

## KPI 2: Policy Count
**Formula:** COUNT(*) FROM anl_dim_policy WHERE is_current=1
**Value:** 1,200
**Note:** Current version only (is_current=1 in Type 2 SCD)

## KPI 3: Renewal Rate
**Formula:** SUM(renewal_count) / SUM(policy_count) × 100
**Value:** 38.9%
**Grain:** Period-level (not policy-level)
**Disclosure:** 62% policy-level rate available on request

## KPI 4: Average Premium
**Formula:** SUM(total_written_premium) / SUM(policy_count)
**Value:** $7,109

## KPI 5: Lapse Rate
**Formula:** SUM(lapse_count) / SUM(policy_count) × 100
**Value:** 1.83%

## KPI 6: 30-Day Premium Trend
**Formula:** SUM(premium_amount) FROM anl_fact_policy_transaction GROUP BY date
**Value:** 25 data points (NB + Renewal transactions only)

## KPI 7: Top 5 Agents by Premium
**Formula:** SUM(total_written_premium) GROUP BY agent_key ORDER BY SUM DESC
**#1 Agent:** Thompson — $856,877

## KPI 8: Premium by LOB
**Formula:** SUM(total_written_premium) GROUP BY lob
**#1 LOB:** WorkersComp — $8,215,940

## KPI 9: Hit Ratio (Quote-to-Bind) ← NEW in PC Demo
**Formula:** SUM(bound_count) / SUM(total_quotes) FROM anl_fact_quote_summary
**Overall:** 58.0%
**New Business:** 48.0%
**Renewal:** 86.4%
**Source Table:** anl_fact_quote_summary (unique to PC — not in Claims Center demo)
