# File Structure — PC_DASHBOARD_DEMO_2025
## Complete directory listing with descriptions

```
policycenter-demo/
├── POLICYCENTER_SDLC_DEMO.html   12-agent pipeline demo (57 KB, all embedded)
├── wiki.html                      LLM Wiki + Obsidian graph (26 KB, offline)
├── dashboard.html                 Business Dashboard, 9 KPIs (25 KB, offline)
├── policycenter.db                SQLite 7.2 MB — all source + ETL + analytical
├── README.md                      Project overview
├── QUICK-START.md                 3-step launch instructions
├── README-macOS.md                Mac portability guide
├── README-Windows.md              Windows portability guide
├── CONTEXT.md                     Context for Donegal IT team
├── .gitignore
│
├── _skills/                       12 agent SKILL.md files + companions
│   ├── grading-agent/             (rubric_template.md, grading_agent.md, 6×rubric_*.md)
│   ├── orchestrator/              (model_policy.json, fleet_config.json)
│   ├── obsidian-llm-wiki/         (wiki_structure.md)
│   ├── plan-agent/                (epic_template.md, plan_config.json)
│   ├── grillmewithdocs/           (SKILL_v2.md, brd_template.md, interview_protocol.md, ...)
│   ├── to-prd/                    (SKILL_v2.md, prd_template.md)
│   ├── schema-discovery/          (SKILL_v2.md, catalog.json, schema_audit_template.md)
│   ├── dev-build/                 (etl_patterns.md, insert_patterns.md)
│   ├── tdd/                       (ac_template.md, test_runner.py, sample_ac_results.md)
│   ├── qa-100/                    (SKILL_v2.md, integration_test_template.md)
│   ├── adf-pipeline/              (pipeline_config.md, run_log.md, pc_etl_nightly.json)
│   └── business-signoff/          (signoff_template.md, kpi_checklist.md, kpi_presentation.md)
│
├── artifacts/                     All SDLC output documents
│   ├── BRD.md                     Business Requirements (grillmewithdocs v2.0)
│   ├── PRD.md                     Product Requirements (to-prd v2.0)
│   ├── Technical_Requirements.md
│   ├── Schema_Audit.md
│   ├── Data_Dictionary.md         All 7 analytical tables documented
│   ├── ETL_Pipeline_Architecture.md
│   ├── Dimensional_Model.md
│   ├── Operations_Runbook.md
│   ├── SIGNOFF_PACKAGE.md
│   ├── sql/                       ETL SQL for all 6 layers
│   └── test-reports/              TDD + QA test reports
│
├── grading/                       Grade records for all agent loops
│   ├── rubrics/                   6 rubric files
│   └── grade-records/             13 grade records
│
├── glossary/                      Guidewire glossaries (PC + BC + CC)
├── knowledge-base/                8 shared knowledge files
├── docs/                          9 documentation files
├── projects/PC_DASHBOARD_DEMO/    Project state + README
├── source-systems/                PC schema SQL + Snowflake DDL
├── vault/                         Obsidian vault (40+ markdown files)
├── scripts/                       Mac + Windows launchers + verifiers
└── python/                        ETL scripts + utilities
```
