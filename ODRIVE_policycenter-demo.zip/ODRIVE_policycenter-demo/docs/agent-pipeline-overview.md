# Agent Pipeline — Complete Overview
## 12 Agents in 3 Categories

### Platform Agents (always running, cross-project)
| Agent | Role |
|-------|------|
| grading-agent | Quality gate. 92/100 threshold. Issues REWARD or REWORK. |
| orchestrator | Fleet management. Model allocation. Pipeline sequencing. |
| obsidian-llm-wiki | Second Brain. Knowledge graph. Artifact indexing. |

### Delivery Agents (PolicyCenter project)
| Agent | Output | Gate |
|-------|--------|------|
| plan-agent | 8 epics, 14 stories | ≥92/100 |
| grillmewithdocs | BRD (Business Requirements) | ≥92/100 |
| to-prd | PRD (Product Requirements) | ≥92/100 |
| schema-discovery | Schema Audit, catalog.json | ≥92/100 |
| dev-build | 5-layer ETL + 7 analytical tables | ≥92/100 |
| tdd | 9 ACs all PASS | ≥92/100 |
| qa-100 | 12 integration tests | ≥92/100 |
| adf-pipeline | ADF pipeline config + run log | ≥92/100 |
| business-signoff | KPI sign-off (HUMAN GATE) | APPROVED |

### Pipeline Flow
plan → grillmewithdocs → [to-prd ∥ schema-discovery] → dev-build → tdd → qa-100 → adf-pipeline → business-signoff
