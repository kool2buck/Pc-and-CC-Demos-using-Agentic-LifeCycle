# Lines of Business Reference — PolicyCenter Demo

| LOB Code | Full Name | Product Code | Premium Range | Typical Policy |
|----------|-----------|--------------|---------------|----------------|
| PersonalAuto | Personal Automobile | PA | $800–$2,500 | Annual, personal vehicle |
| Homeowners | Homeowners Insurance | HO | $1,000–$3,500 | Annual, primary residence |
| CommercialAuto | Commercial Automobile | CA | $3,000–$15,000 | Annual, business fleet |
| DwellingFire | Dwelling Fire | DF | $600–$2,000 | Annual, rental/secondary |
| WorkersComp | Workers Compensation | WC | $5,000–$50,000 | Annual, employer coverage |

## Premium Distribution in Demo
| LOB | Total Premium | % of Total |
|-----|--------------|-----------|
| WorkersComp | $8,215,940 | 58.8% |
| CommercialAuto | $2,912,000 | 20.9% |
| Homeowners | $1,387,000 | 9.9% |
| PersonalAuto | $938,000 | 6.7% |
| DwellingFire | $509,000 | 3.6% |

## Hit Ratio by LOB (Quote-to-Bind)
| LOB | Overall | New Business | Renewal |
|-----|---------|-------------|---------|
| PersonalAuto | ~60% | ~50% | ~87% |
| Homeowners | ~57% | ~47% | ~85% |
| CommercialAuto | ~59% | ~49% | ~87% |
| DwellingFire | ~58% | ~48% | ~86% |
| WorkersComp | ~56% | ~46% | ~86% |
