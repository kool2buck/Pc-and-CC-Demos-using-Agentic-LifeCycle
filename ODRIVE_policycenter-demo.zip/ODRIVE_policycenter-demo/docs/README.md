# Documentation — PC_DASHBOARD_DEMO_2025
| File | Purpose |
|------|---------|
| agent-pipeline-overview.md | All 12 agents, roles, gates |
| kpi-definitions.md | All 9 KPIs with formulas and values |
| lob-reference.md | 5 LOBs with premium ranges and hit ratios |
| pii-handling-guide.md | PII rules by layer, 3-role access model |
| snowflake-migration-guide.md | How to move from SQLite→Snowflake |
| guidewire-pc-integration-notes.md | PC connection, effective dating, typelists |
| architecture-decision-record.md | 5 key ADRs with rationale |
| demo-talking-points.md | Presentation script for Ajay |
