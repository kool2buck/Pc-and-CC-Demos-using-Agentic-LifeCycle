# PII Handling Guide — PolicyCenter Demo
## Donegal Insurance Data Governance Standard

## Fields in Scope
| Field | Table | Classification | Layer Exposure |
|-------|-------|----------------|----------------|
| insured_name | pc_policy | HIGH-PII | SOURCE, STAGING, EXPLORATION, anl_dim_policy only |

## Layer Rules
| Layer | insured_name |
|-------|-------------|
| SOURCE | Present (raw extract) |
| STAGING | Present (1:1 copy) |
| RAW | Present (historical archive) |
| EXPLORATION | Present — FLAGGED for DS use |
| CONFORMED | Excluded from all fact tables |
| ANALYTICAL | Only in anl_dim_policy (dimension), NOT in any fact table |

## 3-Role Access Model (Demo)
| Role | Access |
|------|--------|
| analyst_read | Sees encrypted ciphertext (base64 in demo, AES-256-GCM in prod) |
| regional_mgr_pa | Decrypted for PA/NJ/DE/MD; encrypted for other states |
| data_gov_officer | Full access, all decrypted, every access logged |

## Production: Snowflake Implementation
- ENCRYPT(): Snowflake native encryption
- Key storage: Azure Key Vault (Donegal standard)
- Row access policy: on anl_dim_policy.insured_name
- Audit log: every decryption event → governance.decryption_log
