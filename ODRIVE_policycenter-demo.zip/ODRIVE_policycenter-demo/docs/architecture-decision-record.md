# Architecture Decision Record — PC_DASHBOARD_DEMO_2025

## ADR-001: 5-Layer ETL Architecture
**Status:** Accepted
**Decision:** STAGING → RAW → EXPLORATION → CONFORMED → ANALYTICAL
**Rationale:** Each layer serves a distinct consumer. DS/ML access EXPLORATION. 
BI accesses ANALYTICAL. No shortcuts between layers.
**Rejected:** Single-step ETL (source→analytical) — loses auditability and DS access.

## ADR-002: Aggregate Fact Tables
**Status:** Accepted
**Decision:** Pre-aggregate KPIs 1-8 into anl_fact_policy_aggregate at agent×LOB×year×month grain.
**Rationale:** Dashboard KPI cards need sub-second queries. Aggregating on-the-fly from 3,975 transactions is too slow for a web browser with embedded SQLite.
**Rejected:** On-the-fly aggregation — too slow for dashboard use.

## ADR-003: Separate Quote Fact Table
**Status:** Accepted
**Decision:** anl_fact_quote_summary is a separate table at a different grain from anl_fact_policy_aggregate.
**Rationale:** Quote grain (per-quote) vs Policy grain (per-period) are incompatible. Mixing would cause double-counting or null problems.
**Rejected:** Adding quote columns to anl_fact_policy_aggregate — creates dual-grain fact.

## ADR-004: SQLite for Demo, Snowflake for Production
**Status:** Accepted
**Decision:** All demo ETL uses SQLite (policycenter.db). Production uses Snowflake.
**Rationale:** SQLite ships with Python. Zero install for demo. Table names and column names are identical — only connection string changes for production.
**Migration:** See docs/snowflake-migration-guide.md

## ADR-005: No CTAS (Create Table As Select)
**Status:** Accepted (non-negotiable)
**Decision:** Every table: CREATE TABLE [explicit schema] followed by INSERT INTO ... SELECT FROM.
**Rationale:** CTAS hides column types, makes schema drift invisible, fails in Snowflake when column order changes in source.
