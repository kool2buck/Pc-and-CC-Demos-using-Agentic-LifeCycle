# Demo Talking Points — PolicyCenter SDLC Demo
## For Ajay's Presentation

### Opening (30 seconds)
"This is our North Star — a fully automated 12-agent SDLC that takes a business requirement and 
delivers a verified, CDO-approved analytics dashboard. Every step is graded. Nothing moves forward 
until it scores 92 or higher."

### Agent Pipeline (2 minutes)
- Click GrillMeWithDocs → show Loop 1 FAIL (80/100) 
- Show the SKILL.md diff — exactly what the agent fixed
- Click Loop 2 → show 95/100 PASS
- Key point: "This is how we eliminate re-work. The agent gets better, not us."

### PII Encryption (1 minute)
- Click analyst_read → "This is what your data engineers see"
- Click regional_mgr_pa → "Regional managers see their region, nothing else"
- Click data_gov_officer → "Full access, fully audited"

### KPI 9: Hit Ratio (1 minute)
- "This is new — it comes from the Quote module, not the Policy module"
- "58% overall. 48% new business. 86% renewal."
- "First time we've had quote-to-bind visibility across all 5 LOBs in one place"

### Business Dashboard (30 seconds)
- Click LOB filter → watch all 6 KPI cards and 5 charts update instantly
- "This runs at file:// — no server, no internet, works on any laptop"

### Closing
"Three things are new in this demo vs Claims Center:
1. Quote-to-Bind (Hit Ratio) KPI from the pc_quote table
2. Aggregate fact tables for fast LOB/agent/month slicing
3. A business-grade dashboard with 5 interactive charts
Next: BillingCenter (collected premium, delinquency rate, days-to-pay)."
