# Snowflake Migration Guide
## Moving from SQLite Demo → Production Snowflake

### Step 1: Create Snowflake Databases
```sql
CREATE DATABASE PC_DEMO_RAW;
CREATE DATABASE PC_DEMO_CONFORMED;
CREATE DATABASE PC_DEMO_ANALYTICAL;
```

### Step 2: Run DDL (identical to SQLite schema)
Upload and run: source-systems/policycenter/schema_3nf.sql
Upload and run: artifacts/sql/05_analytical.sql
Upload and run: artifacts/sql/06_aggregate_facts.sql

### Step 3: Adapt Python Scripts
Replace: `sqlite3.connect('policycenter.db')`
With:    `snowflake.connector.connect(account=..., warehouse=..., database=...)`

### Step 4: Schedule ADF Pipeline
Import: _skills/adf-pipeline/pipeline_config.md
Set trigger: nightly 02:00 ET
Alert: data-ops@donegal.com on failure

### Step 5: Enable Row Access Policy (PII)
```sql
CREATE ROW ACCESS POLICY pii_policy AS (state TEXT) RETURNS BOOLEAN ->
  CURRENT_ROLE() IN ('DATA_GOV_OFFICER') OR
  (CURRENT_ROLE() = 'REGIONAL_MGR_PA' AND state IN ('PA','NJ','DE','MD')) OR
  CURRENT_ROLE() = 'ANALYST_READ' AND 1=0;  -- blocked for analyst
ALTER TABLE anl_dim_policy ADD ROW ACCESS POLICY pii_policy ON (state);
```
