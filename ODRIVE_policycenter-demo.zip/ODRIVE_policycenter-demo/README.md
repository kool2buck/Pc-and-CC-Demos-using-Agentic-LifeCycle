# Donegal Insurance — PolicyCenter Analytics Demo
## PC_DASHBOARD_DEMO_2025 | Version 1.0 | 2026-06-16

### What This Is
A complete end-to-end demonstration of:
1. **12-Agent SDLC Pipeline** — from business requirements to delivered dashboards
2. **5-Layer ETL** — Guidewire PolicyCenter → STAGING → RAW → EXPLORATION → CONFORMED → ANALYTICAL
3. **3 Interactive HTML Dashboards** — Agent Demo, LLM Wiki, Business Dashboard
4. **9 Business KPIs** including Hit Ratio (Quote-to-Bind) across 5 Lines of Business

### Quick Start (macOS)
```bash
./scripts/launch-demo.sh
```

### Quick Start (Windows)
```
Double-click: scripts\launch-demo.bat
```

### 3 Dashboards
| File | Purpose |
|------|---------|
| POLICYCENTER_SDLC_DEMO.html | Agent pipeline demo, PII encryption, SQL terminal, BRD viewer |
| wiki.html | LLM Wiki with Obsidian-like knowledge graph |
| dashboard.html | Business Dashboard — 9 KPIs, 5 LOB filter, 5 charts |

### Requirements
- Python 3.8+ (to rebuild database)
- Any modern web browser (Chrome, Safari, Firefox, Edge)
- No internet required — fully self-contained

### Database
policycenter.db — SQLite (~7 MB)
- 1,200 policies | 5 LOBs | 25 agents | 3,975 transactions | 3,384 quotes
- Full 5-layer ETL + analytical tables already loaded

### Source System
Simulates Guidewire PolicyCenter.
ETL pipeline builds the Snowflake analytical layer in SQLite for demo portability.
