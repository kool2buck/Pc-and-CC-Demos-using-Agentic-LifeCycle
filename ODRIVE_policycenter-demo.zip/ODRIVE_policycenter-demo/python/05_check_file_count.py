#!/usr/bin/env python3
"""Verifies the demo has 200+ files and all key files present"""
import os, sys
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

total = sum(len(files) for _,_,files in os.walk(BASE))
print(f"Total files: {total}")

required = [
    'POLICYCENTER_SDLC_DEMO.html','wiki.html','dashboard.html',
    'policycenter.db','README.md','QUICK-START.md',
    '_skills/grillmewithdocs/SKILL.md',
    '_skills/adf-pipeline/SKILL.md',
    '_skills/business-signoff/SKILL.md',
    '_skills/obsidian-llm-wiki/SKILL.md',
    'artifacts/BRD.md','artifacts/Data_Dictionary.md',
    'glossary/policycenter.md','vault/INDEX.md',
]
missing = [f for f in required if not os.path.exists(os.path.join(BASE,f))]
if missing:
    print(f"❌ Missing {len(missing)} required files:")
    for f in missing: print(f"   - {f}")
    sys.exit(1)
else:
    print(f"✅ All required files present")
    print(f"{'✅' if total>=200 else '⚠️'} File count: {total} ({'≥200 ✅' if total>=200 else '<200 ⚠️'})")
