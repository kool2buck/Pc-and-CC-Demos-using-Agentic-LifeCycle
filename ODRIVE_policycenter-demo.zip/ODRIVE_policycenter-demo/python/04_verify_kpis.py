#!/usr/bin/env python3
"""KPI Verification Script — runs against policycenter.db and prints all 9 KPIs"""
import sqlite3, sys
DB = 'policycenter.db'
c = sqlite3.connect(DB).cursor()

def fmt_money(v): return f'${v:,.0f}'
def fmt_pct(v):   return f'{v:.1f}%'

print("=" * 55)
print("DONEGAL INSURANCE — POLICYCENTER KPI REPORT")
print("=" * 55)

prem = c.execute("SELECT SUM(total_written_premium) FROM anl_fact_policy_aggregate").fetchone()[0]
print(f"KPI 1: Total Premium Written   {fmt_money(prem)}")

pol = c.execute("SELECT COUNT(*) FROM anl_dim_policy WHERE is_current=1").fetchone()[0]
print(f"KPI 2: Policy Count            {pol:,}")

rr = c.execute("SELECT AVG(renewal_rate) FROM anl_fact_policy_aggregate").fetchone()[0]
print(f"KPI 3: Renewal Rate            {fmt_pct(rr*100)}")

ap = prem / pol if pol else 0
print(f"KPI 4: Average Premium         {fmt_money(ap)}")

lr = c.execute("SELECT AVG(lapse_rate) FROM anl_fact_policy_aggregate").fetchone()[0]
print(f"KPI 5: Lapse Rate              {fmt_pct(lr*100)}")

trend = c.execute("SELECT COUNT(DISTINCT date_key) FROM anl_fact_policy_transaction WHERE date_key >= strftime('%Y%m%d',date('now','-30 days'))").fetchone()[0]
print(f"KPI 6: 30-Day Trend Points     {trend} data points")

top = c.execute("SELECT a.agent_name, SUM(f.total_written_premium) as p FROM anl_fact_policy_aggregate f JOIN anl_dim_agent a ON f.agent_key=a.agent_key GROUP BY f.agent_key ORDER BY p DESC LIMIT 1").fetchone()
print(f"KPI 7: Top Agent               {top[0]} {fmt_money(top[1])}")

lob = c.execute("SELECT lob, SUM(total_written_premium) as p FROM anl_fact_policy_aggregate GROUP BY lob ORDER BY p DESC LIMIT 1").fetchone()
print(f"KPI 8: Top LOB                 {lob[0]} {fmt_money(lob[1])}")

hr = c.execute("SELECT CAST(SUM(bound_count) AS REAL)/SUM(total_quotes) FROM anl_fact_quote_summary").fetchone()[0]
hr_nb = c.execute("SELECT CAST(SUM(bound_count) AS REAL)/SUM(total_quotes) FROM anl_fact_quote_summary WHERE quote_type='NewBusiness'").fetchone()[0]
hr_rn = c.execute("SELECT CAST(SUM(bound_count) AS REAL)/SUM(total_quotes) FROM anl_fact_quote_summary WHERE quote_type='Renewal'").fetchone()[0]
print(f"KPI 9: Hit Ratio (Overall)     {fmt_pct(hr*100)}")
print(f"       Hit Ratio (NB)          {fmt_pct(hr_nb*100)}")
print(f"       Hit Ratio (Renewal)     {fmt_pct(hr_rn*100)}")
print("=" * 55)
