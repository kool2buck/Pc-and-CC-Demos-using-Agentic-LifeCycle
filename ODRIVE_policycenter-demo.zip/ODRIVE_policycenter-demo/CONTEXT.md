# PC_DASHBOARD_DEMO_2025 — Context Document
**For:** Donegal Insurance IT/Data Team
**Date:** 2026-06-16

## What This Demo Shows
1. **North Star Architecture** — 12 agents automating the complete SDLC for Guidewire data warehouse projects
2. **5-Layer ETL** — the Donegal standard for all Guidewire source pipelines
3. **Real PolicyCenter Data** — 1,200 policies, 5 LOBs, 25 agents, quote-to-bind analytics
4. **Grading Loops** — how agents self-improve when they score below 92/100
5. **Business Sign-Off Gate** — hard stop before dashboard generates

## How This Applies to Production
| Demo Element | Production Equivalent |
|--------------|----------------------|
| policycenter.db (SQLite) | Snowflake on Azure |
| Python ETL scripts | Azure Data Factory + Stored Procs |
| Single HTML dashboard | Power BI (or this HTML, embedded) |
| grillmewithdocs | Claude Sonnet in Claude Code |
| grading-agent | Automated CI quality gate |
| business-signoff | JIRA sign-off ticket + Confluence |

## What Comes Next
1. BillingCenter demo (same architecture, BC source tables)
2. ClaimsCenter demo (CC source tables, Loss Ratio KPI)
3. Cross-center demo (Loss Ratio = CC / PC premium join)
