# Projects — Obsidian Vault
## PC_DASHBOARD_DEMO_2025
See [[PC_DASHBOARD_DEMO]] for complete status.

## Future Projects
- BillingCenter Demo (BC_DASHBOARD_DEMO_2025)
- ClaimsCenter Demo (CC_DASHBOARD_DEMO_2025)
- Cross-Center Loss Ratio (PC+CC combined)
