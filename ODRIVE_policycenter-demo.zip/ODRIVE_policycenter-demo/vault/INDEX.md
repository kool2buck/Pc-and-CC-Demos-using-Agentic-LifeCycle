# 🎯 PolicyCenter Demo — LLM Wiki (Second Brain)

**Project:** PC_DASHBOARD_DEMO_2025  
**Date:** 2026-06-16  |  **Status:** ✅ ALL AGENTS PASSED  |  **CDO Approval:** ✅ APPROVED

---

## 🤖 Agents
[[agents/grading-agent]] | [[agents/orchestrator]] | [[agents/obsidian-llm-wiki]]
[[agents/plan-agent]] | [[agents/grillmewithdocs]] | [[agents/to-prd]]
[[agents/schema-discovery]] | [[agents/dev-build]] | [[agents/tdd]]
[[agents/qa-100]] | [[agents/adf-pipeline]] | [[agents/business-signoff]]

## 📄 Artifacts
[[artifacts/BRD]] | [[artifacts/PRD]] | [[artifacts/Technical_Requirements]]
[[artifacts/Schema_Audit]] | [[artifacts/Data_Dictionary]]
[[artifacts/ETL_Pipeline_Architecture]] | [[artifacts/SIGNOFF_PACKAGE]]

## 📊 Dashboards
[[artifacts/dashboard]] — Business Dashboard (9 KPIs, 5 LOB filter)
[[artifacts/POLICYCENTER_SDLC_DEMO]] — Agent Pipeline Demo
[[artifacts/wiki]] — This LLM Wiki

## 📚 Glossary
[[glossary/PolicyCenter]] | [[glossary/BillingCenter]] | [[glossary/ClaimsCenter]]

## 🧠 Knowledge Base
[[knowledge-base/etl_patterns]] | [[knowledge-base/scd_types]]
[[knowledge-base/grain_definitions]] | [[knowledge-base/pii_masking]]
[[knowledge-base/lessons_learned]]

## 🏗️ Projects
[[projects/PC_DASHBOARD_DEMO]]
