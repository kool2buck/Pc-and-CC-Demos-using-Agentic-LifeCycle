# grading-agent
**Type:** Platform  |  **Score:** 98/100  |  **Loops:** 1  |  **Status:** PASS

## Description
Grades all agents. 92% gate. Issues REWARD/REWORK.

## Links
- Skill: [[../skills/grading-agent]]
- Grade Records: [[../artifacts/grade-records]]
