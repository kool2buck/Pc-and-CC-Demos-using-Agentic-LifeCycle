# obsidian-llm-wiki
**Type:** Platform  |  **Score:** N/A  |  **Loops:** 1  |  **Status:** PASS

## Description
Second Brain. Knowledge graph. All artifacts indexed.

## Links
- Skill: [[../skills/obsidian-llm-wiki]]
- Grade Records: [[../artifacts/grade-records]]
