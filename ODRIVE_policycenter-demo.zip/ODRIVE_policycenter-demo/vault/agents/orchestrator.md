# orchestrator
**Type:** Platform  |  **Score:** 96/100  |  **Loops:** 1  |  **Status:** PASS

## Description
Fleet allocation. Model policy (Haiku/Sonnet). Pipeline state.

## Links
- Skill: [[../skills/orchestrator]]
- Grade Records: [[../artifacts/grade-records]]
