# Scd Types
**File:** knowledge-base/scd_types.md

See the source file for full content.

## Links
- Source: knowledge-base/scd_types.md
- [[../agents/dev-build]] | [[../agents/grillmewithdocs]]
