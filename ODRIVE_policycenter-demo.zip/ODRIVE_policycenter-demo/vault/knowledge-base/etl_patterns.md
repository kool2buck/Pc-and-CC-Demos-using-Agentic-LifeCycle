# Etl Patterns
**File:** knowledge-base/etl_patterns.md

See the source file for full content.

## Links
- Source: knowledge-base/etl_patterns.md
- [[../agents/dev-build]] | [[../agents/grillmewithdocs]]
