# Skill: schema-discovery
**SKILL.md:** _skills/schema-discovery/SKILL.md
**SKILL_v2.md:** _skills/schema-discovery/SKILL_v2.md (revised after Loop 1 FAIL)

## Companion Files
See _skills/schema-discovery/ for all companion files.

## Related
- [[../agents/schema-discovery]]
