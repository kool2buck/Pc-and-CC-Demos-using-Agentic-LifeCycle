# Skill: obsidian-llm-wiki
**SKILL.md:** _skills/obsidian-llm-wiki/SKILL.md


## Companion Files
See _skills/obsidian-llm-wiki/ for all companion files.

## Related
- [[../agents/obsidian-llm-wiki]]
