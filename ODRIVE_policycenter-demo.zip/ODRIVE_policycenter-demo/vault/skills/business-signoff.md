# Skill: business-signoff
**SKILL.md:** _skills/business-signoff/SKILL.md


## Companion Files
See _skills/business-signoff/ for all companion files.

## Related
- [[../agents/business-signoff]]
