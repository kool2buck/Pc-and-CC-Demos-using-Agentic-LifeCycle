# Skill: to-prd
**SKILL.md:** _skills/to-prd/SKILL.md
**SKILL_v2.md:** _skills/to-prd/SKILL_v2.md (revised after Loop 1 FAIL)

## Companion Files
See _skills/to-prd/ for all companion files.

## Related
- [[../agents/to-prd]]
