# Skill: grillmewithdocs
**SKILL.md:** _skills/grillmewithdocs/SKILL.md
**SKILL_v2.md:** _skills/grillmewithdocs/SKILL_v2.md (revised after Loop 1 FAIL)

## Companion Files
See _skills/grillmewithdocs/ for all companion files.

## Related
- [[../agents/grillmewithdocs]]
