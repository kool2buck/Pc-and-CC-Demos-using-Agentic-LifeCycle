# Skill: grading-agent
**SKILL.md:** _skills/grading-agent/SKILL.md


## Companion Files
See _skills/grading-agent/ for all companion files.

## Related
- [[../agents/grading-agent]]
