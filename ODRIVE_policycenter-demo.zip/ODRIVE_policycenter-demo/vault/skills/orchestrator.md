# Skill: orchestrator
**SKILL.md:** _skills/orchestrator/SKILL.md


## Companion Files
See _skills/orchestrator/ for all companion files.

## Related
- [[../agents/orchestrator]]
