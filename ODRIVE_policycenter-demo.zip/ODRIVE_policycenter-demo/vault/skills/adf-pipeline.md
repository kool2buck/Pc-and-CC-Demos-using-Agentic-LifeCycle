# Skill: adf-pipeline
**SKILL.md:** _skills/adf-pipeline/SKILL.md


## Companion Files
See _skills/adf-pipeline/ for all companion files.

## Related
- [[../agents/adf-pipeline]]
