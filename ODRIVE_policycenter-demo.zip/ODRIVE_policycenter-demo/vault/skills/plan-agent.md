# Skill: plan-agent
**SKILL.md:** _skills/plan-agent/SKILL.md


## Companion Files
See _skills/plan-agent/ for all companion files.

## Related
- [[../agents/plan-agent]]
