# PolicyCenter Glossary
**File:** glossary/policycenter.md

## Summary
6 entities: Policy, PolicyPeriod, Transaction, Quote, Agent, Product. PII: insured_name.

## Links
- Full glossary: glossary/policycenter.md
- Used by: [[../agents/grillmewithdocs]]
