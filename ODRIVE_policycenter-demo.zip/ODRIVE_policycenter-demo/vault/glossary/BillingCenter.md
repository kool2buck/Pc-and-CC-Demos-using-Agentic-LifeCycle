# BillingCenter Glossary
**File:** glossary/billingcenter.md

## Summary
5 entities: Account, Charge, Payment, Invoice, Disbursement.

## Links
- Full glossary: glossary/billingcenter.md
- Used by: [[../agents/grillmewithdocs]]
