# ClaimsCenter Glossary
**File:** glossary/claimscenter.md

## Summary
5 entities: Claim, Exposure, Reserve, Transaction, Settlement.

## Links
- Full glossary: glossary/claimscenter.md
- Used by: [[../agents/grillmewithdocs]]
