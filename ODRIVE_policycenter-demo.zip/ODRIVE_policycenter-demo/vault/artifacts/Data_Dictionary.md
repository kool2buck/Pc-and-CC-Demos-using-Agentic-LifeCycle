# Artifact: Data_Dictionary
**Produced by:** [[../agents/dev-build]]  
**File:** artifacts/Data_Dictionary.md

## Description
All 7 analytical tables with column definitions, types, and PII flags.

## Links
- Producer: [[../agents/dev-build]]
- Source file: artifacts/Data_Dictionary.md
