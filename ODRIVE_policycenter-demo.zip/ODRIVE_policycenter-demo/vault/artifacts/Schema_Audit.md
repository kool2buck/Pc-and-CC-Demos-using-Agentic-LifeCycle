# Artifact: Schema_Audit
**Produced by:** [[../agents/schema-discovery]]  
**File:** artifacts/Schema_Audit.md

## Description
All 6 PC tables. 9 FK relationships. Nullable fields. Data quality flags.

## Links
- Producer: [[../agents/schema-discovery]]
- Source file: artifacts/Schema_Audit.md
