# Artifact: BRD
**Produced by:** [[../agents/grillmewithdocs]]  
**File:** artifacts/BRD.md

## Description
Business Requirements Document v2.0. 9 KPIs, 5 LOBs, quote grain, PII rules, LOB ranges.

## Links
- Producer: [[../agents/grillmewithdocs]]
- Source file: artifacts/BRD.md
