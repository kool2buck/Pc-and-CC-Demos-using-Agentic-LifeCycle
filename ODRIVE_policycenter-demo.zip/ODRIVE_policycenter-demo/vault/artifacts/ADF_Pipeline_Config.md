# ADF_Pipeline_Config
**File:** artifacts/ADF_Pipeline_Config.md

Azure Data Factory pipeline config. 6 activities. Nightly 02:00 ET. See _skills/adf-pipeline/pipeline_config.md

## Links
- Source: artifacts/ADF_Pipeline_Config.md
