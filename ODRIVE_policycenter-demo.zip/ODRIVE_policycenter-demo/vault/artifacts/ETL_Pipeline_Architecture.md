# ETL Pipeline Architecture
**File:** artifacts/ETL_Pipeline_Architecture.md

See the source artifact file for full content.

## Links
- [[../agents/dev-build]]
