# Dimensional Model
**File:** artifacts/Dimensional_Model.md

See the source artifact file for full content.

## Links
- [[../agents/dev-build]]
