# Artifact: PRD
**Produced by:** [[../agents/to-prd]]  
**File:** artifacts/PRD.md

## Description
Product Requirements Document v2.0. Data lineage per KPI. 3-dashboard spec. Sign-off gate.

## Links
- Producer: [[../agents/to-prd]]
- Source file: artifacts/PRD.md
