#!/usr/bin/env python3
"""
PolicyCenter Demo — Dashboard Generator
Queries Analytical Layer → Embeds JSON → Writes single-file HTML
"""
import sqlite3, json, os
from datetime import datetime

DB_PATH  = '/home/claude/policycenter_demo/policycenter.db'
OUT_PATH = '/home/claude/policycenter_demo/dashboard.html'

def q(c, sql, p=()):
    return c.execute(sql, p).fetchall()

def one(c, sql, p=()):
    return c.execute(sql, p).fetchone()

# ─────────────────────────────────────────────────────────────────────────────
# EXTRACT all data per LOB (pre-computed for JS filter switching)
# ─────────────────────────────────────────────────────────────────────────────
def extract(conn):
    c    = conn.cursor()
    lobs = ['all','PersonalAuto','Homeowners','CommercialAuto','DwellingFire','WorkersComp']
    D    = {}

    for lob in lobs:
        fw = f"WHERE f.lob='{lob}'"   if lob != 'all' else ''
        tw = f"AND t.lob='{lob}'"     if lob != 'all' else ''
        qw = f"WHERE q.lob='{lob}'"   if lob != 'all' else ''
        rw = f"AND rq.lob='{lob}'"    if lob != 'all' else ''

        # ── Summary KPIs ────────────────────────────────────────────────────
        s = one(c, f"""
            SELECT ROUND(SUM(f.total_written_premium),0),
                   SUM(f.policy_count),
                   ROUND(SUM(f.total_written_premium)/NULLIF(SUM(f.policy_count),0),0),
                   ROUND(CAST(SUM(f.renewal_count) AS REAL)/NULLIF(SUM(f.policy_count),0)*100,1),
                   ROUND(CAST(SUM(f.lapse_count)   AS REAL)/NULLIF(SUM(f.policy_count),0)*100,2)
            FROM anl_fact_policy_aggregate f {fw}
        """)

        # ── 30-Day Trend ────────────────────────────────────────────────────
        trend = q(c, f"""
            SELECT d.full_date, ROUND(SUM(t.premium_amount),0)
            FROM anl_fact_policy_transaction t
            JOIN anl_dim_date d ON t.date_key = d.date_key
            WHERE d.full_date >= date('now','-30 days')
              AND t.transaction_type IN ('NewBusiness','Renewal') {tw}
            GROUP BY d.full_date ORDER BY d.full_date
        """)

        # ── Top 5 Agents ────────────────────────────────────────────────────
        agents = q(c, f"""
            SELECT a.agent_name, ROUND(SUM(f.total_written_premium),0)
            FROM anl_fact_policy_aggregate f
            JOIN anl_dim_agent a ON f.agent_key = a.agent_key
            {fw}
            GROUP BY a.agent_key, a.agent_name ORDER BY 2 DESC LIMIT 5
        """)

        # ── LOB Breakdown ───────────────────────────────────────────────────
        lob_cond = f"WHERE lob='{lob}'" if lob != 'all' else ''
        lbd = q(c, f"""
            SELECT lob, ROUND(SUM(total_written_premium),0), SUM(policy_count)
            FROM anl_fact_policy_aggregate {lob_cond}
            GROUP BY lob ORDER BY 2 DESC
        """)

        # ── Hit Ratio ───────────────────────────────────────────────────────
        h = one(c, f"""
            SELECT SUM(total_quotes), SUM(bound_count),
                   ROUND(CAST(SUM(bound_count) AS REAL)/NULLIF(SUM(total_quotes),0)*100,1),
                   SUM(CASE WHEN quote_type='NewBusiness' THEN total_quotes ELSE 0 END),
                   SUM(CASE WHEN quote_type='NewBusiness' THEN bound_count  ELSE 0 END),
                   SUM(CASE WHEN quote_type='Renewal'     THEN total_quotes ELSE 0 END),
                   SUM(CASE WHEN quote_type='Renewal'     THEN bound_count  ELSE 0 END),
                   SUM(declined_count), SUM(expired_count), SUM(inprogress_count)
            FROM anl_fact_quote_summary q {qw}
        """)
        nb_hr  = round(h[4]/h[3]*100,1) if h[3] else 0
        ren_hr = round(h[6]/h[5]*100,1) if h[5] else 0

        # ── Decline Reasons ─────────────────────────────────────────────────
        dr = q(c, f"""
            SELECT rq.decline_reason, COUNT(*) as cnt
            FROM raw_quote rq
            WHERE rq.status='Declined' AND rq.decline_reason IS NOT NULL {rw}
            GROUP BY rq.decline_reason ORDER BY cnt DESC
        """)

        # ── Hit Ratio by LOB ────────────────────────────────────────────────
        hl = q(c, f"""
            SELECT lob, SUM(total_quotes), SUM(bound_count),
                   ROUND(CAST(SUM(bound_count) AS REAL)/NULLIF(SUM(total_quotes),0)*100,1)
            FROM anl_fact_quote_summary q {qw}
            GROUP BY lob ORDER BY 4 DESC
        """)

        # ── Monthly Trend (full history) ────────────────────────────────────
        monthly = q(c, f"""
            SELECT f.period_year || '-' || printf('%02d', f.period_month) as ym,
                   ROUND(SUM(f.total_written_premium),0)
            FROM anl_fact_policy_aggregate f {fw}
            GROUP BY f.period_year, f.period_month
            ORDER BY f.period_year, f.period_month
            LIMIT 24
        """)

        D[lob] = {
            's':  [float(s[0] or 0), int(s[1] or 0), float(s[2] or 0),
                   float(s[3] or 0), float(s[4] or 0)],
            'tr': {'x': [r[0] for r in trend],    'y': [float(r[1]) for r in trend]},
            'ag': {'x': [r[0] for r in agents],   'y': [float(r[1]) for r in agents]},
            'lb': {'x': [r[0] for r in lbd],      'y': [float(r[1]) for r in lbd],
                   'n': [int(r[2]) for r in lbd]},
            'h':  [int(h[0] or 0), int(h[1] or 0), float(h[2] or 0),
                   int(h[3] or 0), int(h[4] or 0), nb_hr,
                   int(h[5] or 0), int(h[6] or 0), ren_hr,
                   int(h[7] or 0), int(h[8] or 0), int(h[9] or 0)],
            'dr': {'x': [r[0] for r in dr],       'y': [int(r[1]) for r in dr]},
            'hl': {'x': [r[0] for r in hl],       'y': [float(r[3]) for r in hl],
                   'b': [int(r[2]) for r in hl],  't': [int(r[1]) for r in hl]},
            'mo': {'x': [r[0] for r in monthly],  'y': [float(r[1]) for r in monthly]},
        }

    return D

# ─────────────────────────────────────────────────────────────────────────────
# BUILD HTML
# ─────────────────────────────────────────────────────────────────────────────
def build_html(data, today_str):
    json_str = json.dumps(data)

    # ── CSS ──────────────────────────────────────────────────────────────────
    css = """
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',Arial,sans-serif;background:#f0f2f7;color:#1a2744}
:root{--navy:#1a2744;--gold:#c9a227;--blue:#2d5a8e;--light:#4a90d9;--bg:#f0f2f7;
      --card:#fff;--green:#27a74a;--red:#d63031;--orange:#e67e22;--text:#1a2744;--sub:#666}

/* HEADER */
.hdr{background:var(--navy);color:#fff;padding:16px 24px;
     display:flex;align-items:center;justify-content:space-between;
     border-bottom:3px solid var(--gold)}
.hdr-brand{display:flex;align-items:center;gap:12px}
.hdr-logo{width:44px;height:44px;background:var(--gold);border-radius:8px;
          display:flex;align-items:center;justify-content:center;
          font-weight:900;font-size:18px;color:var(--navy)}
.hdr-title h1{font-size:20px;font-weight:700;letter-spacing:.3px}
.hdr-title p{font-size:12px;color:rgba(255,255,255,.65);margin-top:2px}
.hdr-meta{text-align:right;font-size:12px;color:rgba(255,255,255,.6)}
.hdr-meta strong{display:block;font-size:14px;color:#fff}

/* LOB FILTER */
.filter-bar{background:#fff;padding:12px 24px;border-bottom:1px solid #dde2ec;
            display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.filter-bar span{font-size:12px;font-weight:600;color:var(--sub);margin-right:4px;text-transform:uppercase;letter-spacing:.5px}
.lob-btn{padding:6px 16px;border-radius:20px;border:1.5px solid #d0d7e8;
         background:#fff;color:var(--navy);font-size:13px;font-weight:500;
         cursor:pointer;transition:all .2s}
.lob-btn:hover{border-color:var(--navy);background:#f5f7ff}
.lob-btn.active{background:var(--navy);color:#fff;border-color:var(--navy)}

/* MAIN LAYOUT */
.main{padding:20px 24px;display:flex;flex-direction:column;gap:18px}

/* KPI CARDS */
.kpi-row{display:grid;grid-template-columns:repeat(6,1fr);gap:14px}
.kpi{background:var(--card);border-radius:10px;padding:16px 18px;
     box-shadow:0 2px 8px rgba(0,0,0,.06);border-left:4px solid var(--navy)}
.kpi.gold{border-left-color:var(--gold)}
.kpi.green{border-left-color:var(--green)}
.kpi.red{border-left-color:var(--red)}
.kpi.blue{border-left-color:var(--light)}
.kpi.orange{border-left-color:var(--orange)}
.kpi-label{font-size:11px;font-weight:600;color:var(--sub);text-transform:uppercase;letter-spacing:.6px}
.kpi-value{font-size:26px;font-weight:700;color:var(--navy);margin-top:4px;line-height:1.1}
.kpi-sub{font-size:11px;color:var(--sub);margin-top:3px}

/* CARDS */
.row{display:grid;gap:18px}
.row-2{grid-template-columns:1fr 1fr}
.row-3{grid-template-columns:1fr 1fr 1fr}
.row-1{grid-template-columns:1fr}
.panel{background:var(--card);border-radius:10px;padding:18px 20px;
       box-shadow:0 2px 8px rgba(0,0,0,.06)}
.panel-title{font-size:13px;font-weight:700;color:var(--navy);
             text-transform:uppercase;letter-spacing:.5px;
             border-bottom:2px solid var(--gold);padding-bottom:8px;margin-bottom:14px;
             display:flex;justify-content:space-between;align-items:center}
.panel-title .badge{font-size:11px;background:var(--bg);color:var(--sub);
                    border-radius:12px;padding:2px 8px;font-weight:500;letter-spacing:0}

/* HIT RATIO CARDS */
.hit-row{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:14px}
.hit-card{background:var(--bg);border-radius:8px;padding:14px 16px;text-align:center}
.hit-card .hc-val{font-size:32px;font-weight:800;color:var(--navy)}
.hit-card .hc-val.green{color:var(--green)}
.hit-card .hc-val.blue{color:var(--blue)}
.hit-card .hc-label{font-size:11px;color:var(--sub);font-weight:600;text-transform:uppercase;letter-spacing:.5px;margin-top:2px}
.hit-card .hc-sub{font-size:12px;color:var(--sub);margin-top:4px}

/* FUNNEL */
.funnel{display:flex;flex-direction:column;gap:6px}
.funnel-row{display:flex;align-items:center;gap:8px}
.funnel-label{font-size:12px;color:var(--sub);width:90px;text-align:right;flex-shrink:0}
.funnel-bar-wrap{flex:1;background:#f0f2f7;border-radius:4px;height:22px;overflow:hidden}
.funnel-bar{height:100%;border-radius:4px;display:flex;align-items:center;
            padding-left:8px;font-size:11px;font-weight:600;color:#fff;min-width:30px;transition:width .4s}
.funnel-count{font-size:12px;font-weight:700;color:var(--navy);width:48px;flex-shrink:0}

/* TABLES */
.mini-table{width:100%;border-collapse:collapse;font-size:12px}
.mini-table th{background:#f5f7ff;color:var(--sub);padding:6px 10px;text-align:left;
               font-size:11px;font-weight:600;letter-spacing:.4px;text-transform:uppercase}
.mini-table td{padding:7px 10px;border-bottom:1px solid #f0f2f7;color:var(--navy)}
.mini-table tr:last-child td{border-bottom:none}
.mini-table tr:hover td{background:#fafbff}

/* FOOTER */
.footer{text-align:center;padding:12px;font-size:11px;color:var(--sub)}
"""

    # ── HTML BODY ─────────────────────────────────────────────────────────────
    body = """
<div class="hdr">
  <div class="hdr-brand">
    <div class="hdr-logo">DIG</div>
    <div class="hdr-title">
      <h1>Donegal Insurance Group</h1>
      <p>PolicyCenter Analytics Dashboard &mdash; Analytical Layer (Simulated PowerBI)</p>
    </div>
  </div>
  <div class="hdr-meta">
    <strong id="cur-date"></strong>
    <span>Data Load: """ + today_str + """</span><br>
    <span>Guidewire PolicyCenter &rarr; Snowflake Analytical Layer</span>
  </div>
</div>

<div class="filter-bar">
  <span>Line of Business:</span>
  <button class="lob-btn active" onclick="setLOB('all')">All LOBs</button>
  <button class="lob-btn" onclick="setLOB('PersonalAuto')">Personal Auto</button>
  <button class="lob-btn" onclick="setLOB('Homeowners')">Homeowners</button>
  <button class="lob-btn" onclick="setLOB('CommercialAuto')">Commercial Auto</button>
  <button class="lob-btn" onclick="setLOB('DwellingFire')">Dwelling &amp; Fire</button>
  <button class="lob-btn" onclick="setLOB('WorkersComp')">Workers Comp</button>
</div>

<div class="main">

  <!-- KPI ROW -->
  <div class="kpi-row">
    <div class="kpi gold">
      <div class="kpi-label">Total Premium Written</div>
      <div class="kpi-value" id="k-prem">—</div>
      <div class="kpi-sub">Written premium, all terms</div>
    </div>
    <div class="kpi">
      <div class="kpi-label">Policy Count</div>
      <div class="kpi-value" id="k-cnt">—</div>
      <div class="kpi-sub">Active + expired policies</div>
    </div>
    <div class="kpi blue">
      <div class="kpi-label">Avg Premium / Policy</div>
      <div class="kpi-value" id="k-avg">—</div>
      <div class="kpi-sub">Weighted average</div>
    </div>
    <div class="kpi green">
      <div class="kpi-label">Hit Ratio</div>
      <div class="kpi-value" id="k-hit">—</div>
      <div class="kpi-sub">Bound / Total Quotes</div>
    </div>
    <div class="kpi orange">
      <div class="kpi-label">Renewal Rate</div>
      <div class="kpi-value" id="k-ren">—</div>
      <div class="kpi-sub">Renewal periods / total</div>
    </div>
    <div class="kpi red">
      <div class="kpi-label">Lapse Rate</div>
      <div class="kpi-value" id="k-lps">—</div>
      <div class="kpi-sub">Cancelled / total policies</div>
    </div>
  </div>

  <!-- TREND (full width) -->
  <div class="row row-1">
    <div class="panel">
      <div class="panel-title">30-Day Premium Trend
        <span class="badge">New Business &amp; Renewals only</span>
      </div>
      <canvas id="c-trend" height="90"></canvas>
    </div>
  </div>

  <!-- LOB + AGENTS -->
  <div class="row row-2">
    <div class="panel">
      <div class="panel-title">Premium by Line of Business</div>
      <canvas id="c-lob" height="220"></canvas>
    </div>
    <div class="panel">
      <div class="panel-title">Top 5 Agents by Premium</div>
      <canvas id="c-agents" height="220"></canvas>
    </div>
  </div>

  <!-- HIT RATIO SECTION -->
  <div class="row row-2">
    <div class="panel">
      <div class="panel-title">Hit Ratio — Quote to Bind</div>
      <div class="hit-row">
        <div class="hit-card">
          <div class="hc-val" id="h-overall">—</div>
          <div class="hc-label">Overall</div>
          <div class="hc-sub" id="h-overall-sub">—</div>
        </div>
        <div class="hit-card">
          <div class="hc-val blue" id="h-nb">—</div>
          <div class="hc-label">New Business</div>
          <div class="hc-sub" id="h-nb-sub">—</div>
        </div>
        <div class="hit-card">
          <div class="hc-val green" id="h-ren">—</div>
          <div class="hc-label">Renewal</div>
          <div class="hc-sub" id="h-ren-sub">—</div>
        </div>
      </div>
      <div class="panel-title" style="margin-top:4px">Quote Funnel</div>
      <div class="funnel" id="funnel"></div>
    </div>
    <div class="panel">
      <div class="panel-title">Decline Reasons</div>
      <canvas id="c-dr" height="180"></canvas>
    </div>
  </div>

  <!-- HIT RATIO BY LOB -->
  <div class="row row-1">
    <div class="panel">
      <div class="panel-title">Hit Ratio by Line of Business</div>
      <canvas id="c-hl" height="80"></canvas>
    </div>
  </div>

</div>
<div class="footer">
  Donegal Insurance Group &mdash; PolicyCenter Analytics Demo &mdash; Analytical Layer &mdash; 
  Guidewire PolicyCenter &rarr; STAGING &rarr; RAW &rarr; EXPLORATION &rarr; CONFORMED &rarr; ANALYTICAL
</div>
"""

    # ── JAVASCRIPT ────────────────────────────────────────────────────────────
    js = r"""
document.getElementById('cur-date').textContent = new Date().toLocaleDateString('en-US',
  {weekday:'short',year:'numeric',month:'long',day:'numeric'});

const PALETTE = ['#1a2744','#2d5a8e','#4a90d9','#7bb8e8','#b8d9f0','#c9a227'];
const LOB_COLORS = {
  PersonalAuto:'#1a2744', Homeowners:'#2d5a8e', CommercialAuto:'#4a90d9',
  DwellingFire:'#c9a227', WorkersComp:'#e67e22'
};

function fmt$(v){ if(v>=1e6) return '$'+( v/1e6).toFixed(1)+'M';
                  if(v>=1e3) return '$'+(v/1e3).toFixed(0)+'K'; return '$'+v.toFixed(0); }
function fmt2(v){ return v.toFixed(1)+'%'; }
function fmtN(v){ return v.toLocaleString(); }

let charts = {};

function destroyChart(id){
  if(charts[id]){ charts[id].destroy(); delete charts[id]; }
}

function setLOB(lob){
  document.querySelectorAll('.lob-btn').forEach(b=>{
    b.classList.toggle('active', b.textContent.includes(
      lob==='all'?'All':lob==='DwellingFire'?'Dwelling':lob==='WorkersComp'?'Workers':
      lob==='CommercialAuto'?'Commercial':lob==='PersonalAuto'?'Personal':'Homeowners'
    ));
  });
  render(lob);
}

function render(lob){
  const d = DATA[lob];
  const s = d.s;   // [total_prem, policy_cnt, avg_prem, renewal_rate, lapse_rate]
  const h = d.h;   // [total_q, bound, overall%, nb_total, nb_bound, nb%, ren_total, ren_bound, ren%, declined, expired, inprog]

  // ── KPI Cards ──
  document.getElementById('k-prem').textContent = fmt$(s[0]);
  document.getElementById('k-cnt').textContent  = fmtN(s[1]);
  document.getElementById('k-avg').textContent  = fmt$(s[2]);
  document.getElementById('k-hit').textContent  = fmt2(h[2]);
  document.getElementById('k-ren').textContent  = fmt2(s[3]);
  document.getElementById('k-lps').textContent  = s[4].toFixed(2)+'%';

  // ── Hit Ratio Cards ──
  document.getElementById('h-overall').textContent     = fmt2(h[2]);
  document.getElementById('h-overall-sub').textContent = fmtN(h[1])+' bound / '+fmtN(h[0])+' quotes';
  document.getElementById('h-nb').textContent          = fmt2(h[5]);
  document.getElementById('h-nb-sub').textContent      = fmtN(h[4])+' bound / '+fmtN(h[3])+' NB quotes';
  document.getElementById('h-ren').textContent         = fmt2(h[8]);
  document.getElementById('h-ren-sub').textContent     = fmtN(h[7])+' bound / '+fmtN(h[6])+' ren quotes';

  // ── Quote Funnel ──
  const maxQ = h[0];
  const funnelData = [
    {label:'Quoted',  count:h[0],  pct:100,                          color:'#2d5a8e'},
    {label:'Bound',   count:h[1],  pct:Math.round(h[1]/maxQ*100),    color:'#27a74a'},
    {label:'Declined',count:h[9],  pct:Math.round(h[9]/maxQ*100),    color:'#d63031'},
    {label:'Expired', count:h[10], pct:Math.round(h[10]/maxQ*100),   color:'#e67e22'},
    {label:'In Prog', count:h[11], pct:Math.round(h[11]/maxQ*100),   color:'#7bb8e8'},
  ];
  document.getElementById('funnel').innerHTML = funnelData.map(f=>
    `<div class="funnel-row">
       <div class="funnel-label">${f.label}</div>
       <div class="funnel-bar-wrap">
         <div class="funnel-bar" style="width:${f.pct}%;background:${f.color}">${f.pct}%</div>
       </div>
       <div class="funnel-count">${fmtN(f.count)}</div>
     </div>`
  ).join('');

  // ── 30-Day Trend ──
  destroyChart('trend');
  charts['trend'] = new Chart(document.getElementById('c-trend'), {
    type:'line',
    data:{
      labels: d.tr.x,
      datasets:[{
        label:'Daily Premium',
        data: d.tr.y,
        borderColor:'#c9a227', backgroundColor:'rgba(201,162,39,.12)',
        fill:true, tension:.35, pointRadius:3, pointBackgroundColor:'#c9a227',
        borderWidth:2.5
      }]
    },
    options:{
      responsive:true, plugins:{legend:{display:false},
        tooltip:{callbacks:{label:ctx=>fmt$(ctx.raw)}}},
      scales:{
        x:{ticks:{maxTicksLimit:10, maxRotation:0, font:{size:10}},
           grid:{color:'#eee'}},
        y:{ticks:{callback:v=>fmt$(v), font:{size:10}}, grid:{color:'#eee'}}
      }
    }
  });

  // ── LOB Donut ──
  const lbColors = d.lb.x.map(l=>LOB_COLORS[l]||'#888');
  destroyChart('lob');
  charts['lob'] = new Chart(document.getElementById('c-lob'), {
    type:'doughnut',
    data:{
      labels: d.lb.x,
      datasets:[{data:d.lb.y, backgroundColor:lbColors,
                 borderWidth:2, borderColor:'#fff',
                 hoverOffset:6}]
    },
    options:{
      responsive:true, cutout:'60%',
      plugins:{
        legend:{position:'right', labels:{font:{size:11}, boxWidth:14, padding:12}},
        tooltip:{callbacks:{label:ctx=>{
          const pct = (ctx.raw/d.lb.y.reduce((a,b)=>a+b,0)*100).toFixed(1);
          return ` ${fmt$(ctx.raw)}  (${pct}%)  |  ${fmtN(d.lb.n[ctx.dataIndex])} policies`;
        }}}
      }
    }
  });

  // ── Top Agents Horizontal Bar ──
  destroyChart('agents');
  charts['agents'] = new Chart(document.getElementById('c-agents'), {
    type:'bar',
    data:{
      labels: d.ag.x.map(n=>{ const p=n.split(' '); return p[0]+' '+p[p.length-1]; }),
      datasets:[{
        label:'Written Premium',
        data:d.ag.y,
        backgroundColor:'#2d5a8e', borderRadius:5, borderSkipped:false
      }]
    },
    options:{
      indexAxis:'y', responsive:true,
      plugins:{legend:{display:false},
        tooltip:{callbacks:{label:ctx=>fmt$(ctx.raw)}}},
      scales:{
        x:{ticks:{callback:v=>fmt$(v), font:{size:10}}, grid:{color:'#eee'}},
        y:{ticks:{font:{size:11}}, grid:{display:false}}
      }
    }
  });

  // ── Decline Reasons ──
  destroyChart('dr');
  charts['dr'] = new Chart(document.getElementById('c-dr'), {
    type:'bar',
    data:{
      labels: d.dr.x,
      datasets:[{
        label:'Count',
        data:d.dr.y,
        backgroundColor:['#d63031','#e67e22','#f39c12','#c0392b'],
        borderRadius:4, borderSkipped:false
      }]
    },
    options:{
      indexAxis:'y', responsive:true,
      plugins:{legend:{display:false}},
      scales:{
        x:{ticks:{font:{size:10}}, grid:{color:'#eee'}},
        y:{ticks:{font:{size:11}}, grid:{display:false}}
      }
    }
  });

  // ── Hit Ratio by LOB ──
  destroyChart('hl');
  charts['hl'] = new Chart(document.getElementById('c-hl'), {
    type:'bar',
    data:{
      labels: d.hl.x,
      datasets:[
        {label:'Hit Ratio %',
         data:d.hl.y,
         backgroundColor:d.hl.x.map(l=>LOB_COLORS[l]||'#4a90d9'),
         borderRadius:5, borderSkipped:false}
      ]
    },
    options:{
      responsive:true,
      plugins:{
        legend:{display:false},
        tooltip:{callbacks:{label:ctx=>{
          const i=ctx.dataIndex;
          return [`Hit Ratio: ${fmt2(ctx.raw)}`,
                  `Bound: ${fmtN(d.hl.b[i])} / ${fmtN(d.hl.t[i])} quotes`];
        }}}
      },
      scales:{
        y:{min:0, max:100, ticks:{callback:v=>v+'%', font:{size:10}},
           grid:{color:'#eee'}},
        x:{ticks:{font:{size:11}}, grid:{display:false}}
      }
    }
  });
}

render('all');
"""

    # ── ASSEMBLE ─────────────────────────────────────────────────────────────
    html  = '<!DOCTYPE html><html lang="en"><head>\n'
    html += '<meta charset="UTF-8">\n'
    html += '<meta name="viewport" content="width=device-width,initial-scale=1.0">\n'
    html += '<title>Donegal Insurance — PolicyCenter Dashboard</title>\n'
    html += '<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>\n'
    html += '<style>' + css + '</style>\n'
    html += '</head><body>\n'
    html += body
    html += '<script>\nconst DATA = ' + json_str + ';\n'
    html += js
    html += '\n</script>\n</body></html>'
    return html

# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    today_str = datetime.now().strftime('%Y-%m-%d')
    conn = sqlite3.connect(DB_PATH)
    print("Extracting data from Analytical Layer...")
    data = extract(conn)
    conn.close()

    print("Building dashboard HTML...")
    html = build_html(data, today_str)

    with open(OUT_PATH, 'w', encoding='utf-8') as f:
        f.write(html)

    size_kb = os.path.getsize(OUT_PATH) / 1024
    print(f"✅ Dashboard written: {OUT_PATH}")
    print(f"   Size: {size_kb:.1f} KB")
    print(f"   LOBs: all + 5 filters")
    print(f"   KPIs: 9 (6 cards + 5 charts)")
    print(f"\nOpen in browser: file://{OUT_PATH}")
