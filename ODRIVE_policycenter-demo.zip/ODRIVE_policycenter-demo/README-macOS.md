# macOS Setup & Portability Guide — PolicyCenter Demo

## First-Time Setup (< 2 minutes)
```bash
cd ~/Downloads/policycenter-demo   # or wherever you unzipped
chmod +x scripts/*.sh               # make scripts executable (once)
./scripts/launch-demo.sh            # opens all 3 dashboards
```

## Port to Another Mac
**Option 1 - USB:**
```bash
cp -r ~/policycenter-demo /Volumes/USB-DRIVE/
# On other Mac: cd /Volumes/USB-DRIVE/policycenter-demo && ./scripts/launch-demo.sh
```
**Option 2 - AirDrop:** Drag the folder → AirDrop to other Mac

**Option 3 - Zip:**
```bash
zip -r policycenter-demo.zip ~/policycenter-demo
# Email/transfer the zip
```

## Port to Windows
Transfer the folder. Open `scripts\launch-demo.bat`.
All HTML files work in any browser. SQLite .db opens in DB Browser for SQLite.

## File Paths Reference
| What | Path |
|------|------|
| All 3 dashboards | Root folder .html files |
| Python ETL scripts | python/ |
| Agent skills | _skills/ |
| Grading records | grading/grade-records/ |
| Artifacts | artifacts/ |
| Obsidian vault | vault/ |
| Glossaries | glossary/ |
| Database | policycenter.db |
