# Grade Record — ba-grill — Loop 1
**Date:** 2026-06-16  |  **Version:** v1.0  |  **Graded by:** grading-agent

## Rubric Scores
| Category         | Weight | Score | Notes                                                         |
|------------------|--------|-------|---------------------------------------------------------------|
| Accuracy         | 20     | 17    | KPI calculations mostly correct; renewal rate formula ambiguous|
| Completeness     | 20     | 14    | Quote grain undefined; LOB ranges missing; PII not addressed  |
| PC-Context       | 15     | 13    | LOBs listed but no DwellingFire-specific rules                |
| Data Quality     | 15     | 10    | No grain definition for pc_quote; nullable fields skipped     |
| Traceability     | 15     | 13    | KPIs traced to tables but not to specific columns             |
| Insight Quality  | 10     | 8     | Missing business context for hit ratio interpretation         |
| Formatting       | 5      | 5     | Readable                                                      |

## Total: 80/100 ❌ FAIL (threshold: 92)

## Gap List (REWORK signal)
1. **Quote grain undefined** — Define: one row per quote_id in pc_quote
2. **LOB premium ranges missing** — Add validation ranges for all 5 LOBs
3. **PII field insured_name not addressed** — Define handling per layer
4. **Renewal vs NB quote not distinguished** — Hit ratio must split by quote_type
5. **Renewal rate formula** — Clarify: period-level or policy-level?

## Signal: REWORK → ba-grill must revise to v2.0 and re-submit
