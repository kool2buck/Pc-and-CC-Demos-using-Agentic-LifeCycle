# Grade Record — ba-grill — Loop 2
**Date:** 2026-06-16  |  **Version:** v2.0  |  **Graded by:** grading-agent

## Rubric Scores
| Category         | Weight | Score | Notes                                                      |
|------------------|--------|-------|------------------------------------------------------------|
| Accuracy         | 20     | 19    | All KPI formulas now correct and column-level specific      |
| Completeness     | 20     | 19    | Grain defined, PII addressed, LOB ranges added             |
| PC-Context       | 15     | 15    | All 5 LOBs with validation ranges; DwellingFire included   |
| Data Quality     | 15     | 14    | Nullable pc_quote.policy_id documented; edge cases covered |
| Traceability     | 15     | 14    | KPIs traced to table.column level                          |
| Insight Quality  | 10     | 9     | Hit ratio NB vs Renewal split adds real business insight   |
| Formatting       | 5      | 5     | v2.0 versioned, gaps documented, changes clearly marked    |

## Total: 95/100 ✅ PASS

## Signal: REWARD
ba-grill v2.0 cleared the 92-point gate on Loop 2.
Unlocking: to-prd
