# Grade Record — schema-discovery — Loop 1
**Date:** 2026-06-16  |  **Version:** v1.0  |  **Graded by:** grading-agent

## Rubric Scores
| Category         | Weight | Score | Notes                                                    |
|------------------|--------|-------|----------------------------------------------------------|
| Accuracy         | 20     | 19    | Row counts verified; table names correct                 |
| Completeness     | 20     | 15    | pc_quote FK relationships missing entirely               |
| PC-Context       | 15     | 14    | All 6 tables discovered                                  |
| Data Quality     | 15     | 12    | Nullable fields not documented; no edge case notes       |
| Traceability     | 15     | 13    | FK graph incomplete (quote side)                         |
| Insight Quality  | 10     | 8     | No business rule note on quote→policy binding            |
| Formatting       | 5      | 5     | Clean table format                                       |

## Total: 86/100 ❌ FAIL (threshold: 92)

## Gap List (REWORK signal)
1. **pc_quote FKs missing** — Document all 3: policy_id, agent_id, product_id
2. **Nullable fields not documented** — policy_id/decline_reason/bound_date in pc_quote
3. **Business rule missing** — Quote→Policy binding logic (bound_count/hit_ratio source)

## Signal: REWORK → schema-discovery must revise to v2.0 and re-submit
