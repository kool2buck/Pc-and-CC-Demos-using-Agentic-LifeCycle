# Grade Record — qa-100 — Loop 1
**Date:** 2026-06-16  |  **Version:** v1.0  |  **Graded by:** grading-agent

## Rubric Scores
| Category         | Weight | Score | Notes                                                       |
|------------------|--------|-------|-------------------------------------------------------------|
| Accuracy         | 20     | 18    | QA-001 to QA-008 are correct SQL-verifiable tests           |
| Completeness     | 20     | 14    | Missing cross-LOB distribution, Type 2 SCD guard, neg prem |
| PC-Context       | 15     | 14    | PC tables and quote binding referenced                      |
| Data Quality     | 15     | 12    | No test for negative premium impact on aggregates           |
| Traceability     | 15     | 14    | Tests trace to specific tables                              |
| Insight Quality  | 10     | 8     | LOB distribution test would catch silent data skew          |
| Formatting       | 5      | 5     | Clean                                                       |

## Total: 85/100 ❌ FAIL (threshold: 92)

## Gap List (REWORK signal)
1. **Cross-LOB distribution test missing** — LOB % in analytical must match source ±2%
2. **Type 2 SCD guard missing** — Catch accidental duplicate is_current=1 rows
3. **Negative premium guard missing** — Ensure endorsements/cancellations don't corrupt agg

## Signal: REWORK → qa-100 must revise to v2.0 and re-submit
