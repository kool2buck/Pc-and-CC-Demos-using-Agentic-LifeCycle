# Grading Directory — PC_DASHBOARD_DEMO_2025

## Rubrics (6 files)
One rubric per graded document type. 7 categories. 92/100 gate.

## Grade Records (13+ files)
One record per agent per loop.
Agents with 2 loops: grillmewithdocs, to-prd, schema-discovery, qa-100

## Pipeline State
grading/pipeline_state.json — overall pipeline completion status
