# Quick Start — PolicyCenter Demo

## Launch (3 dashboards open at once)
**Mac:**    `./scripts/launch-demo.sh`
**Windows:** Double-click `scripts\launch-demo.bat`

## Individual Dashboards
| Dashboard | File | What to Demo |
|-----------|------|--------------|
| Agent Pipeline | POLICYCENTER_SDLC_DEMO.html | Click each agent → RUN → watch grading bars fill |
| LLM Wiki | wiki.html | Graph view, click nodes, show Obsidian-like navigation |
| Business | dashboard.html | Click LOB filters, show KPI cards update instantly |

## Key Demo Points
1. **GrillMeWithDocs**: Show Loop 1 FAIL (80/100) → SKILL.md fix → Loop 2 PASS (95/100)
2. **Hit Ratio KPI**: 58% overall, 48% NB, 86% Renewal — from Quote layer
3. **PII Encryption**: Switch roles (analyst → regional mgr → data governance officer)
4. **SQL Terminal**: 7 pre-built queries against the ANALYTICAL layer
5. **Sign-Off Gate**: Show the hard stop — APPROVED unlocks dashboard build

## Rebuild Database
```bash
python3 python/01_build_pipeline.py
python3 python/01b_add_quotes.py
python3 python/02_build_dashboard.py
```
